# Knowledge Graph Answer

**Question:** How does the momentum-space dual of the Fock-Lorentz transformations lead to a time-dependent apparent mass, and what consequences does this have for the Klein-Gordon and Dirac oscillators?

## Answer

The momentum-space dual of the Fock-Lorentz transformations leads to a time-dependent apparent mass, mapp(t) = m0/(1 + ct/R), where m0 is the rest mass of the particle. For |t| ≪ R/c, the ordinary SR limit is recovered, mapp ≃ m0, whereas mapp → 0 as t → ∞. The modified Klein-Gordon and Dirac equations, obtained by canonical quantization, contain a slowly varying mass scale, which induces a spectral evolution in the oscillator spectra. The apparent mass drift produces a monotonic spectral collapse only in the asymptotic limit t → ∞, and not at finite time.

## Sources

### Source 1: Page 1

- Chunk: `chunk_e63ffee1aa270b16`
- Entity: `Dirac oscillator`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.8001`
- Semantic: `0.9117`
- BM25: `0.7521`
- Graph: `0.8988`
- LLM rerank: `0.7500`

Graph path:

```text
Dirac oscillator
```

### Source 2: Page 5

- Chunk: `chunk_a67e3fb64382c786`
- Entity: `Hubble radius`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.7706`
- Semantic: `0.8818`
- BM25: `0.6537`
- Graph: `0.7937`
- LLM rerank: `0.7500`

Graph path:

```text
Hubble radius
```

### Source 3: Page 4

- Chunk: `chunk_061056fb1524d2e7`
- Entity: `Fock–Lorentz transformations`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.7611`
- Semantic: `0.8584`
- BM25: `0.6090`
- Graph: `0.8143`
- LLM rerank: `0.7500`

Graph path:

```text
Fock–Lorentz transformations
```

### Source 4: Page 2

- Chunk: `chunk_2443fea43177c96c`
- Entity: `unlinked chunk`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.7518`
- Semantic: `0.9081`
- BM25: `1.0000`
- Graph: `0.0000`
- LLM rerank: `0.7500`

Graph path:

```text
direct vector match
```

### Source 5: Page 20

- Chunk: `chunk_2f4bf355cc1e4c3a`
- Entity: `Dirac oscillator`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.7508`
- Semantic: `0.8278`
- BM25: `0.5270`
- Graph: `0.8988`
- LLM rerank: `0.7500`

Graph path:

```text
Dirac oscillator
```

### Source 6: Page 9

- Chunk: `chunk_8b8c61c33ddce306`
- Entity: `Apparent mass`
- Document: `doc_4a9484dd924d39f9`
- Score: `0.7440`
- Semantic: `0.8574`
- BM25: `0.4556`
- Graph: `0.8564`
- LLM rerank: `0.7500`

Graph path:

```text
Apparent mass
```
