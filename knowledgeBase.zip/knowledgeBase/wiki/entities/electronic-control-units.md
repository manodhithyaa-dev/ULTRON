---
id: entity_3ec8ea8ee10ff471
name: Electronic Control Units
type: hardware
---

# Electronic Control Units

Computational components embedded in vehicles to manage autonomous functions

## Aliases

- ECUs

## Sources

- [[chunk_a79eec0d0df34d5a]]
