---
id: entity_39f810c65f5f6d20
name: averaged dynamics
type: concept
---

# averaged dynamics

The averaged dynamics expressed as dh/dϕ ≃ Keff * G(εn).

## Aliases

- None

## Sources

- [[chunk_04c37ffbc21d6f15]]
