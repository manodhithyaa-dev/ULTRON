---
id: entity_636a1f3175583a14
name: FLInspiredMomentumSpaceDeformation
type: concept
---

# FLInspiredMomentumSpaceDeformation

A momentum-space deformation inspired by Fock-Lorentz transformations, which leads to a deformed dispersion relation.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
