---
id: entity_25bf8e1a2393f110
name: Local
type: concept
---

# Local

A category in XAI taxonomy referring to explanations applied to a local part of the model.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
