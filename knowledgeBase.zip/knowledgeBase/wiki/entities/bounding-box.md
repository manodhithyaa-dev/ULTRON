---
id: entity_8936de6904c82613
name: bounding box
type: concept
---

# bounding box

Rectangular region used to represent an object in object detection

## Aliases

- None

## Sources

- [[chunk_3b65ae6547611187]]
