---
id: entity_04746bd2f2e1729b
name: CPS formalism
type: method
---

# CPS formalism

A formalism for defining presymplectic spaces of solutions in field theory

## Aliases

- None

## Sources

- [[chunk_dd078bcfbf16902a]]
