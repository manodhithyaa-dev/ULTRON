---
id: entity_b1f907167030a938
name: YOLOv5s
type: software model
---

# YOLOv5s

A base object detection model

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_684b65a2e79e2632]]
