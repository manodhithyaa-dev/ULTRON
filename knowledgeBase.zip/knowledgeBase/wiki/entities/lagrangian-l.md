---
id: entity_afb76cb506f8b499
name: Lagrangian (L)
type: concept
---

# Lagrangian (L)

A function that defines the dynamics of a field theory

## Aliases

- None

## Sources

- [[chunk_dd078bcfbf16902a]]
