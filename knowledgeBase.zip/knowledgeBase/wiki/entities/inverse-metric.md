---
id: entity_6c85ab3f8d6424ca
name: Inverse metric
type: concept
---

# Inverse metric

The inverse of the metric tensor used in the context of variational calculations

## Aliases

- None

## Sources

- [[chunk_6b5cd986172c2fdb]]
