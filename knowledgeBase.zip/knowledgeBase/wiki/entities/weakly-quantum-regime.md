---
id: entity_61617d87a8ea9d17
name: Weakly quantum regime
type: concept
---

# Weakly quantum regime



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
