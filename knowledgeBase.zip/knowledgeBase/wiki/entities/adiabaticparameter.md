---
id: entity_316c8318411b9bd0
name: AdiabaticParameter
type: concept
---

# AdiabaticParameter

The adiabatic parameter ηk, which decreases with ct/R for fixed q>0 and is used to determine adiabaticity in wave propagation.

## Aliases

- None

## Sources

- [[chunk_98693b57e4ac9c89]]
- [[chunk_9c337835bc05bd25]]
