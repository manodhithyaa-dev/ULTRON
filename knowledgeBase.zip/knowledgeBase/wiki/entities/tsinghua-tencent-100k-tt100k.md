---
id: entity_9d9a16bdeb002a25
name: Tsinghua-Tencent 100K (TT100K)
type: dataset
---

# Tsinghua-Tencent 100K (TT100K)

A dataset for traffic sign detection

## Aliases

- None

## Sources

- [[chunk_cded9156b67eb4fe]]
