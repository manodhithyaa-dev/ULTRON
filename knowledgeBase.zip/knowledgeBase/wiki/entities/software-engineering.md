---
id: entity_dd7806c6d3a20b24
name: Software engineering
type: method
---

# Software engineering

Systematic approach to designing, building, and maintaining software systems

## Aliases

- None

## Sources

- [[chunk_a79eec0d0df34d5a]]
