---
id: entity_33f8683d9694c401
name: VarD
type: method
---

# VarD

A function in xAct that implements the Leibniz rule for variational derivatives.

## Aliases

- None

## Sources

- [[chunk_4cde0069872070d4]]
