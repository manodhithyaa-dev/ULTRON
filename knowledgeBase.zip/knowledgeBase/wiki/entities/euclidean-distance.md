---
id: entity_4aef750cf8710351
name: Euclidean distance
type: concept
---

# Euclidean distance

The straight-line distance between two points in a plane

## Aliases

- None

## Sources

- [[chunk_3b65ae6547611187]]
