---
id: entity_58bc36fe9cd2c7d2
name: Bianchi identities
type: concept
---

# Bianchi identities

Identities in differential geometry that constrain curvature tensors and are critical for avoiding computational loops in field theory calculations.

## Aliases

- None

## Sources

- [[chunk_ca6e0f0ccb183a63]]
