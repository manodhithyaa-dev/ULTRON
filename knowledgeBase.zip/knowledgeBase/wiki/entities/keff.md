---
id: entity_f9e13a699630e099
name: Keff
type: concept
---

# Keff

a constant that collects the prefactors of the evolution equation

## Aliases

- None

## Sources

- [[chunk_04c37ffbc21d6f15]]
- [[chunk_d7f50f0b6342180c]]
