---
id: entity_8b16477e3abe1de3
name: GDPR
type: regulation
---

# GDPR

European Union data protection regulation impacting vehicle data handling

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
