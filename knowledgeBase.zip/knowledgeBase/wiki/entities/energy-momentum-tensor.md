---
id: entity_3fe884c6fa6c06d4
name: energy-momentum tensor
type: concept
---

# energy-momentum tensor

A tensor that represents the energy and momentum density in a physical system

## Aliases

- None

## Sources

- [[chunk_291b614e7fe8c857]]
- [[chunk_7fc911e7e45dd3bc]]
