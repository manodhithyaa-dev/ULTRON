---
id: entity_77cf46c810626493
name: 4-momentum
type: concept
---

# 4-momentum

The four-dimensional momentum vector in special relativity, with components representing energy and spatial momentum

## Aliases

- None

## Sources

- [[chunk_2d540758cb99f9d1]]
