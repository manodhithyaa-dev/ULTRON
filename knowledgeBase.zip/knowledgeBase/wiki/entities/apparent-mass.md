---
id: entity_846308bec4ff9b39
name: Apparent mass
type: concept
---

# Apparent mass

A function of time defined as mapp(t)/m0 = (1 + ct/R)^{-1}, which exhibits a special-relativistic limit as R→∞ and a leading-order linear drift 1 - ct/R on laboratory time scales, and degenerates to zero as t→∞.

## Aliases

- None

## Sources

- [[chunk_2f4bf355cc1e4c3a]]
- [[chunk_8b8c61c33ddce306]]
- [[chunk_e63ffee1aa270b16]]
- [[chunk_ebd72db35a75d12f]]
