---
id: entity_3b37ef42f765269f
name: Euler-Lagrange form
type: concept
---

# Euler-Lagrange form



## Aliases

- None

## Sources

- [[chunk_a2a2c117fbd51e0e]]
