---
id: entity_2345aeac69297ded
name: Model-specific
type: concept
---

# Model-specific

XAI methods designed for a single specific type of model.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
