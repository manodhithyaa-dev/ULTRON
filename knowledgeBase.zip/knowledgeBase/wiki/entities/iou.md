---
id: entity_8925260c8cb280b2
name: IoU
type: concept
---

# IoU

Intersection over Union, a metric used in object detection to measure the overlap between two bounding boxes

## Aliases

- None

## Sources

- [[chunk_3b65ae6547611187]]
- [[chunk_72fb204c4a8e4af5]]
