---
id: entity_b8b4e9cea77ef29a
name: Metric
type: concept
---

# Metric

The tensor field defining the geometry of spacetime in general relativity

## Aliases

- None

## Sources

- [[chunk_2627d7e62b253eb9]]
- [[chunk_6b5cd986172c2fdb]]
