---
id: entity_ea94bf8700bfa216
name: Ultra-sonic sensor
type: hardware
---

# Ultra-sonic sensor

Sound-wave-based sensor that is less accurate in rain or wet conditions.

## Aliases

- None

## Sources

- [[chunk_9c0df650384be3e9]]
