---
id: entity_9c4315fa538664a0
name: Model-Agnostic Explanations
type: concept
---

# Model-Agnostic Explanations

Explanations that can be applied across diverse model types without requiring model-specific knowledge (e.g., SHAP, LIME).

## Aliases

- None

## Sources

- [[chunk_42086042ea3e3878]]
