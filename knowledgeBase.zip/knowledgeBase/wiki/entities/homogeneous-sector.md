---
id: entity_19d011998fb4b4cd
name: Homogeneous sector
type: concept
---

# Homogeneous sector

The restricted domain of the model where the apparent-mass mechanism admits analytic treatment.

## Aliases

- None

## Sources

- [[chunk_8b8c61c33ddce306]]
