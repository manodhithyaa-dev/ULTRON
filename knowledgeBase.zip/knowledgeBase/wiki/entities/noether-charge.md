---
id: entity_f1f00608e187ad7a
name: Noether charge
type: concept
---

# Noether charge

A conserved quantity associated with a symmetry of the Lagrangian

## Aliases

- None

## Sources

- [[chunk_7fc911e7e45dd3bc]]
