---
id: entity_cad069f27eef3990
name: Integrability
type: property
---

# Integrability



## Aliases

- None

## Sources

- [[chunk_5452b9712845e4c4]]
