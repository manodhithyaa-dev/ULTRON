---
id: entity_49f1e80d2fa0c2db
name: Born-Oppenheimer ansatz
type: method
---

# Born-Oppenheimer ansatz

A mathematical approach for separating nuclear and electronic motion in quantum systems.

## Aliases

- None

## Sources

- [[chunk_9c337835bc05bd25]]
