---
id: entity_9cbc08be6c4fa9ed
name: exterior derivative
type: concept
---

# exterior derivative



## Aliases

- None

## Sources

- [[chunk_a2a2c117fbd51e0e]]
