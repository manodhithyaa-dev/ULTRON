---
id: entity_f45b59736bd986bf
name: Transparency
type: concept
---

# Transparency

The opposite of being opaque for a black-box model; a system becomes transparent when it is understandable by humans.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
