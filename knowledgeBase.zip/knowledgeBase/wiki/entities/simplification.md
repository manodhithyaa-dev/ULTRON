---
id: entity_11f797e8a21d1fab
name: Simplification
type: method
---

# Simplification

Command in xAct that is Simplify@ToCanonical

## Aliases

- None

## Sources

- [[chunk_95ad35faeea20af6]]
