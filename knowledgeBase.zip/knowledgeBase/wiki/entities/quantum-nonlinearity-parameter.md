---
id: entity_cb92046ae7080798
name: Quantum nonlinearity parameter
type: concept
---

# Quantum nonlinearity parameter

Parameter χ that characterizes the quantum nonlinearity in the radiation reaction

## Aliases

- None

## Sources

- [[chunk_ac52788834dd3fee]]
