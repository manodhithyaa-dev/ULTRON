---
id: entity_043ce5ee02caeefe
name: Non-minimal substitution
type: method
---

# Non-minimal substitution

A technique in quantum mechanics where the momentum operator is modified to include a time-dependent mass function, used to derive the Klein-Gordon oscillator.

## Aliases

- None

## Sources

- [[chunk_02600ac7cd921f73]]
