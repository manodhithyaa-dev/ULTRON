---
id: entity_441ff7712716ffcb
name: Crossover regime
type: concept
---

# Crossover regime



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
