---
id: entity_e093ae5f14c69131
name: xTensor
type: software
---

# xTensor

Extends Mathematica with abstract tensor calculus

## Aliases

- None

## Sources

- [[chunk_ed64c4baaa1d86e0]]
