---
id: entity_f090a26341b14f83
name: Plane Wave Identities
type: concept
---

# Plane Wave Identities

Mathematical identities: F^μν n_ν = 0 and F^μν F_να = - (a_j ψ'_j)^2 n^μ n^α

## Aliases

- None

## Sources

- [[chunk_bd172296bfb8a046]]
