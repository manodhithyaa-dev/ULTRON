---
id: entity_8d06f179f9f6a7a7
name: Proper time
type: concept
---

# Proper time

Time parameter s in the electron four-velocity

## Aliases

- None

## Sources

- [[chunk_ac52788834dd3fee]]
