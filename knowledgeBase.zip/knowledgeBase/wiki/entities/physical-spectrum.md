---
id: entity_d83fc6116db157b5
name: Physical spectrum
type: concept
---

# Physical spectrum

The complete set of energy eigenvalues of the physical system, formed by the union of the two component ladders (not counted as two independent spectra).

## Aliases

- None

## Sources

- [[chunk_f9c43d91bc310e21]]
