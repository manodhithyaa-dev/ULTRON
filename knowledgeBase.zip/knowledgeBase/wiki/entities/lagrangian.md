---
id: entity_d457c122ad6a6d13
name: Lagrangian
type: concept
---

# Lagrangian

A functional that describes the dynamics of a field theory.

## Aliases

- None

## Sources

- [[chunk_291b614e7fe8c857]]
- [[chunk_7fc911e7e45dd3bc]]
- [[chunk_a2a2c117fbd51e0e]]
