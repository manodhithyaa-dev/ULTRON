---
id: entity_5f3bcd125e89c868
name: Mathematica
type: software
---

# Mathematica

Symbolic computation software

## Aliases

- None

## Sources

- [[chunk_ce59fe25a0aef320]]
