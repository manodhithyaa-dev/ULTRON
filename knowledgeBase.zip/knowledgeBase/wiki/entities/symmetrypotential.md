---
id: entity_02d28cff2c46dc8c
name: SymmetryPotential
type: method
---

# SymmetryPotential

A function in xCPS that computes the potential for a vector field symmetry.

## Aliases

- None

## Sources

- [[chunk_291b614e7fe8c857]]
