---
id: entity_2fcb6c5b179bbcfb
name: instantaneous spectrum
type: concept
---

# instantaneous spectrum



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
