---
id: entity_ab15e7e4929cb25e
name: Apparent-mass mechanism
type: concept
---

# Apparent-mass mechanism

The mechanism that generates apparent mass in the context of the modified Klein-Gordon equation.

## Aliases

- None

## Sources

- [[chunk_8b8c61c33ddce306]]
