---
id: entity_e24757f1abe666e8
name: Search Space
type: concept
---

# Search Space

A predefined set of 5 sub-policies for data augmentation, each consisting of two image enhancement operations

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
