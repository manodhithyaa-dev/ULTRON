---
id: entity_052724f73aa90cb9
name: Special Relativity
type: concept
---

# Special Relativity

The relativistic framework describing motion at constant velocity without gravitational effects

## Aliases

- None

## Sources

- [[chunk_eff3056d091d58b8]]
