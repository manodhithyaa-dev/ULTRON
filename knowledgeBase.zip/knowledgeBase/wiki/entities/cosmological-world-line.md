---
id: entity_4fef13ebd2a3fa62
name: cosmological world line
type: concept
---

# cosmological world line



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
