---
id: entity_60be9861750facbf
name: mAP
type: metric
---

# mAP

Mean Average Precision, a standard metric for object detection

## Aliases

- None

## Sources

- [[chunk_684b65a2e79e2632]]
