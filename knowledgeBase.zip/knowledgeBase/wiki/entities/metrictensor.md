---
id: entity_892d689502de3fb2
name: MetricTensor
type: tensor
---

# MetricTensor

The metric tensor in general relativity, which defines the geometry of spacetime.

## Aliases

- g

## Sources

- [[chunk_291b614e7fe8c857]]
- [[chunk_a394da0626bbe4f2]]
