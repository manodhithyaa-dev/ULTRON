---
id: entity_b3a8f101cb705049
name: Comprehensibility
type: concept
---

# Comprehensibility

The ability to express learned information in a way that is understandable to humans.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
