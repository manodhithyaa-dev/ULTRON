---
id: entity_95321731886a0a9b
name: Dual transformations
type: concept
---

# Dual transformations

A generalized framework for spacetime transformations that extends Lorentz boosts through position-dependent factors.

## Aliases

- None

## Sources

- [[chunk_4f67ec1ef93df0cb]]
