---
id: entity_fc979ca49becce0b
name: ModifiedKleinGordonEquation
type: concept
---

# ModifiedKleinGordonEquation

A quantum field theory equation derived by promoting four-momentum components to differential operators via canonical correspondence.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
- [[chunk_8b8c61c33ddce306]]
- [[chunk_a67e3fb64382c786]]
