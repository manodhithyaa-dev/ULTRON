---
id: entity_ff87672e615f7243
name: radiation reaction
type: concept
---

# radiation reaction

The process by which a charged particle loses energy through electromagnetic radiation, governed by the Liénard-Wiechert potential

## Aliases

- None

## Sources

- [[chunk_2d540758cb99f9d1]]
- [[chunk_d7f50f0b6342180c]]
