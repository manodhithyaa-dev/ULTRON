---
id: entity_ccad3fc87cd6d177
name: Jetson Xavier NX
type: hardware
---

# Jetson Xavier NX

A mobile device for edge deployment

## Aliases

- None

## Sources

- [[chunk_684b65a2e79e2632]]
