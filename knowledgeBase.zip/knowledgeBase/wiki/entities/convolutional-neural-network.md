---
id: entity_48974119889bcf84
name: Convolutional Neural Network
type: algorithm
---

# Convolutional Neural Network

A deep learning architecture specialized for processing grid-like data, such as images and video.

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_78335d7794f92aac]]
