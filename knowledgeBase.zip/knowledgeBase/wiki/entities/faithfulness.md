---
id: entity_8b77dce83f2d771c
name: Faithfulness
type: concept
---

# Faithfulness

The ability to consistently select the most relevant features in a model.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
