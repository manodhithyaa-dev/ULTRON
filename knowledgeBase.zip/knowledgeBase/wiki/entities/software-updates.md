---
id: entity_97a78be625bfce3e
name: Software updates
type: technology
---

# Software updates

Firmware or code modifications to enhance vehicle functionality

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
