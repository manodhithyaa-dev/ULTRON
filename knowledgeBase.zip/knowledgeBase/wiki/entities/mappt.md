---
id: entity_903af844afcb91c5
name: mapp(t)
type: concept
---

# mapp(t)



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
