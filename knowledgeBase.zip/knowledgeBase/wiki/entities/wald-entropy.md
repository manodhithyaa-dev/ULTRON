---
id: entity_ad7a20aa3b18d96c
name: Wald entropy
type: concept
---

# Wald entropy

Entropy in general relativity defined by Wald's method for gravitational systems

## Aliases

- None

## Sources

- [[chunk_222e71ef5df955c8]]
