---
id: entity_d96e095c32d2f486
name: Spectral consequences
type: concept
---

# Spectral consequences

The consequences of the apparent-mass mechanism on the system's spectrum.

## Aliases

- None

## Sources

- [[chunk_8b8c61c33ddce306]]
