---
id: entity_9edd7b7b105665f9
name: variational derivative
type: concept
---

# variational derivative

The first-order variation operator (denoted by δ), used to define variational vectors in the context of field theory.

## Aliases

- None

## Sources

- [[chunk_e93fcf82bb97b952]]
