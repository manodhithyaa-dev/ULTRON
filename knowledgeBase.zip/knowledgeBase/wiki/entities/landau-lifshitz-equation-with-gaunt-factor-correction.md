---
id: entity_e6c2887d6bc4fd8c
name: Landau-Lifshitz equation with Gaunt factor correction
type: equation
---

# Landau-Lifshitz equation with Gaunt factor correction



## Aliases

- None

## Sources

- [[chunk_5452b9712845e4c4]]
