---
id: entity_e6f0f39409b0516b
name: Variational vector field (VVF)
type: concept
---

# Variational vector field (VVF)

An infinitesimal transformation in the space of field configurations

## Aliases

- None

## Sources

- [[chunk_dd078bcfbf16902a]]
