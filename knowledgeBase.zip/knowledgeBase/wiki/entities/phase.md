---
id: entity_02195b8e989603e4
name: Phase
type: concept
---

# Phase

Evolution parameter ϕ used in the dynamics of the system

## Aliases

- None

## Sources

- [[chunk_bd172296bfb8a046]]
