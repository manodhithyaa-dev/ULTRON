---
id: entity_0ad5c220f66c7778
name: Lorentz boost
type: concept
---

# Lorentz boost

A fundamental symmetry transformation in special relativity that preserves spacetime intervals.

## Aliases

- None

## Sources

- [[chunk_4f67ec1ef93df0cb]]
