---
id: entity_37ed9d33ac29466f
name: DivergenceQ
type: method
---

# DivergenceQ

Checks if an expression is a total divergence

## Aliases

- None

## Sources

- [[chunk_2627d7e62b253eb9]]
- [[chunk_638a88d4afceb0d0]]
- [[chunk_ef20ecf5a069384d]]
