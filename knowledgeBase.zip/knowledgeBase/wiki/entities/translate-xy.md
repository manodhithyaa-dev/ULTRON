---
id: entity_b360ecacf82cd77e
name: Translate X/Y
type: method
---

# Translate X/Y

An image enhancement technique that applies horizontal and vertical translations to simulate shifts in object positions

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
