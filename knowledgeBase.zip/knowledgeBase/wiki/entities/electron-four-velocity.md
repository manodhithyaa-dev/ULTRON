---
id: entity_dea4b304ae88bc00
name: Electron four-velocity
type: concept
---

# Electron four-velocity

Denoted by uµ = dxµ/ds, where s is proper time

## Aliases

- None

## Sources

- [[chunk_ac52788834dd3fee]]
