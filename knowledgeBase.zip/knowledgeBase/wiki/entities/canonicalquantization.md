---
id: entity_470ec5fa681d5f3a
name: CanonicalQuantization
type: concept
---

# CanonicalQuantization

The process of quantization that produces the modified Klein-Gordon and Dirac equations.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
