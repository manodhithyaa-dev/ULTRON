---
id: entity_5714ee003eb1e9af
name: light_front_dissipation_function
type: concept
---

# light_front_dissipation_function

A function defined on the light-front that describes the dissipation dynamics in relativistic systems, central to light-front quantum mechanics and particle physics.

## Aliases

- None

## Sources

- [[chunk_308333403693b741]]
