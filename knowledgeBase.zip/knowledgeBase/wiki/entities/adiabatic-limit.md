---
id: entity_875ee219ff7e7c24
name: Adiabatic limit
type: concept
---

# Adiabatic limit

A regime in quantum mechanics where the system evolves slowly enough that the wavefunction remains in an eigenstate of the Hamiltonian, enabling decoupling of components.

## Aliases

- None

## Sources

- [[chunk_f9c43d91bc310e21]]
