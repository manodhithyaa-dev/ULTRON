---
id: entity_cb258a4871a034ae
name: ToCanonical
type: method
---

# ToCanonical

Command in xAct that brings expressions to a unique canonical form

## Aliases

- None

## Sources

- [[chunk_95ad35faeea20af6]]
