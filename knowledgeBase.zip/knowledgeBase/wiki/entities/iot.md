---
id: entity_ff3d7d9e4c824480
name: IoT
type: concept
---

# IoT

Internet of Things: a network of physical objects embedded with electronics, software, sensors, and connectivity for communication and data exchange.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
