---
id: entity_96c5c515041f4722
name: Counter-propagating relativistic particle
type: concept
---

# Counter-propagating relativistic particle

A relativistic particle that propagates in the opposite direction to the wave, forming a specific scenario for dissipation analysis in light-front dynamics.

## Aliases

- None

## Sources

- [[chunk_2d540758cb99f9d1]]
- [[chunk_308333403693b741]]
- [[chunk_c1565e0a8a3bcbfa]]
