---
id: entity_e8bcead401b53aea
name: Global Explanations
type: concept
---

# Global Explanations

Explanations that describe the overall behavior of a model across the entire dataset (e.g., feature importance trends).

## Aliases

- None

## Sources

- [[chunk_42086042ea3e3878]]
