---
id: entity_eed6f073a444a6f6
name: Lewis-Riesenfeld invariants
type: concept
---

# Lewis-Riesenfeld invariants

a method for solving time-dependent quantum systems

## Aliases

- None

## Sources

- [[chunk_a67e3fb64382c786]]
