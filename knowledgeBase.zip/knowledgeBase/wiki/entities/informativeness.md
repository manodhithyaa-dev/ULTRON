---
id: entity_ce67a552159a9df7
name: Informativeness
type: concept
---

# Informativeness

The ability of an explainability strategy to provide end-users with meaningful information.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
