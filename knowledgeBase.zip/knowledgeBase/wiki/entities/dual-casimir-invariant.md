---
id: entity_ba5408d5be89c39d
name: dual Casimir invariant
type: concept
---

# dual Casimir invariant



## Aliases

- None

## Sources

- [[chunk_ebd72db35a75d12f]]
