---
id: entity_f498474c69f589df
name: China Traffic Sign Dataset
type: dataset
---

# China Traffic Sign Dataset

A dataset of traffic signs used for training improved traffic sign detectors.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
