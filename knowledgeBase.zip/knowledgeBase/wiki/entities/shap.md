---
id: entity_ec098178cd829fd9
name: SHAP
type: method
---

# SHAP

SHapley Additive exPlanations, a game-theoretic approach for explaining model predictions in machine learning.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
