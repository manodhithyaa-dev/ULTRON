---
id: entity_463c5d4dc5b2168d
name: Inverse Gaunt factor
type: concept
---

# Inverse Gaunt factor

The reciprocal of the Gaunt factor, which is a function of the quantum parameter χ and exhibits phase dependence.

## Aliases

- None

## Sources

- [[chunk_c1565e0a8a3bcbfa]]
