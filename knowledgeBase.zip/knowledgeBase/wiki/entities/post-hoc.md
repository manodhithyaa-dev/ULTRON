---
id: entity_02251846998c61ba
name: Post-hoc
type: concept
---

# Post-hoc

Explanations applied externally after the training process of decision systems.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
