---
id: entity_b59ec641b424b178
name: Ethical principles
type: concept
---

# Ethical principles

Guidelines for moral decision-making in autonomous vehicle scenarios

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
