---
id: entity_655a05011dc251c6
name: Scalar Evolution Equation
type: concept
---

# Scalar Evolution Equation

Equation d/dϕ (1/ρ) = τ_R g(χ) (ξ_j ψ'_j)^2, where τ_R is a coupling constant, g(χ) is a function, and χ is a parameter

## Aliases

- None

## Sources

- [[chunk_bd172296bfb8a046]]
