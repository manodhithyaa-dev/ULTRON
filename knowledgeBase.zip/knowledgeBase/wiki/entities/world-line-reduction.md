---
id: entity_86ec4985678da69c
name: World-line reduction
type: concept
---

# World-line reduction

A technique for simplifying equations by reducing spatial dependence.

## Aliases

- None

## Sources

- [[chunk_8b8c61c33ddce306]]
