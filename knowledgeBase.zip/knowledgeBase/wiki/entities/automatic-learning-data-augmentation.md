---
id: entity_504d2704464395e8
name: Automatic Learning Data Augmentation
type: method
---

# Automatic Learning Data Augmentation

A method for data augmentation that is learned and optimized using reinforcement learning.

## Aliases

- None

## Sources

- [[chunk_3f0df260b036f227]]
