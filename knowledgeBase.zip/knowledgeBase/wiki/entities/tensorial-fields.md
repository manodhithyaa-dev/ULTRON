---
id: entity_9b01b6e8d6f00087
name: tensorial fields
type: concept
---

# tensorial fields



## Aliases

- None

## Sources

- [[chunk_a2a2c117fbd51e0e]]
