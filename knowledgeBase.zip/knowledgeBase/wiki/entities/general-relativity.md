---
id: entity_cb3ccb348b3e4180
name: General Relativity
type: concept
---

# General Relativity

Theory of gravitation describing spacetime geometry and gravitational interactions

## Aliases

- None

## Sources

- [[chunk_222e71ef5df955c8]]
