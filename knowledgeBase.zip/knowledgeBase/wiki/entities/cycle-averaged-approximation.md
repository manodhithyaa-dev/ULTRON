---
id: entity_92ca06c7725dba18
name: Cycle-averaged approximation
type: method
---

# Cycle-averaged approximation



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
