---
id: entity_cfc86e17b9269cd7
name: ModifiedDiracEquation
type: concept
---

# ModifiedDiracEquation

The modified Dirac equation derived from canonical quantization of the deformed momentum space.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
- [[chunk_a67e3fb64382c786]]
