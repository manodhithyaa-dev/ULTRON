---
id: entity_be0fcf526ebb30b1
name: RetinaNet
type: algorithm
---

# RetinaNet

A model that uses Feature Pyramid Network for object detection.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
