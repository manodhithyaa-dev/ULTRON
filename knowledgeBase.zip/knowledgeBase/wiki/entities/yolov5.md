---
id: entity_63806a07b7b97ced
name: YOLOv5
type: algorithm
---

# YOLOv5

A deep learning model for object detection, used as the base for traffic sign detection in this paper.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
- [[chunk_cded9156b67eb4fe]]
