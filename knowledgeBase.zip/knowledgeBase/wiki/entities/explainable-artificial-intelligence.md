---
id: entity_c17106c4d6dc1c0f
name: Explainable Artificial Intelligence
type: concept
---

# Explainable Artificial Intelligence

A field of study focused on making AI systems understandable to humans

## Aliases

- XAI
- explainable AI

## Sources

- [[chunk_e462f399bda26deb]]
