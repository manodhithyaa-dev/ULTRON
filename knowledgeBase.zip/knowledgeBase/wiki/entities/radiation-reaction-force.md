---
id: entity_a3701334e83a3a78
name: Radiation-reaction force
type: force
---

# Radiation-reaction force



## Aliases

- None

## Sources

- [[chunk_5452b9712845e4c4]]
