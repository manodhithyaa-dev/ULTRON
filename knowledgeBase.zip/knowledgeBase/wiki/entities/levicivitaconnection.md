---
id: entity_30ad455be2855f31
name: LeviCivitaConnection
type: tensor
---

# LeviCivitaConnection

The Levi-Civita connection in general relativity, used to define parallel transport and curvature.

## Aliases

- None

## Sources

- [[chunk_2627d7e62b253eb9]]
- [[chunk_a394da0626bbe4f2]]
