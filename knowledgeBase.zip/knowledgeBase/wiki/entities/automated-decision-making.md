---
id: entity_9bcc5fee1153b5b2
name: Automated Decision-Making
type: concept
---

# Automated Decision-Making



## Aliases

- None

## Sources

- [[chunk_1bf0ce6f194b3f80]]
