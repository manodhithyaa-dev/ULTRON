---
id: entity_f76ab71b3d81c3fa
name: FL spacetime
type: concept
---

# FL spacetime

A spacetime structure defined by the conformal factor that governs the transformation rules for momentum space.

## Aliases

- None

## Sources

- [[chunk_4f67ec1ef93df0cb]]
