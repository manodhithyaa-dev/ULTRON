---
id: entity_1824671da6ab4ae2
name: Dimensionless Amplitude
type: concept
---

# Dimensionless Amplitude

Amplitude ξ_j defined by ξ_j^2 = - (e^2 a_j^2)/m^2, with a_j being a parameter and m the mass scale

## Aliases

- None

## Sources

- [[chunk_bd172296bfb8a046]]
