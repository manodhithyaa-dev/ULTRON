---
id: entity_73a666e3f8918219
name: Proposed Method
type: method
---

# Proposed Method

The method described in the paper for traffic sign detection and recognition

## Aliases

- None

## Sources

- [[chunk_684b65a2e79e2632]]
