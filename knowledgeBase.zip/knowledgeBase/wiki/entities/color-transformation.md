---
id: entity_af01d0b4244dffeb
name: Color transformation
type: method
---

# Color transformation



## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
