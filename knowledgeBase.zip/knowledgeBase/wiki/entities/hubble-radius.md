---
id: entity_5e9a5a199156e350
name: Hubble radius
type: concept
---

# Hubble radius

the radius of the Hubble sphere in cosmology

## Aliases

- None

## Sources

- [[chunk_a67e3fb64382c786]]
