---
id: entity_53880fb4fa3872b0
name: characteristic length
type: concept
---

# characteristic length



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
