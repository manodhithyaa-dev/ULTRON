---
id: entity_ea424017c57b0d0b
name: Random Forest
type: algorithm
---

# Random Forest

An ensemble learning method that combines multiple decision trees to improve accuracy and reduce overfitting.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
