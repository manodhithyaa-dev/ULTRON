---
id: entity_5729f8eebb90f92e
name: Recursive constantness-propagation algorithm
type: algorithm
---

# Recursive constantness-propagation algorithm

An algorithm that propagates constants through the variational graph

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
