---
id: entity_11ddef5f1581115e
name: LinearlyExpandingCosmology
type: concept
---

# LinearlyExpandingCosmology

Cosmological models that expand linearly with time.

## Aliases

- None

## Sources

- [[chunk_98693b57e4ac9c89]]
