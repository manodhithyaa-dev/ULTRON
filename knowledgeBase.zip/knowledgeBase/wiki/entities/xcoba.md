---
id: entity_fcb0516250ccde3a
name: xCoba
type: software
---

# xCoba

Complements xTensor with tools for explicit bases and component calculations

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
- [[chunk_ed64c4baaa1d86e0]]
