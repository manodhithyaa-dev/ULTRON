---
id: entity_2b8dd0c46c694096
name: FPN
type: algorithm
---

# FPN

Feature Pyramid Network

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_de02ffe72fca9186]]
