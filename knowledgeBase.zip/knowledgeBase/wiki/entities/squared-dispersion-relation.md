---
id: entity_2276436ddfc1e5a1
name: squared dispersion relation
type: concept
---

# squared dispersion relation

The energy-momentum relation for quantum systems that reduces to Special Relativity in the low-mass limit

## Aliases

- None

## Sources

- [[chunk_eff3056d091d58b8]]
