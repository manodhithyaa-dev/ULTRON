---
id: entity_0b57609580f2d29d
name: SnapMix
type: method
---

# SnapMix

An image enhancement technique that applies random cropping and scaling to generate diverse training samples

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
