---
id: entity_88069f4e45ea28c2
name: G(εn)
type: function
---

# G(εn)

A function defined by the integral expression (with closed form) that depends on the parameter εn.

## Aliases

- None

## Sources

- [[chunk_04c37ffbc21d6f15]]
