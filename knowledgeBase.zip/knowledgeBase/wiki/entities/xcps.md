---
id: entity_8320ffe2abd1cc52
name: xCPS
type: technology
---

# xCPS

A Mathematica package for defining and manipulating vertical forms and field-space structures, distributed under GNU GPL and available at https://github.com/juanmargaf/xCPS.

## Aliases

- None

## Sources

- [[chunk_291b614e7fe8c857]]
- [[chunk_638a88d4afceb0d0]]
- [[chunk_6b5cd986172c2fdb]]
- [[chunk_a2a2c117fbd51e0e]]
- [[chunk_a394da0626bbe4f2]]
- [[chunk_e93fcf82bb97b952]]
- [[chunk_ef20ecf5a069384d]]
