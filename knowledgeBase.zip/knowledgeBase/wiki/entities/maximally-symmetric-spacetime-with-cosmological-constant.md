---
id: entity_8edc16c736f777cf
name: Maximally symmetric spacetime with cosmological constant
type: concept
---

# Maximally symmetric spacetime with cosmological constant

A spacetime with maximal symmetry (e.g., de Sitter or anti-de Sitter space) characterized by a cosmological constant Λ.

## Aliases

- None

## Sources

- [[chunk_7b3621d89bf94a88]]
