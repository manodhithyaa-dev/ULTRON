---
id: entity_78c55a6ad04d7767
name: Klein-Gordon equation
type: concept
---

# Klein-Gordon equation

A relativistic wave equation for spin-0 particles that describes the dynamics of scalar fields.

## Aliases

- KG equation

## Sources

- [[chunk_02600ac7cd921f73]]
- [[chunk_2f4bf355cc1e4c3a]]
