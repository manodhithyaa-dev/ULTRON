---
id: entity_118540f74f503236
name: four_velocity
type: concept
---

# four_velocity

The four-dimensional velocity vector in special relativity, comprising spatial velocity and temporal components, used to describe particle motion in spacetime.

## Aliases

- None

## Sources

- [[chunk_308333403693b741]]
