---
id: entity_b242b2a2c31b0cdc
name: Deformed Casimir invariant
type: concept
---

# Deformed Casimir invariant

The invariant quantity derived from the dual transformations that replaces the standard mass shell condition in deformed spacetime.

## Aliases

- None

## Sources

- [[chunk_4f67ec1ef93df0cb]]
