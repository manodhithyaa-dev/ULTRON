---
id: entity_72c2a27b7fe5285e
name: Data Augmentation Policy
type: method
---

# Data Augmentation Policy

A systematic approach for data augmentation that combines a search space and search algorithm to select effective image enhancement operations

## Aliases

- None

## Sources

- [[chunk_3f0df260b036f227]]
- [[chunk_a324525c8c883cb0]]
