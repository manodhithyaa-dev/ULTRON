---
id: entity_dff85ef5067faf24
name: Symplectic currents
type: concept
---

# Symplectic currents

Currents in general relativity used to compute thermodynamic quantities like entropy

## Aliases

- None

## Sources

- [[chunk_222e71ef5df955c8]]
