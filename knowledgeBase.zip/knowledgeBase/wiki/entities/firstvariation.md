---
id: entity_0d050f441db1e72f
name: FirstVariation
type: method
---

# FirstVariation

A function in xAct that computes the first variation of a Lagrangian expression.

## Aliases

- None

## Sources

- [[chunk_4cde0069872070d4]]
