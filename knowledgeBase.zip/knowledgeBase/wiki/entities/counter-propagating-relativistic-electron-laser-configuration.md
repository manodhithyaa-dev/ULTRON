---
id: entity_3b13713b03347146
name: Counter-propagating relativistic electron-laser configuration
type: concept
---

# Counter-propagating relativistic electron-laser configuration



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
