---
id: entity_12a084a0e96b2d08
name: XAI-CBIR
type: software
---

# XAI-CBIR

A human-assisted explainable AI system for content-based image retrieval in surgical education.

## Aliases

- None

## Sources

- [[chunk_a9ae9e011fe6a4b5]]
