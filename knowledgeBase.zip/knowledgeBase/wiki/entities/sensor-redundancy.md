---
id: entity_a5d3fc2190aac87e
name: Sensor redundancy
type: technology
---

# Sensor redundancy

Multiple sensor systems to ensure continuous environmental monitoring

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
