---
id: entity_a632939716e9bb14
name: Component ladders
type: concept
---

# Component ladders

Two distinct sequences of energy eigenvalues for the upper and lower spinor components in the adiabatic limit, derived from harmonic oscillator eigenvalues with component-specific shifts.

## Aliases

- None

## Sources

- [[chunk_f9c43d91bc310e21]]
