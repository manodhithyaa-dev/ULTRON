---
id: entity_24bdbc160627351f
name: VariationalGraph
type: graph
---

# VariationalGraph

A global graph in xCPS that encodes all defined tensors as vertices and their variational dependencies as directed edges.

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
- [[chunk_a394da0626bbe4f2]]
