---
id: entity_e4d831ac1caab370
name: Field Tensor
type: concept
---

# Field Tensor

Tensor F^μν(ϕ) defined as F^μν(ϕ) = f^μν_j ψ'_j(ϕ), where f^μν_j = n^μ_a^ν_j - n^ν_a^μ_j and ψ'_j denotes the derivative of ψ_j with respect to ϕ

## Aliases

- None

## Sources

- [[chunk_bd172296bfb8a046]]
