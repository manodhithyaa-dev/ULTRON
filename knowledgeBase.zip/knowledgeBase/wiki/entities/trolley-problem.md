---
id: entity_c0982e7c21bdf22d
name: Trolley problem
type: concept
---

# Trolley problem

An ethical thought experiment where self-driving vehicles must choose between two harmful outcomes

## Aliases

- None

## Sources

- [[chunk_a79eec0d0df34d5a]]
