---
id: entity_417409984ee45445
name: feature pyramids
type: concept
---

# feature pyramids

Hierarchical feature structures

## Aliases

- None

## Sources

- [[chunk_de02ffe72fca9186]]
