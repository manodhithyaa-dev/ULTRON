---
id: entity_c8ef82204cfcfef8
name: Decision Tree
type: algorithm
---

# Decision Tree

A supervised learning algorithm used for classification and regression tasks that creates a tree-like model of decisions.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
