---
id: entity_efbaa8cbfffc1af3
name: LIME
type: method
---

# LIME

Local Interpretable Model-agnostic Explanations, a technique for explaining individual predictions of any machine learning model.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
