---
id: entity_591534ca37f88fc1
name: Explainable AI
type: concept
---

# Explainable AI

AI systems designed to be transparent and interpretable to humans

## Aliases

- None

## Sources

- [[chunk_0417279e249039ed]]
- [[chunk_a9ae9e011fe6a4b5]]
