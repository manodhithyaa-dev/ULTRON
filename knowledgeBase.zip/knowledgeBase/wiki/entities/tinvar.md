---
id: entity_17f87ffa0b59085c
name: TInvar
type: software
---

# TInvar

A software package for implementing identities in theoretical physics, particularly for gravitational calculations

## Aliases

- None

## Sources

- [[chunk_222e71ef5df955c8]]
