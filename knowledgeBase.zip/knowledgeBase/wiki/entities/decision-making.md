---
id: entity_96d3365b1c45f1e5
name: Decision making
type: concept
---

# Decision making

Process by which autonomous vehicles determine actions based on inputs

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
