---
id: entity_c73daf6649ef6a59
name: Mixup
type: method
---

# Mixup

An image enhancement technique that linearly combines pairs of images to generate smooth transitions between training samples

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
