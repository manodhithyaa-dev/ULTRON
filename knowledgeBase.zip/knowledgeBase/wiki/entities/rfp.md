---
id: entity_d6c0324fb4ca223c
name: RFP
type: algorithm
---

# RFP

Receptive Field Pyramid

## Aliases

- None

## Sources

- [[chunk_de02ffe72fca9186]]
