---
id: entity_e4c7fec6fa33d287
name: Plane electromagnetic wave
type: concept
---

# Plane electromagnetic wave



## Aliases

- None

## Sources

- [[chunk_1b53e9e1f246ee35]]
