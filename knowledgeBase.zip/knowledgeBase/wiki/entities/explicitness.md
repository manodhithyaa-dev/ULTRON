---
id: entity_a14f86051dbe6041
name: Explicitness
type: concept
---

# Explicitness

The ability of a method to deliver immediate and clear explanations.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
