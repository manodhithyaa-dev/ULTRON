---
id: entity_14d8491bb6b93421
name: CutMix
type: method
---

# CutMix

An image enhancement technique that cuts and pastes patches from different images to create mixed samples

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
