---
id: entity_955bbf18f810b012
name: oscillator
type: concept
---

# oscillator



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
