---
id: entity_b923c0c6e64f0ee6
name: VertCartanMagicFormula
type: formula
---

# VertCartanMagicFormula

Formula that relates VertLie to VertInt

## Aliases

- None

## Sources

- [[chunk_93cfc67c265fcf32]]
