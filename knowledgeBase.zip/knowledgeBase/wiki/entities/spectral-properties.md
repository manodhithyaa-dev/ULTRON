---
id: entity_31fca6503328613c
name: Spectral properties
type: phenomenon
---

# Spectral properties



## Aliases

- None

## Sources

- [[chunk_2f4bf355cc1e4c3a]]
