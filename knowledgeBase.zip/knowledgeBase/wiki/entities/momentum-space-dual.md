---
id: entity_8aeb63d3460884ed
name: Momentum-space dual
type: concept
---

# Momentum-space dual

A dual representation in momentum space

## Aliases

- None

## Sources

- [[chunk_e63ffee1aa270b16]]
