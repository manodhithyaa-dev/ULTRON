---
id: entity_862668c6bb5e7f02
name: low-level features
type: concept
---

# low-level features

Features extracted at lower levels of the network

## Aliases

- None

## Sources

- [[chunk_de02ffe72fca9186]]
