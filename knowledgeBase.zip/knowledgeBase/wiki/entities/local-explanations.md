---
id: entity_a793c71b308ec762
name: Local Explanations
type: concept
---

# Local Explanations

Explanations that focus on individual predictions or instances (e.g., why a specific input was classified a certain way).

## Aliases

- None

## Sources

- [[chunk_42086042ea3e3878]]
