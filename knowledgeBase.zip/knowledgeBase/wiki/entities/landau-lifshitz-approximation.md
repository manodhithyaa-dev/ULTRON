---
id: entity_f50b05dc07ca9146
name: Landau-Lifshitz approximation
type: concept
---

# Landau-Lifshitz approximation

A classical approximation for radiation reaction where the Gaunt factor is fixed at 1 (g = 1), representing the simplest case without quantum effects

## Aliases

- None

## Sources

- [[chunk_2d540758cb99f9d1]]
