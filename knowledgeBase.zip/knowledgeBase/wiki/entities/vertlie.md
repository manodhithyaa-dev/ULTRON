---
id: entity_0368fe98042183b1
name: VertLie
type: operator
---

# VertLie

Operator of vertical degree 0 that takes the vertical Lie derivative of an expression with respect to a VVF

## Aliases

- None

## Sources

- [[chunk_93cfc67c265fcf32]]
