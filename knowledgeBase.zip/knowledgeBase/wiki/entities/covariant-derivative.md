---
id: entity_371e021559056864
name: Covariant derivative
type: concept
---

# Covariant derivative



## Aliases

- None

## Sources

- [[chunk_2627d7e62b253eb9]]
