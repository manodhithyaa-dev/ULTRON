---
id: entity_717fad07b8885df0
name: Self-driving cars
type: concept
---

# Self-driving cars

Autonomous vehicles that operate without human intervention

## Aliases

- Autonomous vehicles

## Sources

- [[chunk_a79eec0d0df34d5a]]
