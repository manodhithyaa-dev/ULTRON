---
id: entity_414b6ea3ec56021d
name: vertical forms
type: concept
---

# vertical forms

Forms defined on the space of fields (F) that have a vertical degree (a non-negative integer) in the context of the variational bicomplex.

## Aliases

- None

## Sources

- [[chunk_e93fcf82bb97b952]]
