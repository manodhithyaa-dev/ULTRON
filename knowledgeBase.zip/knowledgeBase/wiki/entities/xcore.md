---
id: entity_7e92ca7252fff23e
name: xCore
type: software
---

# xCore

Provides basic programming tools

## Aliases

- None

## Sources

- [[chunk_ed64c4baaa1d86e0]]
