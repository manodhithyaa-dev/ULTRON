---
id: entity_9289176b50661c4a
name: ExpandVertInt
type: method
---

# ExpandVertInt

Expands vertical integrals in xCPS

## Aliases

- None

## Sources

- [[chunk_ef20ecf5a069384d]]
