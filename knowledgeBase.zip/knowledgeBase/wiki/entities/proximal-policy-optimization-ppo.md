---
id: entity_8c22286e26f63d16
name: Proximal Policy Optimization (PPO)
type: algorithm
---

# Proximal Policy Optimization (PPO)

A reinforcement learning algorithm used for training the controller RNN with a learning rate of 0.00035.

## Aliases

- None

## Sources

- [[chunk_3f0df260b036f227]]
