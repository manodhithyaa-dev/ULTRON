---
id: entity_7b450a7c375f2d37
name: Proven in Use
type: concept
---

# Proven in Use

Legislative testing approach that validates self-driving car behavior through real-world usage data.

## Aliases

- None

## Sources

- [[chunk_9c0df650384be3e9]]
