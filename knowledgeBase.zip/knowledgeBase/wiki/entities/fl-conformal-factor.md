---
id: entity_d1423fdc745c896b
name: FL conformal factor
type: concept
---

# FL conformal factor

The conformal factor in the Friedmann-Lemaître-Robertson-Walker metric that governs the cosmic expansion dynamics

## Aliases

- None

## Sources

- [[chunk_ebd72db35a75d12f]]
- [[chunk_eff3056d091d58b8]]
