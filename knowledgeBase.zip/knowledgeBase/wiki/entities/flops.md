---
id: entity_a785c8e729665f25
name: FLOPS
type: metric
---

# FLOPS

Floating point operations per second, a measure of computational complexity

## Aliases

- None

## Sources

- [[chunk_684b65a2e79e2632]]
