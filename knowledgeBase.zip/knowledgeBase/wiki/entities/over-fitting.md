---
id: entity_a1f32f577f69843e
name: Over-fitting
type: problem
---

# Over-fitting



## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
