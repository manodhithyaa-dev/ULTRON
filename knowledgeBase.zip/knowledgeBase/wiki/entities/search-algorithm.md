---
id: entity_b9b1ffc748a62557
name: Search Algorithm
type: concept
---

# Search Algorithm

An optimization procedure for selecting the most effective sub-policy from the search space during data augmentation

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
