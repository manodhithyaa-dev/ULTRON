---
id: entity_893e32bb42f95d4f
name: Time-dependent mass function
type: concept
---

# Time-dependent mass function

A function m_app(t) that varies with time and is used in the non-minimal substitution to modify the Klein-Gordon equation.

## Aliases

- m_app(t)

## Sources

- [[chunk_02600ac7cd921f73]]
