---
id: entity_e685f93cd5ba442c
name: Black-Box Models
type: concept
---

# Black-Box Models

Machine learning models whose internal decision-making processes are opaque and difficult to interpret (e.g., deep neural networks).

## Aliases

- black box models

## Sources

- [[chunk_42086042ea3e3878]]
- [[chunk_e462f399bda26deb]]
