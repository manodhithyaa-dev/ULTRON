---
id: entity_50f4077b0c1a857a
name: vertical degree
type: concept
---

# vertical degree

A non-negative integer that characterizes a vertical form (on the space of fields) in the variational bicomplex, representing the degree in the fiber direction.

## Aliases

- None

## Sources

- [[chunk_e93fcf82bb97b952]]
