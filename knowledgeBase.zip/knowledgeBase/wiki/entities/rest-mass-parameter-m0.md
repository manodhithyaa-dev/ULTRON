---
id: entity_37e02e46b49fb627
name: rest-mass parameter m0
type: concept
---

# rest-mass parameter m0

The rest mass parameter in the apparent-mass formulation

## Aliases

- None

## Sources

- [[chunk_5bee8704fbb3d22a]]
