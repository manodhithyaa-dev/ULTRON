---
id: entity_aaa9402664f1a41f
name: h
type: concept
---

# h

the slow variable that is approximately constant over one optical period

## Aliases

- None

## Sources

- [[chunk_d7f50f0b6342180c]]
