---
id: entity_6cdf6c495b06911a
name: component index shift
type: concept
---

# component index shift

The shift in quantum number index between upper and lower components of a fermionic oscillator

## Aliases

- None

## Sources

- [[chunk_eff3056d091d58b8]]
