---
id: entity_7eb21968c95bf5f9
name: Erasing
type: method
---

# Erasing

An image enhancement technique that randomly removes portions of the image to simulate occlusion and improve robustness

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
