---
id: entity_00211591ce366b87
name: LIMA
type: concept
---

# LIMA

Local Interpretable Model-Agnostic, a technique for explainability.

## Aliases

- None

## Sources

- [[chunk_a9ae9e011fe6a4b5]]
