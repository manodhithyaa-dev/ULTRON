---
id: entity_ebea8870e15a9b40
name: xAct
type: software
---

# xAct

A software package for tensor computations in general relativity, used for variational calculus and differential geometry.

## Aliases

- None

## Sources

- [[chunk_4cde0069872070d4]]
- [[chunk_7fc911e7e45dd3bc]]
- [[chunk_95ad35faeea20af6]]
- [[chunk_ce59fe25a0aef320]]
- [[chunk_e93fcf82bb97b952]]
- [[chunk_ed64c4baaa1d86e0]]
