---
id: entity_99abaadbd7e96105
name: FEM
type: technology
---

# FEM

Feature Enhancement Module, a component of AF-FPN that enhances feature representation and accelerates inference

## Aliases

- None

## Sources

- [[chunk_72fb204c4a8e4af5]]
