---
id: entity_8f1be318bd2ebbfa
name: SortVertOperators
type: command
---

# SortVertOperators

Command that rewrites expressions containing nested vertical operators

## Aliases

- None

## Sources

- [[chunk_93cfc67c265fcf32]]
