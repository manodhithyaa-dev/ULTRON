---
id: entity_cd881f8e09c85c65
name: DeformedDispersionRelation
type: concept
---

# DeformedDispersionRelation

The deformed relativistic dispersion relation with a time-dependent apparent mass mapp(t), given by (E^2 - p^2 c^2) * (1 + c t / R)^2 = m0^2 c^4.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
- [[chunk_a67e3fb64382c786]]
