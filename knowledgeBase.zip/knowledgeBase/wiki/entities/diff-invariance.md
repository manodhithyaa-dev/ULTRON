---
id: entity_63fc990f8bd71684
name: Diff-invariance
type: concept
---

# Diff-invariance

The property that an action is invariant under all diffeomorphisms

## Aliases

- None

## Sources

- [[chunk_7fc911e7e45dd3bc]]
