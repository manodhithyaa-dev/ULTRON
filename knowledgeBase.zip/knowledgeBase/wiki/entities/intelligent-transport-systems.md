---
id: entity_8174dbae8b611cc1
name: Intelligent Transport Systems
type: technology
---

# Intelligent Transport Systems

Integrated networks for real-time traffic management and vehicle coordination

## Aliases

- ITS

## Sources

- [[chunk_a79eec0d0df34d5a]]
