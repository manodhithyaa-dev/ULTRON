---
id: entity_1f83849e2f0b5122
name: NoetherCurrent
type: method
---

# NoetherCurrent

A function in xCPS that computes the Noether current for a given vector field symmetry.

## Aliases

- None

## Sources

- [[chunk_291b614e7fe8c857]]
- [[chunk_ca6e0f0ccb183a63]]
