---
id: entity_6cf67a5c3ffd9253
name: Mosaic augmentation
type: method
---

# Mosaic augmentation



## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
