---
id: entity_7aba4c807ca612e9
name: AutoAugment
type: algorithm
---

# AutoAugment

A data augmentation strategy that automatically selects and applies augmentation operations to improve model training and robustness.

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_9c3f4e4df2cea03a]]
