---
id: entity_7412788848bd4c38
name: symplectic potential
type: concept
---

# symplectic potential



## Aliases

- None

## Sources

- [[chunk_a2a2c117fbd51e0e]]
