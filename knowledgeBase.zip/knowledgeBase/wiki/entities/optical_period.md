---
id: entity_e7696c810eb5c101
name: optical_period
type: concept
---

# optical_period

the period of an optical electromagnetic wave

## Aliases

- None

## Sources

- [[chunk_d7f50f0b6342180c]]
