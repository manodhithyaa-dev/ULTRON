---
id: entity_523159f9dd41b69d
name: Geometric transformation
type: method
---

# Geometric transformation



## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
