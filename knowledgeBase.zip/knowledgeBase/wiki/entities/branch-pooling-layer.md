---
id: entity_fb8a1577cf1f131d
name: branch pooling layer
type: method
---

# branch pooling layer

A neural network layer that fuses information from different parallel branches to avoid additional parameters, using averaging to balance representation during training and enable single branch inference during test.

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
- [[chunk_a6910cfa85bfae99]]
