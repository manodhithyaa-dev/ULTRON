---
id: entity_70fff5d06649e5cb
name: Landau–Lifshitz equation
type: concept
---

# Landau–Lifshitz equation

Classical equation for the motion of an electron in an electromagnetic field with radiation reaction

## Aliases

- None

## Sources

- [[chunk_1b53e9e1f246ee35]]
- [[chunk_ac52788834dd3fee]]
