---
id: entity_f44682583b2543ea
name: comoving observer
type: concept
---

# comoving observer



## Aliases

- None

## Sources

- [[chunk_ebd72db35a75d12f]]
