---
id: entity_1e2801743450ed13
name: (pre)symplectic form
type: concept
---

# (pre)symplectic form



## Aliases

- None

## Sources

- [[chunk_a2a2c117fbd51e0e]]
