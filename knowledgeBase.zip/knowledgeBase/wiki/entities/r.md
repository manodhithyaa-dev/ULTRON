---
id: entity_454349e422f05297
name: R
type: concept
---

# R

A cosmological scale parameter related to the Hubble constant.

## Aliases

- None

## Sources

- [[chunk_9c337835bc05bd25]]
