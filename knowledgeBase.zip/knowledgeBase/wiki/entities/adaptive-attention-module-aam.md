---
id: entity_74cb5796925d6b62
name: Adaptive attention module (AAM)
type: method
---

# Adaptive attention module (AAM)

A module used in AF-FPN to reduce information loss

## Aliases

- None

## Sources

- [[chunk_cded9156b67eb4fe]]
