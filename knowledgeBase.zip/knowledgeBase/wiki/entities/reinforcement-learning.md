---
id: entity_f85d2769bba3ba88
name: Reinforcement Learning
type: method
---

# Reinforcement Learning

A machine learning paradigm used as the search algorithm for finding an optimal data augmentation policy.

## Aliases

- None

## Sources

- [[chunk_3f0df260b036f227]]
