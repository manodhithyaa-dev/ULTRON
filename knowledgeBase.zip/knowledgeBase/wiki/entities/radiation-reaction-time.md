---
id: entity_a7de0044c0d5fb77
name: Radiation reaction time
type: concept
---

# Radiation reaction time

Parameter τR = 2e²/(3m) in the Landau-Lifshitz equation, representing the characteristic time scale for radiation reaction

## Aliases

- None

## Sources

- [[chunk_ac52788834dd3fee]]
