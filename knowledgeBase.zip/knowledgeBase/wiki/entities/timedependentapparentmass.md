---
id: entity_81cf535d38f7cda5
name: TimeDependentApparentMass
type: concept
---

# TimeDependentApparentMass

A mass parameter that depends on time, denoted as mapp(t), appearing in the deformed dispersion relation.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
- [[chunk_a67e3fb64382c786]]
