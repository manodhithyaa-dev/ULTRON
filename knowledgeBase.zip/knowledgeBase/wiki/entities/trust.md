---
id: entity_f796e2f28ae58117
name: TRUST
type: method
---

# TRUST

A method for generating trustworthy explanations in machine learning models, particularly for security applications.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
