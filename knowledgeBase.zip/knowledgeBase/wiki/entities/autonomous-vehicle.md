---
id: entity_2c596d13fa5b2f75
name: Autonomous vehicle
type: concept
---

# Autonomous vehicle

Self-driving cars that operate without human intervention.

## Aliases

- self-driving car

## Sources

- [[chunk_85348f42361b0fcb]]
- [[chunk_9c0df650384be3e9]]
