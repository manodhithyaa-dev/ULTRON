---
id: entity_25e36e9e1e12109f
name: Vertical exterior calculus
type: concept
---

# Vertical exterior calculus

A mathematical framework for computing symplectic currents

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
