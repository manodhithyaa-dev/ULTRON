---
id: entity_29d25ab1acb4315e
name: Klein–Gordon oscillator
type: concept
---

# Klein–Gordon oscillator

A one-dimensional quantum mechanical oscillator system defined by applying the non-minimal substitution to the Klein-Gordon equation.

## Aliases

- KG oscillator

## Sources

- [[chunk_02600ac7cd921f73]]
- [[chunk_e63ffee1aa270b16]]
- [[chunk_eff3056d091d58b8]]
