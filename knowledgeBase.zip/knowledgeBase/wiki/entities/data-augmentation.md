---
id: entity_c0e0465333ac57d1
name: Data augmentation
type: method
---

# Data augmentation

A data preprocessing technique used to improve model performance

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_684b65a2e79e2632]]
