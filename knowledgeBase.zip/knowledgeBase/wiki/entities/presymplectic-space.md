---
id: entity_a2b1234de88b33d0
name: Presymplectic space
type: concept
---

# Presymplectic space

A space equipped with a presymplectic form that describes the solutions of a field theory

## Aliases

- None

## Sources

- [[chunk_dd078bcfbf16902a]]
