---
id: entity_885e8d4c686548d6
name: Ante-hoc
type: concept
---

# Ante-hoc

Explanations provided to a model during pre-training, in-training, or post-training phases.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
