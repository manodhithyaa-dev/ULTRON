---
id: entity_13d451d518ee3b3b
name: Feature Pyramid Network
type: algorithm
---

# Feature Pyramid Network

A multi-scale feature fusion method used in object detection to improve recognition of multi-scale targets.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
