---
id: entity_6c86db5490124317
name: Cosmological scale factor
type: parameter
---

# Cosmological scale factor



## Aliases

- None

## Sources

- [[chunk_2f4bf355cc1e4c3a]]
