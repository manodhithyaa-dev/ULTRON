---
id: entity_ca4a8e1c2dec8837
name: ExpandVertDiff
type: method
---

# ExpandVertDiff

Expands vertical derivatives in xCPS

## Aliases

- None

## Sources

- [[chunk_ef20ecf5a069384d]]
