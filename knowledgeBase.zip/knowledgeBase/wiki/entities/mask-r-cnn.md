---
id: entity_774b30710ae9c753
name: Mask R-CNN
type: algorithm
---

# Mask R-CNN

A model that uses Feature Pyramid Network for object detection and segmentation.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
