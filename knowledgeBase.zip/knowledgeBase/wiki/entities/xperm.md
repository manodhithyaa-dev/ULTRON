---
id: entity_c6d0a23e9f7d1264
name: xPerm
type: software
---

# xPerm

Handles index canonicalization under permutation symmetries

## Aliases

- None

## Sources

- [[chunk_ed64c4baaa1d86e0]]
