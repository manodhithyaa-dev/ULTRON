---
id: entity_fc7a25b911cde43f
name: Roboethics
type: concept
---

# Roboethics

Ethical framework specifically addressing autonomous vehicle decision-making

## Aliases

- None

## Sources

- [[chunk_85348f42361b0fcb]]
