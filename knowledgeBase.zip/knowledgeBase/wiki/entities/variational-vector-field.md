---
id: entity_cb6d61add9f82721
name: Variational vector field
type: concept
---

# Variational vector field

A scalar expression where each monomial contains exactly one variational vector, used in the context of general relativity

## Aliases

- None

## Sources

- [[chunk_6b5cd986172c2fdb]]
