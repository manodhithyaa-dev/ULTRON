---
id: entity_a61de438b0c5834d
name: Conformal factor
type: concept
---

# Conformal factor

A position-dependent scaling factor that modifies the metric structure in curved spacetime or momentum space.

## Aliases

- None

## Sources

- [[chunk_4f67ec1ef93df0cb]]
- [[chunk_6fd387c20105d5de]]
