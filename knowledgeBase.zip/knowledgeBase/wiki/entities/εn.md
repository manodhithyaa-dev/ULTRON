---
id: entity_1b16b1df538ba12d
name: εn
type: parameter
---

# εn

A parameter that varies slowly over many cycles.

## Aliases

- None

## Sources

- [[chunk_04c37ffbc21d6f15]]
