---
id: entity_c112b3c06e9ed112
name: RCIoU
type: concept
---

# RCIoU

Region Center Intersection over Union penalty term

## Aliases

- None

## Sources

- [[chunk_3b65ae6547611187]]
