---
id: entity_8e41e925da60505f
name: AAM
type: technology
---

# AAM

Adaptive Attention Module, a component of AF-FPN that uses adaptive pooling and spatial attention to fuse multi-scale context features

## Aliases

- None

## Sources

- [[chunk_72fb204c4a8e4af5]]
