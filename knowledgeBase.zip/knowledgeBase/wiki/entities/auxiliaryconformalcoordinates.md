---
id: entity_f039b354e76e62fb
name: AuxiliaryConformalCoordinates
type: concept
---

# AuxiliaryConformalCoordinates

Conformal coordinates (T, ⃗X) defined by T = t/(1 + ct/R) and ⃗: r/(1 + ct/R) that absorb explicit time dependence.

## Aliases

- None

## Sources

- [[chunk_98693b57e4ac9c89]]
