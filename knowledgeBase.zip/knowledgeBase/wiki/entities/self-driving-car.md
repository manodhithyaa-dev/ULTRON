---
id: entity_f1e7829f9addf498
name: Self-driving car
type: concept
---

# Self-driving car



## Aliases

- None

## Sources

- [[chunk_93969288f13880ae]]
