---
id: entity_eeb44a5d2c2f7f71
name: Damping factor
type: concept
---

# Damping factor



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
