---
id: entity_9c573131f4e3fd8c
name: KDD benchmark dataset
type: dataset
---

# KDD benchmark dataset

A well-known dataset used in machine learning research for intrusion detection and security applications.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
