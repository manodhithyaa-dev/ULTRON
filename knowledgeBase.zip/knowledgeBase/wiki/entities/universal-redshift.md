---
id: entity_daecd4f07d0f8e38
name: universal redshift
type: concept
---

# universal redshift

The cosmological redshift parameter that is removed to isolate the apparent rest mass effect in spectral line ratios

## Aliases

- None

## Sources

- [[chunk_eff3056d091d58b8]]
