---
id: entity_9b09f598d5ff8127
name: field-space wedge product
type: concept
---

# field-space wedge product

A bilinear supergraded product (denoted as WWedge) for vertical forms, defined as α ∧ β = (-1)^(VertDeg[α] * VertDeg[β]) β ∧ α.

## Aliases

- None

## Sources

- [[chunk_e93fcf82bb97b952]]
