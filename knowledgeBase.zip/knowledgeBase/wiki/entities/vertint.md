---
id: entity_f3e6385e5873d9de
name: VertInt
type: operator
---

# VertInt

Operator of vertical degree -1 that takes the vertical interior product of an expression with a VVF

## Aliases

- None

## Sources

- [[chunk_93cfc67c265fcf32]]
