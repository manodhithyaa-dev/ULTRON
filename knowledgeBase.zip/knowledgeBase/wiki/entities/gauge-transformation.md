---
id: entity_76a8cb308c241f00
name: gauge transformation
type: concept
---

# gauge transformation

A transformation that preserves the gauge symmetry of the Lagrangian

## Aliases

- None

## Sources

- [[chunk_7fc911e7e45dd3bc]]
