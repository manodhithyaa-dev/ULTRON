---
id: entity_b8a3087710e22e32
name: Explainability
type: concept
---

# Explainability

The ability to provide information about the inner workings of the model.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
