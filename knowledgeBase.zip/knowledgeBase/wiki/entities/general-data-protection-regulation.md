---
id: entity_4c68ea3147b49025
name: General Data Protection Regulation
type: regulation
---

# General Data Protection Regulation



## Aliases

- None

## Sources

- [[chunk_1bf0ce6f194b3f80]]
