---
id: entity_8074db86033c5ca5
name: Lightfront momentum
type: concept
---

# Lightfront momentum

Momentum ρ(ϕ) defined as ρ(ϕ) = n · u(ϕ), where n is a vector and u(ϕ) is a dynamical field

## Aliases

- None

## Sources

- [[chunk_1b53e9e1f246ee35]]
- [[chunk_5452b9712845e4c4]]
- [[chunk_bd172296bfb8a046]]
