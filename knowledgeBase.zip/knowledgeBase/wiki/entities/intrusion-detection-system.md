---
id: entity_970bf316ccb78c48
name: Intrusion Detection System
type: technology
---

# Intrusion Detection System

A system for detecting unauthorized access to computer networks and security breaches.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
