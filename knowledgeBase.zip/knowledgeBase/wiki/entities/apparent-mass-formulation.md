---
id: entity_391703e44be2f086
name: apparent-mass formulation
type: method
---

# apparent-mass formulation

A formulation that retains the explicit rest-mass parameter m0

## Aliases

- None

## Sources

- [[chunk_5bee8704fbb3d22a]]
