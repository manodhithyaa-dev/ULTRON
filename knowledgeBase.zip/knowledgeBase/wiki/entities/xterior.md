---
id: entity_0ee198b8d2df0d55
name: xTerior
type: software
---

# xTerior

A Mathematica package that implements the horizontal wedge product of horizontal forms.

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
- [[chunk_e93fcf82bb97b952]]
