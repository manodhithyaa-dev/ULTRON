---
id: entity_7a09aa8b47d4929a
name: VVF
type: concept
---

# VVF

Vertical vector field

## Aliases

- None

## Sources

- [[chunk_93cfc67c265fcf32]]
