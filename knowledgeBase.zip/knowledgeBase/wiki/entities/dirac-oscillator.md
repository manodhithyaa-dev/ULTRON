---
id: entity_4a9a0af016880b17
name: Dirac oscillator
type: concept
---

# Dirac oscillator

A quantum mechanical oscillator for fermions described by the Dirac equation

## Aliases

- None

## Sources

- [[chunk_2f4bf355cc1e4c3a]]
- [[chunk_e63ffee1aa270b16]]
- [[chunk_eff3056d091d58b8]]
