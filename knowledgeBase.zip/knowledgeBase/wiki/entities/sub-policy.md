---
id: entity_f401f5348910d0ea
name: Sub-policy
type: concept
---

# Sub-policy

A sequence of two image enhancement operations applied in a specific order to transform input data

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
