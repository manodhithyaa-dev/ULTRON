---
id: entity_694d68371711f183
name: CIoU
type: concept
---

# CIoU

Center Intersection over Union loss function for object detection

## Aliases

- None

## Sources

- [[chunk_3b65ae6547611187]]
