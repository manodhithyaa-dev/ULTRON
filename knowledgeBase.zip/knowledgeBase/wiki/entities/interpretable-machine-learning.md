---
id: entity_c35b71bfc0f4dac9
name: Interpretable Machine Learning
type: concept
---

# Interpretable Machine Learning

A subset of XAI that focuses on describing the logic of machine learning algorithms.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
