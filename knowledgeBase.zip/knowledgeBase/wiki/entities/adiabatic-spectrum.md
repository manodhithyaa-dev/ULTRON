---
id: entity_89261c4963dfe9e6
name: Adiabatic spectrum
type: concept
---

# Adiabatic spectrum

The time-evolving spectrum resulting from adiabatic processes.

## Aliases

- None

## Sources

- [[chunk_9c337835bc05bd25]]
