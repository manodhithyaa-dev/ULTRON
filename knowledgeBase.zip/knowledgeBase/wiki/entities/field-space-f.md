---
id: entity_0bf2d1145ec255af
name: Field space (F)
type: concept
---

# Field space (F)

The space of all field configurations

## Aliases

- None

## Sources

- [[chunk_dd078bcfbf16902a]]
