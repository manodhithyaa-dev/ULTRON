---
id: entity_b374384d897e91ef
name: Lorentz transformations
type: concept
---

# Lorentz transformations

Standard transformations in special relativity that preserve spacetime intervals.

## Aliases

- None

## Sources

- [[chunk_7b3621d89bf94a88]]
