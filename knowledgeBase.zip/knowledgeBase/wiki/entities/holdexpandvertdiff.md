---
id: entity_7c9e769ea1f38d77
name: HoldExpandVertDiff
type: other
---

# HoldExpandVertDiff

Option for ExpandVertDiff to prevent deeper recursive expansion

## Aliases

- None

## Sources

- [[chunk_ef20ecf5a069384d]]
