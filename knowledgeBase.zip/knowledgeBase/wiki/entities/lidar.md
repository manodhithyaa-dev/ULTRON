---
id: entity_4263c537225041cb
name: LIDAR
type: hardware
---

# LIDAR

Laser-based sensor that delivers high-quality data in diverse weather conditions.

## Aliases

- None

## Sources

- [[chunk_93969288f13880ae]]
- [[chunk_9c0df650384be3e9]]
