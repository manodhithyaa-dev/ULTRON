---
id: entity_4c9905dd8e902ab1
name: momentum-space dualization
type: method
---

# momentum-space dualization



## Aliases

- None

## Sources

- [[chunk_6fd387c20105d5de]]
