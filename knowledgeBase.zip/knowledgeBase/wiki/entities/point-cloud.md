---
id: entity_6d4d52e8a1724288
name: Point cloud
type: concept
---

# Point cloud



## Aliases

- None

## Sources

- [[chunk_93969288f13880ae]]
