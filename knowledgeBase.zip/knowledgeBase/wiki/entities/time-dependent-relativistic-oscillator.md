---
id: entity_02d412cb4f4bb08f
name: time-dependent relativistic oscillator
type: concept
---

# time-dependent relativistic oscillator

a class of solvable quantum mechanical oscillators with time-dependent mass

## Aliases

- None

## Sources

- [[chunk_a67e3fb64382c786]]
