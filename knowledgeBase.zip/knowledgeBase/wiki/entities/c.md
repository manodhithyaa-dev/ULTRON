---
id: entity_2e7d2c03a9507ae2
name: c
type: concept
---

# c

The speed of light in vacuum, a fundamental physical constant.

## Aliases

- None

## Sources

- [[chunk_9c337835bc05bd25]]
