---
id: entity_3cf4d0dd722a3a42
name: Fock–Lorentz transformations
type: concept
---

# Fock–Lorentz transformations

Transformations in spacetime that are mapped to momentum space via a formal exchange of spacetime coordinates and four-momentum components.

## Aliases

- None

## Sources

- [[chunk_061056fb1524d2e7]]
- [[chunk_7b3621d89bf94a88]]
- [[chunk_e63ffee1aa270b16]]
