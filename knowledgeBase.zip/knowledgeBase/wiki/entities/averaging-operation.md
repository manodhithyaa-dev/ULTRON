---
id: entity_58ffec4dcbc4836a
name: averaging operation
type: method
---

# averaging operation

An operation that balances the representation of different parallel branches during training.

## Aliases

- None

## Sources

- [[chunk_a6910cfa85bfae99]]
