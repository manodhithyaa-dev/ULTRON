---
id: entity_31635ab7bd940e22
name: Gaunt factor
type: concept
---

# Gaunt factor

A dimensionless factor (g(χ) < 1) that quantifies the suppression of radiation reaction in the semiclassical regime, accounting for quantum effects in the particle's motion

## Aliases

- None

## Sources

- [[chunk_1b53e9e1f246ee35]]
- [[chunk_2d540758cb99f9d1]]
- [[chunk_ac52788834dd3fee]]
- [[chunk_f87d5a938aef8f03]]
