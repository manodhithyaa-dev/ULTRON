---
id: entity_a701a28ff0955f50
name: Dirac equation
type: concept
---

# Dirac equation

A relativistic wave equation for spin-1/2 particles that describes the behavior of fermions.

## Aliases

- Dirac equation

## Sources

- [[chunk_02600ac7cd921f73]]
