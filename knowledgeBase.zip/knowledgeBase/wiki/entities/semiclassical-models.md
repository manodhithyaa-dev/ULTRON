---
id: entity_cc0df4242b2ef557
name: Semiclassical models
type: concept
---

# Semiclassical models

Models that incorporate quantum effects in radiation reaction by multiplying radiation-reaction terms by the Gaunt factor

## Aliases

- None

## Sources

- [[chunk_ac52788834dd3fee]]
