---
id: entity_9247369ab1f2ec3b
name: LSTM
type: algorithm
---

# LSTM

Long Short-Term Memory, a type of recurrent neural network designed for sequential data processing.

## Aliases

- None

## Sources

- [[chunk_78335d7794f92aac]]
