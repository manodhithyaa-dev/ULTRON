---
id: entity_1678b75b0d674567
name: Bianchi identity
type: concept
---

# Bianchi identity

A set of identities in differential geometry that arise from the Riemann tensor and are used in gravitational theory

## Aliases

- None

## Sources

- [[chunk_222e71ef5df955c8]]
