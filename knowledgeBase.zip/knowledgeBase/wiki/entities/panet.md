---
id: entity_9e653e461b4ba5e5
name: PANet
type: software architecture
---

# PANet

Path Aggregation Network, a network architecture that shortens information paths between lower layers and the topmost feature

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_72fb204c4a8e4af5]]
