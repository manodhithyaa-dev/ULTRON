---
id: entity_efd38c017669e860
name: Model-agnostic
type: concept
---

# Model-agnostic

XAI methods that can be applied to any model type without model-specific constraints.

## Aliases

- None

## Sources

- [[chunk_4c99723739a79c4c]]
