---
id: entity_89e8b9518d922794
name: Camera
type: hardware
---

# Camera

Visual sensor that is less accurate and sensitive in adverse weather conditions.

## Aliases

- None

## Sources

- [[chunk_9c0df650384be3e9]]
