---
id: entity_80b1ee7db3927c47
name: Internet of Things
type: technology
---

# Internet of Things

Interconnected devices that enable data exchange between vehicles and infrastructure

## Aliases

- IoT

## Sources

- [[chunk_0417279e249039ed]]
- [[chunk_a79eec0d0df34d5a]]
