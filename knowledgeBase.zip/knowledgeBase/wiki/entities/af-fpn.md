---
id: entity_515b82a8aea6a980
name: AF-FPN
type: algorithm
---

# AF-FPN

Adaptive Feature Pyramid Network, a feature pyramid network architecture that adds adaptive attention and feature enhancement modules

## Aliases

- None

## Sources

- [[chunk_54e2a47d99b90d59]]
- [[chunk_684b65a2e79e2632]]
- [[chunk_72fb204c4a8e4af5]]
- [[chunk_cded9156b67eb4fe]]
