---
id: entity_e09ad88b3af6e6f0
name: apparent rest mass
type: concept
---

# apparent rest mass

The mass parameter in the model that varies with cosmic time and is denoted as mapp(t), influencing spectral line ratios

## Aliases

- None

## Sources

- [[chunk_eff3056d091d58b8]]
