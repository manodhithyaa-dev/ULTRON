---
id: entity_e7a483b41496a097
name: RiemannCurvatureTensor
type: tensor
---

# RiemannCurvatureTensor

The Riemann curvature tensor in general relativity, which quantifies the curvature of spacetime.

## Aliases

- None

## Sources

- [[chunk_a394da0626bbe4f2]]
