---
id: entity_19818c00e27a5381
name: Mosaic
type: method
---

# Mosaic

An image enhancement technique that combines multiple small patches into a larger mosaic to improve spatial resolution

## Aliases

- None

## Sources

- [[chunk_a324525c8c883cb0]]
