---
id: entity_07332037d5444d54
name: xActxCPS
type: software
---

# xActxCPS

A Mathematica-based package for tensor calculus and general relativity computations.

## Aliases

- None

## Sources

- [[chunk_ca6e0f0ccb183a63]]
