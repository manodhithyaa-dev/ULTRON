---
id: entity_f50e6d1bce6ee826
name: Semiclassical radiation reaction
type: concept
---

# Semiclassical radiation reaction



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
