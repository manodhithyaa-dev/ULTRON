---
id: entity_8e2daaf589c72644
name: SADANet
type: algorithm
---

# SADANet

A network that combines a domain adaptive network with a multi-scale prediction network to address scale variety in traffic sign detection.

## Aliases

- None

## Sources

- [[chunk_9c3f4e4df2cea03a]]
