---
id: entity_d0fd53ccd03c253b
name: VariationalRelationsOf
type: function
---

# VariationalRelationsOf

A function in xCPS that returns the subgraph of the VariationalGraph connected to a specified tensor.

## Aliases

- None

## Sources

- [[chunk_a394da0626bbe4f2]]
