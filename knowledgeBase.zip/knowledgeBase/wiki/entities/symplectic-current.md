---
id: entity_ffe24ee50deedfaf
name: symplectic current
type: concept
---

# symplectic current

A physical quantity arising from vertical exterior calculus

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
- [[chunk_a2a2c117fbd51e0e]]
