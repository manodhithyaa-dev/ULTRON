---
id: entity_efb5e4a10fefd315
name: NonConstantTensors
type: other
---

# NonConstantTensors

Option for ExpandVertDiff to specify dynamical tensors

## Aliases

- None

## Sources

- [[chunk_ef20ecf5a069384d]]
