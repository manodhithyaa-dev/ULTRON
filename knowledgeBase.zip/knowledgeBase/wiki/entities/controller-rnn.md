---
id: entity_9d7a14410e80a5df
name: Controller RNN
type: software
---

# Controller RNN

A recurrent neural network that predicts decisions via softmax to generate the data augmentation policy.

## Aliases

- None

## Sources

- [[chunk_3f0df260b036f227]]
