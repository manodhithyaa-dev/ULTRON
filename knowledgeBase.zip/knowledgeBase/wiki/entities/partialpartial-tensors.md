---
id: entity_667e0d8b7939ce63
name: PartialPartial tensors
type: concept
---

# PartialPartial tensors

A type of tensor used in the variational graph

## Aliases

- None

## Sources

- [[chunk_638a88d4afceb0d0]]
