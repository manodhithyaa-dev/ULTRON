---
id: entity_595942bfe65a9cec
name: ImplicitTensorDepQ
type: function
---

# ImplicitTensorDepQ

A built-in relation checker in xCPS for verifying tensor dependencies.

## Aliases

- None

## Sources

- [[chunk_a394da0626bbe4f2]]
