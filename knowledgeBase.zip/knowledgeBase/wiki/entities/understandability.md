---
id: entity_8fac451054e343a6
name: Understandability
type: concept
---

# Understandability

The ability to make a human grasp its function without needing to explain underlying structure or algorithms.

## Aliases

- Intelligibility

## Sources

- [[chunk_4c99723739a79c4c]]
