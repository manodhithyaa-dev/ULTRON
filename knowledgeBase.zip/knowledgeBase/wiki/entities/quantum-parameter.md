---
id: entity_7bdd1caee2eca908
name: Quantum parameter
type: concept
---

# Quantum parameter

A parameter in relativistic particle dynamics that is inversely proportional to the radiation loss parameter h (χ ∝ h⁻¹).

## Aliases

- None

## Sources

- [[chunk_1b53e9e1f246ee35]]
- [[chunk_5452b9712845e4c4]]
- [[chunk_c1565e0a8a3bcbfa]]
