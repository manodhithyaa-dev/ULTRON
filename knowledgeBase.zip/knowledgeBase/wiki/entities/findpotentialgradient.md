---
id: entity_18bfc9abeda40953
name: FindPotentialGradient
type: method
---

# FindPotentialGradient

Attempts to find the potential for a total divergence

## Aliases

- None

## Sources

- [[chunk_2627d7e62b253eb9]]
- [[chunk_ef20ecf5a069384d]]
