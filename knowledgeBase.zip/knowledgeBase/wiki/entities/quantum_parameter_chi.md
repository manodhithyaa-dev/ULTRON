---
id: entity_255dd50b4d62602b
name: quantum_parameter_chi
type: concept
---

# quantum_parameter_chi

A quantum parameter defined in the plane wave limit that quantifies the strength of quantum effects in the dissipation function, critical for distinguishing classical and semiclassical regimes.

## Aliases

- None

## Sources

- [[chunk_308333403693b741]]
