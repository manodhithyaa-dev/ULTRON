---
id: entity_d571e9e85972c970
name: Plane wave
type: field configuration
---

# Plane wave



## Aliases

- None

## Sources

- [[chunk_5452b9712845e4c4]]
