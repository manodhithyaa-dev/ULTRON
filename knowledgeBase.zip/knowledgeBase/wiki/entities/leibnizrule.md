---
id: entity_23cf7ca7c267c479
name: LeibnizRule
type: method
---

# LeibnizRule

A private command in xAct that improves upon VarD by handling total derivatives and Lie derivatives.

## Aliases

- None

## Sources

- [[chunk_4cde0069872070d4]]
