---
id: entity_a7cf4e8e497b6b98
name: Computer vision
type: method
---

# Computer vision



## Aliases

- None

## Sources

- [[chunk_93969288f13880ae]]
