---
id: entity_28aafeeb04ffd57d
name: Interpretability
type: concept
---

# Interpretability

The ability to extend a model or its predictions to be understandable by humans, expressed through transparency.

## Aliases

- model interpretability

## Sources

- [[chunk_4c99723739a79c4c]]
- [[chunk_e462f399bda26deb]]
