---
id: entity_04917211ddd8952c
name: Conformal group
type: concept
---

# Conformal group

A group of transformations that preserve angles and conformal properties in spacetime.

## Aliases

- None

## Sources

- [[chunk_7b3621d89bf94a88]]
