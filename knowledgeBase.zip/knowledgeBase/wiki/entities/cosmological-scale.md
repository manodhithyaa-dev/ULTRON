---
id: entity_a93e2f5217391082
name: cosmological scale
type: concept
---

# cosmological scale

The scale of deformation in the present framework (as opposed to Planckian)

## Aliases

- None

## Sources

- [[chunk_5bee8704fbb3d22a]]
