---
id: entity_e2185800857ba8a5
name: Lie derivative
type: concept
---

# Lie derivative

A differential operator that measures the change of a tensor field along a vector field

## Aliases

- None

## Sources

- [[chunk_6b5cd986172c2fdb]]
