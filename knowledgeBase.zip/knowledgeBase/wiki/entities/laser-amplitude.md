---
id: entity_1b4b0e65cd28acd4
name: Laser amplitude
type: concept
---

# Laser amplitude



## Aliases

- None

## Sources

- [[chunk_f87d5a938aef8f03]]
