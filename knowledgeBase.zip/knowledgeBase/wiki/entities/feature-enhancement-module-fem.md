---
id: entity_c99a9ad6d6b502a4
name: Feature enhancement module (FEM)
type: method
---

# Feature enhancement module (FEM)

A module used in AF-FPN to enhance feature representation

## Aliases

- None

## Sources

- [[chunk_cded9156b67eb4fe]]
