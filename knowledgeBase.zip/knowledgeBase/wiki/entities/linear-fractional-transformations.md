---
id: entity_f19b60afd3676eb7
name: linear-fractional transformations
type: method
---

# linear-fractional transformations

Mathematical transformations used to describe deformations of relativistic kinematics

## Aliases

- None

## Sources

- [[chunk_5bee8704fbb3d22a]]
