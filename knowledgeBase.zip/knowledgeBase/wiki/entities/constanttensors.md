---
id: entity_f4a3eaa25c0bdf89
name: ConstantTensors
type: other
---

# ConstantTensors

Option for ExpandVertDiff to specify constant tensors

## Aliases

- None

## Sources

- [[chunk_ef20ecf5a069384d]]
