---
id: entity_e7b7a4fcd2cecc79
name: high-level features
type: concept
---

# high-level features

Features extracted at higher levels of the network

## Aliases

- None

## Sources

- [[chunk_de02ffe72fca9186]]
