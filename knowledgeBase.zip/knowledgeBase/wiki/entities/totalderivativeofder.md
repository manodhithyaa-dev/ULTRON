---
id: entity_c8df962a902ee853
name: TotalDerivativeOfder
type: concept
---

# TotalDerivativeOfder

A linear InertHead in xAct used to prevent expansion of terms during variational calculations.

## Aliases

- None

## Sources

- [[chunk_4cde0069872070d4]]
