---
id: entity_2f02a4f7da5ad4d6
name: FPS
type: metric
---

# FPS

Frames per second, a measure of real-time performance

## Aliases

- None

## Sources

- [[chunk_684b65a2e79e2632]]
