---
id: entity_4a6111482c8b1bcf
name: adiabatic approximation
type: concept
---

# adiabatic approximation

an approximation method for time-dependent systems where the time scale is large

## Aliases

- None

## Sources

- [[chunk_a67e3fb64382c786]]
