---
id: entity_7bfed66f38a6f112
name: Vertical operator
type: concept
---

# Vertical operator

An operator in xCPS for handling vertical variations in general relativity

## Aliases

- VertBracket
- VertDiff
- VertInt
- VertLie

## Sources

- [[chunk_6b5cd986172c2fdb]]
