---
id: chunk_ebd72db35a75d12f
document: doc_4a9484dd924d39f9
heading: Page 8
start_paragraph: 14
end_paragraph: 15
---

# Page 8

## Page 8

The integration constant m2
0c4 is identified with the squared rest energy at t = 0 in the
cosmological frame. Equation (13) constitutes the central kinematical relation of this work.
Its derivation rests on two ingredients: the multiplicative structure of Eq. (11) and the
transformation rule (12) governing the FL conformal factor. Since the latter is precisely the
rule that controls the position-dependent metric in the original FL construction, the dual
Casimir invariant inherits its geometric origin.
C.
Apparent mass and physical interpretation
It is convenient to rewrite Eq. (13) as the standard relativistic dispersion relation with a
time-dependent rest mass:
E2 −p2c2 = m2
app(t) c4,
mapp(t) ≡
m0
1 + ct/R.
(14)
The function mapp(t) decreases monotonically for t > 0, is equal to m0 at t = 0, and vanishes
as t →∞(see Fig. 2). For |t| ≪R/c,
mapp(t) ≈m0

1 −ct
R + c2t2
R2 −· · ·

,
(15)
so that the leading correction is linear in t with coefficient −m0c/R. With R ∼c/H0, this
corresponds to a fractional mass drift |
˙
mapp/mapp| ∼H0 ≈2.3 × 10−18 s−1. The apparent-
mass interpretation therefore provides a direct bridge between the geometric deformation
encoded in the FL conformal factor and ordinary relativistic quantum mechanics with a
slowly varying mass parameter.
D.
World-line restriction and covariance status
The reduction to x = 0 is a physical restriction rather than a mere notational convenience.
In the full FL map, the conformal factor depends on both time and position. Evaluating it on
a preferred cosmological world line is analogous to employing cosmic time in a homogeneous
cosmological model: the prescription is operationally well defined for a comoving observer,
but it does not constitute a fully covariant phase-space theory. Accordingly, the quantity
mapp(t) should be interpreted as the rest-mass scale inferred by such an observer when the
dynamics is expressed in the original FL laboratory variables.
8
