---
id: chunk_93cfc67c265fcf32
document: doc_6ac2027a878dbe19
heading: Page 13
start_paragraph: 25
end_paragraph: 26
---

# Page 13

## Page 13

4.3.2
VertInt
VertInt is an operator of vertical degree −1 that takes the vertical interior product of an expression
with a VVF. It automatically applies the following rules:
1. It is linear and distributes over products using the Leibniz rule
iVVF(α ∧β) = (iVVFα) ∧β + (−1)VertDeg[iVVF]VertDeg[α]α ∧(iVVFβ)
2. iVVFα = 0 if VertDeg[α]=0.
If VVF is an unresolved symbol, the output contains unevaluated terms of the form VertInt[VVF]@T a
b
When VVF is an explicit expression such as equation (25), the terms can be further simplified using
ExpandVertInt, as we will see in subsection 4.6.
4.3.3
VertLie
VertLie is an operator of vertical degree 0 that takes the vertical Lie derivative of an expression
with respect to a VVF. It automatically applies the following rules:
1. It is linear and distributes over products using the Leibniz rule
LVVF(α ∧β) = (LVVFα) ∧β + (−1)VertDeg[VVF]VertDeg[α]α ∧(LVVFβ)
2. VertLie[VVF][δ b
a ]=0 (since the Kronecker delta is non-dynamical).
Cartan’s magic formula relates VertLie to VertDiff and VertInt, and is implemented via
SortVertOperators as explained below.
4.3.4
VertBracket
VertBracket represents the vertical Lie bracket of VVF1 and VVF2. It automatically applies the
following rules:
1. It is bilinear and satisfies the super-anticommutative property (lexicographical order):
JVVF2, VVF1K = −(−1)VertDeg[VVF1]VertDeg[VVF2]JVVF1, VVF2K
2. JVVF,VVFK=0 if VertDeg[VVF] is even.
4.3.5
SortVertOperators, VertCartanMagicFormula, and VertBracketToVertLie
These three commands rewrite expressions containing nested vertical operators in terms of the
others. To understand how, first notice that there are six possible super-commutators between L, i,
and d, defined as:
[P, Q] = PQ −(−1)VertDeg[P]VertDeg[Q]QP
(27)
Under appropriate conditions on the vector fields (they are prolongations of evolutionary vector
fields, see for instance [1, 1.16,1.17,3.17,3.26]), their result can be written in terms of {L, i, d}:
[Lvvf1, Lvvf2] = LJvvf1,vvf2K
[Lvvf1, ivvf2] = iJvvf1,vvf2K
[Lvvf, d] = 0
[ivvf1, ivvf2] = 0
[ivvf, d] = Lvvf
[d, d] = 0
The last one is d2 = 0, which is implemented automatically. Whenever other operators are nested, we
can sort them out using SortVertOperators according to a specified sorting order {P, Q, R} (which
can be parsed as an argument or defined globally via $SortVertOperatorsOrder). The command
SortVertOperators (analogous to SortDerivationsRule of xTerior) applies equation (27) to
13
