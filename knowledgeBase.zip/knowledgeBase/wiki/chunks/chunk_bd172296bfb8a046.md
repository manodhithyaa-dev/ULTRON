---
id: chunk_bd172296bfb8a046
document: doc_309e7c4d59ff81df
heading: Page 6
start_paragraph: 10
end_paragraph: 11
---

# Page 6

## Page 6

6
The field tensor then takes the form
F µν(ϕ) = fµν
j ψ′
j(ϕ),
(7)
where a prime denotes differentiation with respect to ϕ and fµν
j
= nµaν
j −nνaµ
j .
It is convenient to introduce dimensionless amplitudes
ξ2
j = −
e2a2
j
m2 ,
(8)
with a2 < 0, so that (ξjψ′
j)2 measures the local field strength.
C.
Evolution with respect to phase
Since F µν depends only on ϕ, it is advantageous to use ϕ as evolution parameter. Using
d
ds = (n · u) d
dϕ,
Eq. (5) becomes
mduµ
dϕ =
1
n · u

eF µνuν + τRg(χ)

e∂αF µνuαuν −e2
mF µνFανuα + e2
m(F αβuβFαγuγ)uµ

.
(9)
D.
Light-front momentum and decoupling
We now introduce the light-front momentum
ρ(ϕ) = n · u(ϕ).
(10)
Using the plane-wave identities
F µνnν = 0,
(11)
F µνFνα = −(ajψ′
j)2nµnα,
(12)
one finds
(F αβuβ)(Fαγuγ) = −ρ2(ajψ′
j)2.
(13)
Contracting Eq. (9) with nµ, all Lorentz-force terms vanish due to transversality, and the
equation reduces to a scalar evolution equation:
d
dϕ
1
ρ

= τRg(χ)(ξjψ′
j)2.
(14)
This equation is exact and fully decoupled from transverse components. It is the central structural
property responsible for integrability.
