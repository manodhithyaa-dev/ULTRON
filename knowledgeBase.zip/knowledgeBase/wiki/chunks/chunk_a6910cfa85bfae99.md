---
id: chunk_a6910cfa85bfae99
document: doc_604e4dcb676808b0
heading: Document
start_paragraph: 33
end_paragraph: 36
---

# Document



1
1
1




r
d
k

(7)



1
1





n
n
r
d
k
r

(8)
where k and ri denote the kernel size and dilation rate, 
respectively. And d denote the stride of the convolution. 
The branch pooling layer [43] is proposed to fuse 
information from different parallel branches and avoid 
introducing additional parameters. The averaging 
operation is utilized to balance the representation of 
different parallels branches during training, which 
enables a single branch to implement inference during 
the test. The expression is as follows:
