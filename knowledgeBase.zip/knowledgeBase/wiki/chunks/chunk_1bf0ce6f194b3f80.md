---
id: chunk_1bf0ce6f194b3f80
document: doc_27960becbcfef01d
heading: Page 11
start_paragraph: 20
end_paragraph: 21
---

# Page 11

## Page 11

Ethical and Social Aspects of Self-Driving Cars
ARXIV’18, January 2018, Gothenburg, Sweden
Applications Conference, volume 2, pages 39–44, July 2015.
[61] Toyota. New toyota test vehicle paves the way for commercialization of auto-
mated highway driving technologies | toyota global newsroom, 2015.
[62] S. Wachter, B. Mittelstadt, and L. Floridi. Why a right to explanation of auto-
mated decision-making does not exist in the general data protection regulation.
International Data Privacy Law, 7(2):76–99, 2017.
[63] M. M. Waldrop. Autonomous vehicles: No drivers required. Nature, 518:20–3,
2015.
[64] Waymo. Technology - Waymo, 2017. https://waymo.com/tech/.
[65] Waymo. Waymo, September 2017. https://waymo.com.
[66] P. Wintersberger, A. K. Prison, A. Riener, and S. Hasirlioglu. The experience
of ethics: Evaluation of self harm risks in automated vehicles. In 2017 IEEE
Intelligent Vehicles Symposium (IV), pages 385–391, June 2017.
