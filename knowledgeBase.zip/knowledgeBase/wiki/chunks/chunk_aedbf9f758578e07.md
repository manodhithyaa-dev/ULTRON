---
id: chunk_aedbf9f758578e07
document: doc_a8343f0236b29082
heading: Page 5
start_paragraph: 8
end_paragraph: 9
---

# Page 5

## Page 5

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
5
Fig. 3. The methodologies of XAI
a loan application approval algorithm, such as completely
rejecting applications from a particular location, group, or
race. XAI provides a guideline for revealing these biases
in the model.
IV. XAI IN IOT APPLICATION DOMAINS
In this section, we aim to provide a comprehensive
overview/review of XAI studies in IoT application domains.
For this purpose, we review the studies presented in the
literature and summarize them in Table I in accordance with
the XAI terminology and taxonomy.
A. Autonomous Systems and Robotics
In autonomous and robotics domain, AI-powered robots can
perform tasks in critical and dangerous environments that hu-
mans cannot perform, or typical applications such as welding,
ironing, painting, equipment placing/receiving and palletizing,
all of which are performed with high strength, speed and
accuracy [49]. On the other hand, XAI algorithms make
robots’ reasoning explainable by humans, providing a better
understanding of decisions and increasing the level of trust
in robots. Wang et al. [50] developed a new mechanism for
robots to automatically generate explanations of their decisions
based on Partially Observable Markov Decision Problems
(POMDPs). They measured the performance of this mecha-
nism in an agent-based test environment that simulates the
tasks of a human-robot team. Experimental results show that
robot explanations can improve task performance and improve
trust and transparency. For robot explainability, the authors
created a four-level natural language template including no
explanation, explanation of two sensor readings, explanation
of three sensor readings, and conﬁdence-level explanation. In
this way, robots are enabled to produce text explanations based
on postdoc techniques related to their decision processes.
Iyer et al. [51] proposed an explainable and object-sensitive
deep reinforcement learning (DRL) model for the object
recognition and classiﬁcation problem. In the proposed model,
the authors used a method that focuses on "object saliency
maps" to provide human-intelligible visualization of DRLs
states and actions. Kampik et al. [52] used text-based ex-
plainability approaches to explain the human-like actions of
autonomous agents in human-robot interaction scenarios. The
authors demonstrate the impact of the developed approaches
on human participants through a study based on human-robot
ultimatum games.
Guo [53] proposed the Double Dueling Deep Q-learning
Neural Network (DDDQN) network for the quality of service
(QoS), Quality-of-Experience (QoE), and energy optimization
of the UAVs in the UAV-supported 5G network. In the
study, partial explainability is provided by extracting the state
weights of the proposed DDDQN network.
