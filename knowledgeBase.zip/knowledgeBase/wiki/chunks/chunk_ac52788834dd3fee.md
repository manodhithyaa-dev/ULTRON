---
id: chunk_ac52788834dd3fee
document: doc_309e7c4d59ff81df
heading: Page 4
start_paragraph: 6
end_paragraph: 7
---

# Page 4

## Page 4

4
The electron four-velocity is denoted by uµ = dxµ/ds, where s is the proper time, and satisfies
the normalization condition uµuµ = 1.
A.
Landau–Lifshitz equation with semiclassical correction
The classical Landau–Lifshitz (LL) equation [16] reads
mduµ
ds = eF µνuν + τR

e∂αF µνuαuν −e2
mF µνFανuα + e2
m(F αβuβFαγuγ)uµ

,
(2)
where
τR = 2e2
3m,
(3)
is the classic radiation reaction time.
The choice of τR depends on the normalization set by the laser frequency ω0, which defines the
phase variable ϕ = k · x. In this work, we assume ω0 = 1 for simplicity, so that τR is treated as a
dimensionless parameter. Our choice τR = 10−9 is sufficiently small to remain consistent with the
physical magnitude of the radiation reaction time, while still allowing the effects of radiation reaction
to be clearly resolved in the simulations. For ultra-intense optical laser systems (e.g. λ ∼1 µm),
this choice corresponds to realistic physical conditions and therefore represents a reasonable and
physically relevant parameter regime.
To incorporate quantum suppression of radiation emission, it is common in semiclassical models to
multiply the radiation-reaction terms by a Gaunt factor g(χ) depending on the quantum nonlinearity
parameter (1).
The Gaunt factor satisfies
0 < g(χ) ≤1,
with g(χ) →1 for χ ≪1 and g(χ) ∼χ−4/3 for χ ≫1. A convenient approximation, accurate over
the parameter range considered here, is
g(χ) ≃(1 + 4.8χ)−1
(4)
Thus, g(χ) describes the quantum suppression of the average radiative losses due to recoil effects:
it approaches unity in the classical limit χ ≪1 and decreases monotonically as χ increases. The
evolution of g(χ(ϕ))−1 along the trajectory is shown in Fig. 1. Since the minima of g(χ) correspond
to the maxima of χ, the resulting dynamics exhibits a periodic modulation synchronized with the field
