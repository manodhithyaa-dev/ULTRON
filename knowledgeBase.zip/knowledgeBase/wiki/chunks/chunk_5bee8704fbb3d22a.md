---
id: chunk_5bee8704fbb3d22a
document: doc_4a9484dd924d39f9
heading: Page 21
start_paragraph: 42
end_paragraph: 43
---

# Page 21

## Page 21

to the underlying linear-fractional structure rather than to an independently imposed mass
variation.
E.
Relation to other deformation frameworks
The present framework shares several structural features with other approaches while
remaining physically distinct from them:
• Unlike standard DSR models [5, 7], the deformation scale here is cosmological rather
than Planckian.
• Unlike Standard-Model-Extension descriptions of Lorentz violation [22, 23], the present
deformation is isotropic in the preferred cosmological frame and does not introduce
direction-dependent coefficients.
• Unlike a strictly conformal theory, the apparent-mass formulation retains the explicit
rest-mass parameter m0 and therefore does not possess exact scale invariance.
These comparisons suggest that linear-fractional transformations furnish a useful mathe-
matical language for organizing different deformations of relativistic kinematics [9–11].
F.
Phenomenological prospects
If R is of order c/H0, the fractional change of a mass-controlled transition over a lab-
oratory time interval is of order H0∆t.
Such a variation is extremely small and, more
importantly, a universal drift of all dimensional mass scales is difficult to distinguish from
a redefinition of units or from ordinary cosmological redshift. A realistic phenomenological
analysis must therefore be formulated in terms of dimensionless comparisons: ratios of dif-
ferent transition frequencies, comparisons between particle species with distinct microscopic
sensitivities, or propagation effects accumulated over cosmological distances.
Three classes of candidate signatures may be highlighted. None is expected to produce
an observable effect at the current level of sensitivity, but each corresponds to a definite
scaling law fixed by Eq. (14):
• Differential ratios of atomic and molecular transitions in high-redshift systems. In natural
units, oscillator-like contributions to bound-state spectra scale as mapp(t)ω, whereas
21
