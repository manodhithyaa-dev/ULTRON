---
id: chunk_7b868ad464ff8e18
document: doc_309e7c4d59ff81df
heading: Page 8
start_paragraph: 14
end_paragraph: 15
---

# Page 8

## Page 8

8
semiclassical regimes, h(ϕ) exhibits linear growth with respect to ϕ, owing to the presence of a
secular term (see Sec. IV for details).
Consequently, h(ϕ) can be interpreted as an effective dynamical damping factor: it suppresses all
components of the particle momentum, thereby introducing irreversible energy loss and leading to a
violation of the Lawson–Woodward theorem. This behavior is further illustrated in Fig. 3, where the
classical Volkov-type solution (gray dotted line), which neglects radiation reaction, preserves both
energy and momentum, while the radiation-reaction-modified numerical and analytical solutions
(solid blue and dashed black lines) exhibit a monotonic loss of electron energy.
III.
EXACT FOUR-VELOCITY SOLUTION
The reduced four-velocity ˜uµ = huµ satisfies a linear inhomogeneous equation in a plane-wave
background. Due to the algebraic closure of plane-wave tensors,
F 3 = 0,
F µνnν = 0,
the associated Dyson series truncates at second order.
The exact four-velocity can therefore be written in closed form as
uµ(ϕ) =
1
h(ϕ)
n
uµ
0 + h2(ϕ) −1
2ρ0
nµ + 1
ρ0
Ij(ϕ)
efµν
j
m u0,ν −
1
2ρ0
[ξjIj(ϕ)]2nµo
,
(19)
where
Ij(ϕ) =
Z ϕ
ϕ0

h(φ)ψ′
j(φ) + τRg(χ)ρ0ψ′′
j (φ)

dφ.
(20)
The classical Di-Piazza solution is recovered when g(χ) →1.
Figure 3 shows the evolution of the four-velocity components during the interaction with the
laser field. The initial four-velocity is chosen as
uµ
0 = (γ0, 0, 0, −γ0β),
β =
q
1 −1/γ2
0
with γ0 = 1500. The particle therefore initially propagates along the negative z direction, corre-
sponding to a head-on collision geometry with the laser pulse.
Panels [Fig. 3(a)] and [Fig. 3(b)] show the temporal component u0, which determines the particle
energy. In the absence of radiation reaction, corresponding to the Lorentz-force (Volkov) solution,
u0 remains constant on average, consistent with the Lawson–Woodward theorem. When radiation
reaction is included, the particle continuously loses energy through radiation emission, leading to a
