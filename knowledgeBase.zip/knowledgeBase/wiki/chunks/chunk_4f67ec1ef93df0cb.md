---
id: chunk_4f67ec1ef93df0cb
document: doc_4a9484dd924d39f9
heading: Page 7
start_paragraph: 12
end_paragraph: 13
---

# Page 7

## Page 7

where p0 = E/c carries the dimensions of momentum. The resulting structure is that of a
Lorentz boost multiplied by the position-dependent factor D. Two interpretational remarks
are in order. First, because D depends on (t, x), the dual transformations are not boosts in
the conventional sense; they relate momentum components measured on a chosen reference
world line. Second, the present construction is neither unique nor canonical: it should be
viewed as a controlled working ansatz whose principal merit is to produce a well-defined
deformed Casimir invariant amenable to standard quantization. Several inequivalent dual-
izations can in principle be envisaged, including those induced by curved momentum-space
geometries [13], by Hopf-algebraic deformations associated with κ-Poincaré symmetry [12],
or by alternative placements of the conformal factor (for instance, on the four-momentum
itself rather than on the transformation law). Each of these would, in general, lead to a dis-
tinct deformed dispersion relation. The choice adopted here is the simplest one that respects
the multiplicative structure of the FL maps and that reduces to ordinary Lorentz kinematics
in the limit R →∞; a comparative analysis of the various alternatives lies beyond the scope
of the present work and is briefly revisited in Section VII.
B.
The deformed Casimir invariant
We now seek a quadratic invariant of the dual transformations (8)–(10). A direct com-
putation of the Lorentzian momentum norm yields
(p0′)2 −p′2 = (p02 −p2) D(t, x; v)2.
(11)
Equivalently, after multiplication by c2, the quantity E2 −p2c2 is rescaled by D2. Thus the
ordinary mass shell is not invariant under the dual map; it must be supplemented by the
FL conformal factor. To restore an invariant, a compensating factor is needed. The natural
candidate is the conformal factor of the FL spacetime itself, which obeys the transformation
rule
1 + ct′
R = 1 + ct/R
D(t, x; v)
⇐⇒
D(t, x; v) = 1 + ct/R
1 + ct′/R,
(12)
as may be verified by direct substitution of Eqs. (3)–(5) into 1 + ct′/R. In what follows, we
evaluate the relation on the world line x = 0 for definiteness. Combining Eqs. (11) and (12)
yields the invariant
(E2 −p2c2)

1 + ct
R
2
= m2
0c4.
(13)
7
