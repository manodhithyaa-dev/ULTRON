---
id: chunk_cded9156b67eb4fe
document: doc_604e4dcb676808b0
heading: Page 1
start_paragraph: 0
end_paragraph: 5
---

# Page 1

## Page 1

Improved YOLOv5 network for real-time multi-scale traffic 
sign detection 
Junfan WANG1, Yi CHEN1, Mingyu GAO()1,2, Zhenkang DONG1,3

1 School of Electronic Information, Hangzhou Dianzi University, Hangzhou 310018, China 
2 Zhenjiang Provincial Key Lab of Equipment Electronics, Hangzhou 310018, China 
3 Department of Electronic Engineering, Zhejiang University, Hangzhou 310027, China

Abstract Traffic sign detection is a challenging task 
for the unmanned driving system, especially for the 
detection of multi-scale targets and the real-time 
problem of detection. In the traffic sign detection 
process, the scale of the targets changes greatly, which 
will have a certain impact on the detection accuracy. 
Feature pyramid is widely used to solve this problem 
but it might break the feature consistency across 
different scales of traffic signs. Moreover, in practical 
application, it is difficult for common methods to 
improve the detection accuracy of multi-scale traffic 
signs while ensuring real-time detection. In this paper, 
we propose an improved feature pyramid model, named 
AF-FPN, which utilizes the adaptive attention module 
(AAM) and feature enhancement module (FEM) to 
reduce the information loss in the process of feature 
map generation and enhance the representation ability 
of the feature pyramid. We replaced the original feature 
pyramid network in YOLOv5 with AF-FPN, which 
improves the detection performance for multi-scale 
targets of the YOLOv5 network under the premise of 
ensuring real-time detection. Furthermore, a new 
automatic learning data augmentation method is 
proposed to enrich the dataset and improve the 
robustness of the model to make it more suitable for 
practical scenarios. Extensive experimental results on 
the 
Tsinghua-Tencent 
100K 
(TT100K) 
dataset 
demonstrate that compared with several state-of-the-art 
methods, our method is more universal and superior.

Keywords AF-FPN, data augmentation, multi-scale 
targets, YOLOv5

1 Introduction 
The traffic sign recognition system is the data 
foundation of intelligent transportation systems (ITS) 
and unmanned driving system, balancing the accuracy 
and real-time performance of the traffic sign detection 
and recognition technology, which plays an important 
role in the subsequent decision-making of ITS and 
unmanned driving system [1]. 
In recent years, most of the state-of-the-art 
object-detection algorithms have used convolutional 
neural networks (CNNs) and have achieved fruitful 
results in target detection tasks, such as the two-stage 
detectors Faster R-CNN [2], R-FCN [3], the one-stage 
detectors SSD [4], and YOLO [5]. However, directly 
applying these methods to traffic sign recognition is 
hard to achieve satisfactory results in practical 
application. The target recognition and detection of the 
vehicle-mounted mobile terminal require high accuracy 
for targets of different scales, and high requirements for 
recognition speed, which means to meet the two 
requirements of accuracy and real-time [6, 7]. 
Traditional CNNs use a large number of parameters 
and floating-point operations per second (FLOP) to 
achieve better detection performance. For example, 
VGG-16 [8] has about 138M parameters and requires 
14.9B FLOPs to process an image of size 608×608. 
However, mobile devices (e.g. smartphones and 
self-driving 
cars) 
with 
limited 
memory 
and 
computation resources cannot be used for deployment 
and inference for larger networks. As a one-stage 
detector, the YOLOv5 [9] is used in this paper because
