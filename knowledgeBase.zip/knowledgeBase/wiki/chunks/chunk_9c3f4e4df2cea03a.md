---
id: chunk_9c3f4e4df2cea03a
document: doc_604e4dcb676808b0
heading: Page 2
start_paragraph: 6
end_paragraph: 8
---

# Page 2

## Page 2

of the advantages of low computation and fast 
recognition speed. 
In this paper, an improved YOLOv5 network is 
proposed, which not only ensures that the model size 
can meet the requirements of deployment on the vehicle 
side but also improve the ability of multi-scale targets 
and meet the real-time requirement. 
The main contributions of our work are summarized 
as follows: 
● A novel feature pyramid network is proposed in 
this paper. Through adaptive feature fusion and 
receptive field enhancement, it retains the channel 
information in the feature transfer process to a 
large extent and learns different receptive fields in 
each feature map adaptively to enhance the 
representations of feature pyramids, effectively 
improving the accuracy of multi-scale targets 
recognition. 
● A new automatic learning data augmentation 
strategy is proposed. Inspired by AutoAugment 
[10], the latest data augmentation operations have 
been added. The improved data augmentation 
method effectively improves the model training 
effect and the robustness of the training model, 
which has more practical significance. 
● Unlike the existing YOLOv5 network, the current 
version is improved to reduce the impact of scale 
invariance. Meanwhile, it can be deployed on the 
mobile terminal of the vehicle to detect and 
recognize traffic signs in real-time. 
The rest of this paper is organized as follows: Section 
2 introduces related works about CNN-based traffic 
sign detection and data augmentation. Section 3 
introduces the details of the proposed method to detect 
and recognize the traffic signs efficiently in real-time. 
The experimental results and analysis are presented in 
Section 4. Finally, the conclusion is described in 
Section 5.

2 Related Works 
2.1 CNN-based traffic sign detection 
At present, CNN as a popular algorithm for deep 
learning has a wide range of applications in computer 
vision, natural language processing, visual-semantic 
alignments, and other fields [11-14]. According to 
whether region proposal is required, it can be divided 
into two categories: single-stage detection and 
two-stage detection. Single-stage detection is often used 
in traffic detection due to its fast detection performance. 
Shao et al. [15, 16] proposed an improved Faster 
R-CNN to traffic sign detection. They simplified the 
Gabor wavelet through a regional suggestion algorithm 
to improve the recognition speed of the network. Zhang 
et al. [17] modified the number of convolutional layers 
in the network based on YOLOv2, proposed an 
improved one-stage traffic sign detector, and used the 
China Traffic Sign Dataset for training to make it better 
adapted to Chinese traffic road scenes. A novel 
perceptual 
generative 
adversarial 
network 
was 
developed for the recognition of small-sized traffic 
signs [18], which boosts detection performance by 
generating super-resolve representations for small 
traffic signs. Aiming the scale variety problems in 
traffic sign detection, SADANet [19] combines a 
domain adaptive network with a multi-scale prediction 
network to improve the ability of the network to extract 
multi-scale features. 
Most 
of 
the 
above-mentioned 
networks 
use 
single-stage detection and only use single-scale depth 
features, so it is difficult for them to have superior 
detection and recognition performance in sophisticated 
traffic scenes. Traffic sign instances of different scales 
have great differences in visual features, and the 
proportion of traffic signs in the entire traffic scene 
image is very small. Therefore, the scale variety 
problem has become a major challenge in traffic sign 
detection and recognition. And learning scale-invariant 
representation is critical for target recognition and 
location[20]. At present, this challenge is handled 
mainly from two aspects: network architecture 
modification and data augmentation [21]. 
At present, multi-scale features are widely used in 
high-level object recognition to improve the recognition 
performance of multi-scale targets [22]. Feature 
Pyramid Network (FPN) [23], as a commonly used 
multi-layer feature fusion method, uses its multi-scale 
expression ability to derive many networks with high 
detection accuracies, such as Mask R-CNN [24] and 
RetinaNet [25]. It is worth noting that the feature maps 
will suffer from information loss due to the reduced 
feature channels and only contain some less relevant 
context information in the feature maps of other levels.
