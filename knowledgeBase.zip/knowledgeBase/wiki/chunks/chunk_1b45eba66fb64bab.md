---
id: chunk_1b45eba66fb64bab
document: doc_604e4dcb676808b0
heading: Page 8
start_paragraph: 45
end_paragraph: 47
---

# Page 8

## Page 8

Table Ⅰ 
Comparison of our method with other method on the TT100K dataset 
Method 
Model 
Parameters 
FLOPs 
APS 
APM 
APL 
mAP@0.5
FPS 
Efficientdet-d0 
15.15M 
3.752M 
2.50B 
- 
0.3980 
0.5526 
0.5786 
26 
M2det  
340M 
147M 
16.35G 
0.0300 
0.3198 
0.6586 
0.4658 
12 
Mobilenet-SSD 
118M 
25.067M 
29.20G 
0.0275 
0.2443 
0.5261 
0.3200 
22 
YOLOv3 
119.6M 
59.578M 
158.00G
0.3889 
0.4454 
0.4288 
0.6186 
27 
YOLOX-s 
69.0M 
9.010M 
27.03G 
0.4122 
0.5975 
0.6081 
0.6860 
59 
YOLOv5-Lite-g 
11.6M 
5.277M 
15.60G 
0.3218 
0.4914 
0.4957 
0.5431 
71 
YOLOv5 
14.6M 
7.193M 
17.90G 
0.3567 
0.5142 
0.5184 
0.6018 
105 
Ours 
16.3M 
8.039M 
17.90G 
0.4146 
0.5783 
0.5817 
0.6514 
95 
Firstly, it can be seen that the model size of the 
proposed method is 16.3M, which is easy to be deployed 
on a mobile platform so that it can be used for real-time 
shooting and recognition on the vehicle side. The 
amount of parameters in the training process is slightly 
higher than that of Efficientdet and YOLOX. FLOPs is 
17.9G. which is only 3.3G larger than the optimal 
YOLOv5-Lite. It can be seen from these two indicators 
that our method has a faster training speed and requires 
less hardware equipment, which is convenient for 
popularization. Excessive reduction of the number of 
parameters and calculations will lead to a decrease in the 
detection effect of the final training model. Secondly, 
our method achieves the mAP of 65.14% on all 182 
traffic sign classes, which is second only to YOLOX. 
Although the APL of our method is lower than M2det 
and YOLOX, the recognition accuracy on small targets 
is 41,46%, which is significantly higher than other 
methods. Finally, FPS is used as a metric to evaluate the 
speed of target detection, indicating that our method can 
meet the real-time requirements of detection on the 
mobile terminal. In general, our method has high 
accuracy for multi-scale target detection and can achieve 
a balance between recognition accuracy and recognition 
speed. The model size is suitable for deployment on the 
mobile 
terminal 
and 
has 
practical 
application 
significance. 
In addition, traffic sign detection is a multi-category 
and multi-target recognition task, and the false detection 
rate and missed detection rate are also important metrics 
to measure the detection network. In order to verify the 
missed detection requirements of the proposed method 
in real-time traffic sign detection, Log-Average Miss 
RATE (LAMR) [55] is selected as the evaluation index. 
LAMR reflects the relationship between the false 
negative (FP) of each image and the missed detection 
rate. The lower the FP, the better the detection 
performance of traffic signs. We selected the top 19 
traffic sign categories in the dataset, and compared the 
missed detections of each method on these types of 
traffic signs, as shown in Fig. 7. It can be seen that the 
missed detection rate of our method for traffic sign 
recognition is significantly lower than other methods, 
and it has practical application significance. However, 
the missed detection rate of several types of traffic signs 
such as ip, w57, and po is still high, and we will make 
further improvements in future research. 
1.0
0.8
0.6
0.4
0.2
0.0
pne pn i5 p11 pl40 po pl80 pl50 io p26 pl60 i4 pl5 pl30pl100 w57 il60 p5 ip
Classes
Log-average-miss-rate

Fig. 7 Comparison of the miss detection rate of each 
method on 19 types of traffic signs 
We visualize the method proposed in this paper, as 
shown in Fig. 8(a). It can be observed that our method 
successfully recognized the multi-sized traffic signs on the 
actual traffic scene with high recognition accuracy, and 
there are almost no missed detections and false detections. 
Meanwhile, we transplanted the trained model to the 
mobile platform and connected an external camera to shoot 
the actual road scene. Real-time traffic sign detection and 
recognition are performed on the captured images, and the 
recognition results are displayed on the LED screen, as 
shown in Fig. 8(b).
