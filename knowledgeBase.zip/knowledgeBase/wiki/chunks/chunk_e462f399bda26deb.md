---
id: chunk_e462f399bda26deb
document: doc_a8343f0236b29082
heading: Page 12
start_paragraph: 22
end_paragraph: 23
---

# Page 12

## Page 12

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
12
[7] R. Guidotti, A. Monreale, S. Ruggieri, F. Turini, F. Giannotti, and
D. Pedreschi, “A survey of methods for explaining black box models,”
ACM computing surveys (CSUR), vol. 51, no. 5, pp. 1–42, 2018.
[8] W. Samek, T. Wiegand, and K.-R. Müller, “Explainable artiﬁcial
intelligence: Understanding, visualizing and interpreting deep learning
models,” arXiv preprint arXiv:1708.08296, 2017.
[9] L. H. Gilpin, D. Bau, B. Z. Yuan, A. Bajwa, M. Specter, and L. Kagal,
“Explaining explanations: An overview of interpretability of machine
learning,” in 2018 IEEE 5th International Conference on data science
and advanced analytics (DSAA).
IEEE, 2018, pp. 80–89.
[10] E. Tjoa and C. Guan, “A survey on explainable artiﬁcial intelligence
(xai): Toward medical xai,” IEEE transactions on neural networks and
learning systems, vol. 32, no. 11, pp. 4793–4813, 2020.
[11] A. B. Arrieta, N. Díaz-Rodríguez, J. Del Ser, A. Bennetot, S. Tabik,
A. Barbado, S. García, S. Gil-López, D. Molina, R. Benjamins et al.,
“Explainable artiﬁcial intelligence (xai): Concepts, taxonomies, op-
portunities and challenges toward responsible ai,” Information fusion,
vol. 58, pp. 82–115, 2020.
[12] T. Rojat, R. Puget, D. Filliat, J. Del Ser, R. Gelin, and N. Díaz-
Rodríguez, “Explainable artiﬁcial intelligence (xai) on timeseries data:
A survey,” arXiv preprint arXiv:2104.00950, 2021.
[13] A. Adadi and M. Berrada, “Peeking inside the black-box: a survey
on explainable artiﬁcial intelligence (xai),” IEEE access, vol. 6, pp.
52 138–52 160, 2018.
[14] R. Confalonieri, L. Coba, B. Wagner, and T. R. Besold, “A historical
perspective of explainable artiﬁcial intelligence,” Wiley Interdisci-
plinary Reviews: Data Mining and Knowledge Discovery, vol. 11, no. 1,
p. e1391, 2021.
[15] M. van den Berg and O. Kuiper, “Xai in the ﬁnancial sector: a
conceptual framework for explainable ai (xai),” https://www. hu. nl/-
/media/hu/documenten/onderzoek/projecten/, 2020.
[16] G. Vilone and L. Longo, “Explainable artiﬁcial intelligence: a system-
atic review,” arXiv preprint arXiv:2006.00093, 2020.
[17] D. V. Carvalho, E. M. Pereira, and J. S. Cardoso, “Machine learning
interpretability: A survey on methods and metrics,” Electronics, vol. 8,
no. 8, p. 832, 2019.
[18] U. Kamath and J. Liu, Explainable Artiﬁcial Intelligence: An Introduc-
tion to Interpretable Machine Learning.
Springer, 2021.
[19] J. H. Friedman, “Greedy function approximation: a gradient boosting
machine,” Annals of statistics, pp. 1189–1232, 2001.
[20] A. Goldstein, A. Kapelner, J. Bleich, and E. Pitkin, “Peeking inside
the black box: Visualizing statistical learning with plots of individual
conditional expectation,” journal of Computational and Graphical
Statistics, vol. 24, no. 1, pp. 44–65, 2015.
[21] D. W. Apley and J. Zhu, “Visualizing the effects of predictor variables
in black box supervised learning models,” Journal of the Royal Sta-
tistical Society: Series B (Statistical Methodology), vol. 82, no. 4, pp.
1059–1086, 2020.
[22] M. Ku´zba, E. Baranowska, and P. Biecek, “pyceterisparibus: explaining
machine learning models with ceteris paribus proﬁles in python,”
Journal of Open Source Software, vol. 4, no. 37, p. 1389, 2019.
[23] M. J. Pontiveros, G. A. Solano, C. A. Tee, and M. L. Tee, “Explain-
able machine learning applied to single-nucleotide polymorphisms for
systemic lupus erythematosus prediction,” in 2020 11th International
Conference on Information, Intelligence, Systems and Applications
(IISA.
IEEE, 2020, pp. 1–8.
[24] S. M. Lundberg and S.-I. Lee, “A uniﬁed approach to interpreting
model predictions,” Advances in neural information processing systems,
vol. 30, 2017.
[25] O. Ribeiro, L. Gomes, and Z. Vale, “Iot-based human fall detection
system,” Electronics, vol. 11, no. 4, p. 592, 2022.
[26] M. T. Ribeiro, S. Singh, and C. Guestrin, “Anchors: High-precision
model-agnostic explanations,” in Proceedings of the AAAI conference
on artiﬁcial intelligence, vol. 32, no. 1, 2018.
[27] J. H. Friedman and B. E. Popescu, “Predictive learning via rule
ensembles,” The annals of applied statistics, vol. 2, no. 3, pp. 916–
954, 2008.
[28] F. Galkin, A. Aliper, E. Putin, I. Kuznetsov, V. N. Gladyshev, and
A. Zhavoronkov, “Human microbiome aging clocks based on deep
learning and tandem of permutation feature importance and accumu-
lated local effects,” BioRxiv, p. 507780, 2018.
[29] J. Lei, M. G’Sell, A. Rinaldo, R. J. Tibshirani, and L. Wasserman,
“Distribution-free predictive inference for regression,” Journal of the
American Statistical Association, vol. 113, no. 523, pp. 1094–1111,
2018.
[30] D. Lewis, Counterfactuals.
John Wiley & Sons, 2013.
[31] A. Dhurandhar, P.-Y. Chen, R. Luss, C.-C. Tu, P. Ting, K. Shanmugam,
and P. Das, “Explanations based on the missing: Towards contrastive
explanations with pertinent negatives,” Advances in neural information
processing systems, vol. 31, 2018.
[32] P. Stock and M. Cisse, “Convnets and imagenet beyond accuracy:
Understanding mistakes and uncovering biases,” in Proceedings of the
European Conference on Computer Vision (ECCV), 2018, pp. 498–512.
[33] J. Chakraborty, K. Peng, and T. Menzies, “Making fair ml software
using trustworthy explanation,” in 2020 35th IEEE/ACM International
Conference on Automated Software Engineering (ASE).
IEEE, 2020,
pp. 1229–1233.
[34] J. Druce, M. Harradon, and J. Tittle, “Explainable artiﬁcial intelligence
(xai) for increasing user trust in deep reinforcement learning driven
autonomous systems,” arXiv preprint arXiv:2106.03775, 2021.
[35] A. Das and P. Rad, “Opportunities and challenges in explainable ar-
tiﬁcial intelligence (xai): A survey,” arXiv preprint arXiv:2006.11371,
2020.
[36] J. Li, W. Monroe, and D. Jurafsky, “Understanding neural networks
through representation erasure,” arXiv preprint arXiv:1612.08220,
2016.
[37] V. Petsiuk, A. Das, and K. Saenko, “Rise: Randomized input
sampling for explanation of black-box models,” arXiv preprint
arXiv:1806.07421, 2018.
[38] L. M. Zintgraf, T. S. Cohen, T. Adel, and M. Welling, “Visualizing
deep neural network decisions: Prediction difference analysis,” arXiv
preprint arXiv:1702.04595, 2017.
[39] R. C. Fong and A. Vedaldi, “Interpretable explanations of black boxes
by meaningful perturbation,” in Proceedings of the IEEE international
conference on computer vision, 2017, pp. 3429–3437.
[40] D. Erhan, A. Courville, and Y. Bengio, “Understanding representations
learned in deep architectures,” Technical Report 1355, Université de
Montréal/DIRO, Tech. Rep., 2010.
[41] K. Simonyan, A. Vedaldi, and A. Zisserman, “Deep inside convolu-
tional networks: Visualising image classiﬁcation models and saliency
maps,” in In Workshop at International Conference on Learning
Representations.
Citeseer, 2014.
[42] A. Shrikumar, P. Greenside, and A. Kundaje, “Learning important
features through propagating activation differences,” in International
conference on machine learning.
PMLR, 2017, pp. 3145–3153.
[43] H. Chen, S. Lundberg, and S.-I. Lee, “Explaining models by prop-
agating shapley values of local components,” in Explainable AI in
Healthcare and Medicine.
Springer, 2021, pp. 261–270.
[44] M. D. Zeiler and R. Fergus, “Visualizing and understanding con-
volutional networks,” in European conference on computer vision.
Springer, 2014, pp. 818–833.
[45] J. T. Springenberg, A. Dosovitskiy, T. Brox, and M. Riedmiller,
“Striving for simplicity: The all convolutional net,” arXiv preprint
arXiv:1412.6806, 2014.
[46] B. Zhou, A. Khosla, A. Lapedriza, A. Oliva, and A. Torralba, “Learning
deep features for discriminative localization,” in Proceedings of the
IEEE conference on computer vision and pattern recognition, 2016,
pp. 2921–2929.
[47] R. R. Selvaraju, M. Cogswell, A. Das, R. Vedantam, D. Parikh, and
D. Batra, “Grad-cam: Visual explanations from deep networks via
gradient-based localization,” in Proceedings of the IEEE international
conference on computer vision, 2017, pp. 618–626.
[48] F. Doshi-Velez and B. Kim, “Towards a rigorous science of inter-
pretable machine learning,” arXiv preprint arXiv:1702.08608, 2017.
[49] I. Ahmed, G. Jeon, and F. Piccialli, “From artiﬁcial intelligence to
explainable artiﬁcial intelligence in industry 4.0: A survey on what,
how, and where,” IEEE Transactions on Industrial Informatics, 2022.
[50] N. Wang, D. V. Pynadath, and S. G. Hill, “The impact of pomdp-
generated explanations on trust and performance in human-robot
teams,” in Proceedings of the 2016 international conference on au-
tonomous agents & multiagent systems, 2016, pp. 997–1005.
[51] R. Iyer, Y. Li, H. Li, M. Lewis, R. Sundar, and K. Sycara, “Trans-
parency and explanation in deep reinforcement learning neural net-
works,” in Proceedings of the 2018 AAAI/ACM Conference on AI,
Ethics, and Society, 2018, pp. 144–150.
[52] T. Kampik, J. C. Nieves, and H. Lindgren, “Explaining sympathetic
actions of rational agents,” in International Workshop on Explainable,
Transparent Autonomous Agents and Multi-Agent Systems.
Springer,
2019, pp. 59–76.
[53] W. Guo, “Partially explainable big data driven deep reinforcement
learning for green 5g uav,” in ICC 2020-2020 IEEE International
Conference on Communications (ICC).
IEEE, 2020, pp. 1–7.
