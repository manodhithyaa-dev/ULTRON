---
id: chunk_5bc1ec6f782c366f
document: doc_6ac2027a878dbe19
heading: Page 15
start_paragraph: 29
end_paragraph: 30
---

# Page 15

## Page 15

Out[9]=
Users can add or remove relations using AddVariationalRelation[tensor1→tensor2] and
RemoveVariationalRelation[tensor1→tensor2].
In[10]:= DefTensor[{v[a],w[a],u[a],A[-a],B[]},M]
AddVariationalRelation[v→w→u]
AddVariationalRelation[A→B→w]
AddVariationalRelation adds only the abstract relation without specifying the formula; this is
done via GenerateExpandVertDiffRule (subsection 4.6). Additionally, VariationalRelationsOf
accepts the option Directed→Out or Directed→In that restricts, respectively, to outbound or
inbound dependencies.
In[13]:= VariationalRelationsOf[w]
VariationalRelationsOf[w,Directed→In]
Out[13]=
Out[14]=
The ConstantTensors option can be passed to VariationalRelationsOf to declare specific tensors
as variationally constant. Once initial constant tensors are seeded, the “constantness” is propagated
forward through the graph with backward pruning: a node is constant if all the incoming edges are
constant. This recursive propagation algorithm is a major technical novelty in xCPS.
Constant nodes are rendered as red squares and relations between them as red edges. The central
node of the graph (the tensor passed as argument) is always drawn as a green triangle for visibility,
with its dynamical status determined by its surrounding edges.
In[15]:= VariationalRelationsOf[w,ConstantTensors→{B}]
VariationalRelationsOf[w,ConstantTensors→{B,v}]
15
