---
id: chunk_278b9e11adf59a1a
document: doc_a8343f0236b29082
heading: Page 6
start_paragraph: 10
end_paragraph: 11
---

# Page 6

## Page 6

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
6
B. Energy Management
AI-powered energy decision systems used in smart cities,
smart grids and smart home applications provide decision
makers with critical predictions about energy use and emis-
sions. However, decision-makers want to know and believe
the parameters that affect the model outputs in addition to
the predicted results. Kim and Cho [54] proposed an energy
demand prediction model for smart environments. Authors
use an explainable autoencoder-based deep learning model to
predict energy demands in various environment states. The
proposed model produces consumption estimates of 15, 30,
and 45 minutes according to deﬁned states in the environment.
The developed model has been tested on home electrical
energy consumption data set containing ﬁve-year data. The
model predicts energy demands by taking the 8 features (date,
global active power, global reactive power, global intensity,
voltage, sub-metering 1/2/3) in the environment as inputs. The
authors provide more explainable information by visualizing
monthly electricity demands with t-SNA algorithm. Exper-
imental results show that the proposed model achieves the
best performance compared to other machine learning models
(Decision Trees, MLP, LSTM etc.). Sirmacek and Riverio
[55] proposed two new algorithms (machine learning-based,
computer vision-based) to predict real-time occupancy in
smart ofﬁce spaces by using very low-resolution heat sensors
data. The authors used the well-known approach SHapley
Additive exPlanations (SHAP) to extract the contribution of
features to the classiﬁcation in the ﬁrst algorithm and to reveal
the contribution of each local pixel in the second algorithm.
They showed that proposed algorithms can be used in many
application areas related to the automation and efﬁcient use
of ofﬁces, spaces, and buildings. Amiri et al. [56] proposed
an artiﬁcial neural network-based transportation energy model
to predict urban transportation energy. They used LIME for
model transparency and explainability.
C. Environmental Monitoring
Environmental applications in IoT focus on many issues and
problems in areas such as smart cities, air monitoring, water
management and climate monitoring, etc. In solving the ad-
dressed problems, mostly AI models with high complexity and
low interpretability are used. Therefore, interpretable and more
transparent models are needed in these areas that affect human
and environmental health. In this context, there are some
current efforts to solve the existing problems. Barrett-Powell et
al. [57] proposed a Situational Understanding Explorer (SUE)
platform for coalition situational understanding research that
highlights capabilities in explainable artiﬁcial intelligence for
event processing in a dense urban terrain setting. Kalamaras
et al. [58] proposed a new visual analytics platform that
includes architecture and components created for air pollution
monitoring within the scope of the AI4IoT project. In this
context, there are two component designs speciﬁcally designed
to provide an explanation of artiﬁcial intelligence models.
The ﬁrst is the Annotated Line Chart, which visualizes the
parameters of an ARIMA prediction model, the second is
the SHAP Chart provides insight into the most important
features used for Random Forest regression. Graham et al.
[59] developed an environmental bio-sensing platform called
Dynomics to evaluate patterns in transcriptional data at a
genome-scale by using XGBoost, LSTM classiﬁers and XAI
algorithms. They used SHAP algorithm to gain insight into
the features used by the predictive algorithms trained on
transcriptional data. Thakker et al. [60] proposed a ﬂood
monitoring application using semantic web technologies for
the ﬂood problem in smart cities. In this application, the
authors created an explainable hybrid image classiﬁcation
model by combining CNN-based DL models and semantic
techniques. CNN was used to determine the object coverage
proportion in the drainage and gully images obtained from
critical geographic areas, whereas semantic techniques have
been used to deﬁne the relationship between the coverage
level and the objects. In this work, the authors preferred rule-
based explainability in image classiﬁcation. Ryo et al. [61]
performed an XAI-based animal SDM (species distribution
model) analysis over time in terms of ecology, biogeography
and conservation biology. In the work, the authors demon-
strated that XAI can be used to improve the interpretability
of SDMs by performing the distribution analysis of African
elephants with the LIME model. Daillo et al. [62] proposed a
CNN algorithm that aims to reduce the problem of adaptation
space and can be used in an on-campus smart environment
monitoring platform. The authors aim to design a reliable
system using explainable artiﬁcial intelligence in the learning
and prediction process of the proposed algorithm.
D. Financial System
AI models are rapidly changing the way the ﬁnancial system
works, providing cost savings as well as operational efﬁciency
in areas such as asset management, investment advisory, risk
forecasting, lending and customer service [91]. However, due
to the nature of ﬁnancial domain, AI decisions in these
applications also contain risks that can be costly due to their
consequences. For this reason, XAI should be considered
among the priority issues in the ﬁnancial ﬁeld. Sachan et al.
[63] developed a belief-rule-based (BRB) explainable decision
support system to automate the process of lending loans. The
authors aimed to reveal the chain of events that clariﬁed the
decision process by adding a structure containing factual and
heuristic rules to the traditional IF-THEN rule-based system.
Bussmann et al. [64] proposed an XAI model that can be used
to measure the risks arising in loan purchases. The proposed
model aimed to design a system that can explain the credit
score of borrowers and predict their future behavior. The
explainability of the proposed model is provided by using
the TreeSHAP method, which provides explanations based
on Shapley values. Gramegna and Giudici [65] proposed a
technological insurance model for the insurance industry that
allows understanding of purchase and cancellation behavior of
customers. The authors used the XGBoost algorithm for the
extraction of the behavior patterns and SHAP for the model
agnostic interpretability. Gite et al. [66] proposed a stock
price prediction moded based on LSTM and CNN. With the
proposed model, it is aimed that investors can learn how and
