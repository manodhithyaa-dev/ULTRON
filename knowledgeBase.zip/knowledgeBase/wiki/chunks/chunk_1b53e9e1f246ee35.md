---
id: chunk_1b53e9e1f246ee35
document: doc_309e7c4d59ff81df
heading: Page 1
start_paragraph: 0
end_paragraph: 1
---

# Page 1

## Page 1

Exact solution of the Gaunt-modified Landau–Lifshitz equation in a plane wave
S. A. Shekhanov∗and C. P. Ridgers
York Plasma Institute, University of York, York, YO10 5DD, UK
(Dated: June 5, 2026)
We analyze electron dynamics in a plane electromagnetic wave using the Landau–Lifshitz
equation with a quantum radiation reaction correction modeled by a Gaunt factor. In this
geometry, the quantum parameter χ depends solely on the lightfront momentum, allowing
the modified equation of motion to retain the integrable structure of the classical problem.
We derive an exact solution for the energy evolution and the four-velocity, which reduces to
the known classical result in the appropriate limit. The results provide an analytical and
deterministic description of semiclassical radiation reaction in plane-wave fields.
I.
INTRODUCTION
Radiation reaction (RR) remains one of the most subtle problems in classical and quantum
electrodynamics. In interactions between ultra-relativistic electrons and ultra-intense laser fields,
radiation emission can substantially modify particle trajectories, leading to strongly nonlinear
dynamical effects that are now accessible in experiments at multi-petawatt facilities [1–3].
The classical theoretical foundation of radiation reaction lies in the Lorentz–Abraham–Dirac
equation and is regularized into the Landau–Lifshitz (LL) equation, which eliminates runaway
solutions while preserving consistency with classical electrodynamics. Classical radiation damp-
ing in relativistic motion is closely connected to synchrotron radiation theory and its quantum
generalization developed in the works of Sokolov and Ternov [4], as well as to early quasiclassical
approaches such as the Baier–Katkov formalism [5].
A particularly important configuration for analytical studies is a plane electromagnetic wave. In
this geometry the LL equation becomes exactly solvable, as first demonstrated by Di Piazza [6].
The integrability originates from the light-front structure of the plane wave: the dynamics reduces
to a closed system governed by a single scalar function controlling the evolution of the light-front
momentum and, consequently, the particle energy. This exact solution has played a central role
in clarifying the structure of classical radiation reaction and serves as a benchmark for numerical
implementations.
∗sviatoslav.shekhanov@york.ac.uk
arXiv:2606.05205v1  [physics.plasm-ph]  23 May 2026
