---
id: chunk_ed64c4baaa1d86e0
document: doc_6ac2027a878dbe19
heading: Page 8
start_paragraph: 15
end_paragraph: 16
---

# Page 8

## Page 8

Notice that⃗U is a vector in M and a 1-form in F (see Examples 1 and 4).
Remarks.
2.11. eΛ(div⃗V ) = (0, div(d⃗V )) with an additional ambiguity similar to dZ.
2.12. Upon integration over a Cauchy surface, we have:
Ω=
Z
Σ
ı∗dΘ =
Z
Σ
ı∗ιd⃗Uvol0 = −
Z
Σ
nadUavolΣ
(19)
where na is a 1-form transverse to Σ (i.e. vol0 = −n ∧volΣ over Σ).
Likewise, we establish a density equivalent to equation (12). Because SX has a horizontal co-degree
of 1, there exists a symmetry potential vector⃗sX such that SX = ι⃗sXvol0. This gives:
LXL = LXL
vol0
= dSX
vol0
= div(⃗sX)
(20)
Finally, the densitized Noether current and non-Noether current are defined as:⃗
jX =⃗sX −iX⃗U⃗
jξ = L⃗ξ −iXξ⃗U
(21)
Remark 2.13. Several signs appearing in the equations of this section are conventional and can be
globally adjusted within the xCPS package settings.
3
Computational background
3.1
xAct
xAct is a Mathematica bundle for symbolic tensor algebra. Its core functionality is distributed across
several packages: xPerm handles index canonicalization under permutation symmetries [20]; xCore
provides basic programming tools; xTensor extends Mathematica with abstract tensor calculus;
and xCoba complements xTensor with tools for explicit bases and component calculations.
In this section, we provide a brief introduction to xTensor. For brevity, we suppress all information
messages (see [17] for the companion file); for clarity, outputs are slightly formatted when needed
(LATEX formulas are retrieved via TexAct [2]). We load the core framework with the command:
In[1]:= <<xActxTensor
3.2
Quick tour of xAct
The most basic command is DefManifold, which defines a manifold and its tangent bundle.
Following Penrose’s abstract index notation, a set of abstract indices must be explicitly declared.
The dimension can be a fixed integer or a symbolic variable.
In[2]:= DefManifold[M,4,{a,b,c,d,e,f}]
Once a manifold is defined, tensors are declared with DefTensor, requiring the user to specify index
slots as covariant or contravariant within previously defined bundles. Monoterm symmetries can
be imposed directly on the indices. However, there are no known algorithms to handle multiterm
symmetries (such as Bianchi identities), though these can sometimes be implemented manually.
In[3]:= DefTensor[T[a,b,-c],M,Symmetric[{a,b}]]
Since T is symmetric in its first two indices, the expression T ab
c −T ba
c should be zero. However,
Mathematica would not simplify this expression even if we use Simplify, because it is not aware
of this symmetry. xAct has that information and can rewrite this expression using ToCanonical:
8
