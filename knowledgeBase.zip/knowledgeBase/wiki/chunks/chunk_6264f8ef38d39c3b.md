---
id: chunk_6264f8ef38d39c3b
document: doc_604e4dcb676808b0
heading: Page 6
start_paragraph: 30
end_paragraph: 32
---

# Page 6

## Page 6

M6. The final feature map has rich multi-scale context 
information, which to a certain extent alleviates the loss 
of information due to the reduction of the number of 
channels. 
FEM mainly uses the dilated convolution to learn the 
different receptive fields in each feature map adaptively 
based on the varying scales of detected traffic signs, 
thereby improving the accuracy of multi-scale target 
detection and recognition. As shown in Fig. 4, it can be 
divided into two components: the multi-branch 
convolution layer and the branch pooling layer. The 
multi-branch convolution layer is used to provide 
different sizes of receptive fields for the input feature 
map through the dilated convolution. And the average 
pooling layer is used to fuse the traffic information 
from the three branch receptive fields to improve the 
accuracy of multi-scale prediction. 
BN+ReLU
Multi-branch 
convolution layer
Dilated convolution
dilation rate = 3
dilation rate = 5
dilation rate = 7
Branch      Pooling       Layer

Fig. 4 The architecture of the FEM 
The multi-branch convolution layer consists of 
dilated convolution, BN layer, and ReLU activation 
layer. The dilated convolutions in the three parallel 
branches have the same kernel size but different 
dilation rates. Specifically, the kernel of each dilated 
convolution is 3×3 and the dilation rates d is 1, 3, and 5 
for different branches. 
Dilated 
convolutions 
support 
exponentially 
expanding receptive fields without losing resolution or 
coverage [42]. However, in the convolution operation 
of dilated convolution, the elements of the convolution 
kernel are spaced, and the size of the space depends on 
the dilation rates, which is different from the elements 
of the convolution kernel that are all adjacent in the 
standard convolution operation. 
The convolution kernel changed from 3×3 to 7×7 and 
the receptive field of this layer is 7×7. The formula for 
the receptive field of dilated convolution is as follows:
