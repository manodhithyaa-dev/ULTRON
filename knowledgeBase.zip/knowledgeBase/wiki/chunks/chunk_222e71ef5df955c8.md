---
id: chunk_222e71ef5df955c8
document: doc_6ac2027a878dbe19
heading: Page 26
start_paragraph: 51
end_paragraph: 52
---

# Page 26

## Page 26

Wald entropy of General Relativity
In[18]:= EntropyGR = EOM[RiemannLCDer][LGR] // Simplification
Out[18]=
1
2
p
−
≈g(−gadgbc + gacgbd)
Symplectic currents
In[19]:= ΩScl = SymplecticCurrent[phi][LScl] // ContractMetric // Simplification
ΩGR = SymplecticCurrent[][LGR] // ContractMetric // Simplification
Out[19]= −
p
−
≈g(nD)a(dϕ) ∧Da(dϕ)
Out[20]=
1
2
p
−
≈g(nD)a
(dg)ab ∧Db(dg)cc −(dg)bb ∧Da(dg)cc + (dg)bb ∧Dc(dg)ac
+ (dg)bc ∧Da(dg)bc −2(dg)bc ∧Dc(dg)ab

This coincides, as expected, with the theoretical results [3].
Noether symmetries
In[21]:= DefTensor[xi[a],M,PrintAs→"ξ"]
vvf1 = VVFFromLieD[xi][phi]
vvf2 = VVFFromLieD[xi][phi,g]
NoetherSymmetryQ[vvf1][g,CheckZero→True][LScl]
NoetherSymmetryQ[vvf2][g][LScl] // SortCovDs // Simplification
Out[22]= ( δ
δϕ)Lξϕ
Out[23]= ( δ
δg)abLξgab + ( δ
δϕ)Lξϕ
Out[24]= False
Out[25]= True
In[26]:= ApplyBianchi[expr_]:=···;
vvf3 = VVFFromLieD[xi][g]
NoetherSymmetryQ[vvf3][g][LGR] // SortCovDs // Simplification
,→// ApplyBianchi // ContractMetric // Simplification
Out[27]= ( δ
δg)abLξgab
Out[28]= True
ApplyBianchi is a user-defined function, provided in the companion file, that applies the Bianchi
identity in cases such as those arising here. The package TInvar implements a more systematic
approach with a database of identities [14].
Noether currents of the scalar field
In[29]:= NoetherCurrent[vvf1][g][LScl] // ContractMetric // Simplification
NoetherCurrent[vvf2][g][LScl] // ContractMetric // Simplification
FindPotentialGradient::Loop detected at iteration 2. Search aborted. Provide the optional ’iteration’
argument to obtain partial results or try applying intermediate simplification functions.
Out[29]= −
p
−
≈g(nD)aDaϕLξϕ
Out[30]=
1
2
p
−
≈g(nD)a(ξaDbϕDbϕ −2DaϕLξϕ)
vvf1 is not a symmetry but vvf2 is; see subsection 5.5 for the detailed explanation.
Non-Noether currents of the scalar field
In[31]:= CurrentFromVector[xi][g][LScl] // LieDToCovD[#,LCDer] & // ContractMetric
,→
// Simplification
26
