---
id: chunk_5ed51cf93e6b06d4
document: doc_309e7c4d59ff81df
heading: Page 2
start_paragraph: 2
end_paragraph: 3
---

# Page 2

## Page 2

2
However, the classical Landau–Lifshitz (LL) equation systematically overestimates radiative
losses once the quantum nonlinearity parameter
χ =
1
mEcr
p
−(F µνpν)2
(1)
enters the moderately quantum regime, χ ∼0.1–1. In this domain, quantum recoil and the discrete
nature of photon emission reduce the average emitted power relative to the classical prediction.
The importance of this regime was already emphasized in early strong-field QED analyses and later
formalized in the modern theory of nonlinear Compton scattering and pair production [7]. Here
Ecr ≡m2c3
e¯h
≈1.3 × 1016 V cm−1
is the Schwinger critical field. The parameter χ characterizes the field strength in the instantaneous
rest frame of the particle in units of Ecr. For an ultrarelativistic particle it can be estimated as
χ ∼γE⊥/Ecr, where E⊥is the component of the field transverse to the particle velocity. In a
counter-propagating particle–laser geometry, the Lorentz boost enhances the effective field strength
in the particle rest frame, leading to the stronger scaling χ ∼2γE⊥/Ecr. As a result, relativistic
particles with initial Lorentz factor γ0 ≫1 interacting head-on with sufficiently intense laser pulse
can readily reach the regime χ ≃0.1 −1, where quantum recoil and radiation-reaction effects
become non-negligible.
A fully quantum description based on stochastic photon emission provides the most accurate
treatment but does not admit closed-form solutions even in simple backgrounds. In practical large-
scale simulations, quantum effects are incorporated via Monte Carlo photon emission algorithms
embedded in particle-in-cell (PIC) frameworks. This approach, pioneered and developed in works
such as Bell & Kirk [8], Elkina et al. [9], and Ridgers et al. [10], forms the basis of modern
QED-PIC modeling. Closely related developments by Bulanov and collaborators established the
connection between intense laser fields and QED cascade formation in plasma environments [11],
while subsequent analyses by Narozhny and Fedotov clarified fundamental limits of perturbative
QED in extreme fields [12, 13].
In contrast, a deterministic semiclassical correction, in which the classical radiation-reaction
force is multiplied by a χ-dependent Gaunt factor g(χ) [14], reproduces the quantum-suppressed
mean emission rate while preserving the structure of a classical equation of motion, but does not
capture the stochastic broadening associated with discrete emission [15].
Despite their widespread use in numerical simulations of strong-field QED plasmas, the analytical
properties of Gaunt-modified LL equations have received comparatively little attention. In particular,
