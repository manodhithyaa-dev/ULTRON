---
id: chunk_a9ae9e011fe6a4b5
document: doc_a8343f0236b29082
heading: Page 7
start_paragraph: 12
end_paragraph: 13
---

# Page 7

## Page 7

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
7
TABLE I. The Summary of XAI Studies by IoT Application Domain
IoT Domain
Reference
Year
ML/DL Model(s)
XAI Model Name
XAI Taxonomy
Ante-hoc/
Post-Hoc
Model Spesiﬁc /
Model Agnostic
Local /
Global
Autonomous Systems
and Robotics
Iyer et al. [51]
2018
DRLN
Saliency Map
Post-hoc
Agnostic
Local
Guo et al. [53]
2020
DRL
-
Ante-hoc
Speciﬁc
Local
Energy Management
Kim et al. [54]
2019
Autoencoder
t-SNE
Post-hoc
Agnostic
-
Sirmacek et al. [55]
2020
CatBoost
SHAP
Ante-hoc
Agnostic
Local
Amiri et al. [56]
2021
NN
LIME
Post-hoc
Agnostic
Local
Environment
Kalamaras et al. [58]
2019
ARIMA, RF
SHAP
Post-hoc
Agnostic
Local
Diallo et al. [62]
2020
CNN
Integrated Gradients
Post-hoc
Agnostic
Local
Graham et al. [59]
2020
LSTM, XGBoost
SHAP
Post-hoc
Agnostic
Local
Ryo et al. [61]
2021
SDM
LIME
Post-hoc
Agnostic
Local
Finance
Sachan et al. [63]
2019
-
Belief-Rule-Base
-
-
-
Bussman et al. [64]
2020
XGBoost
Shapley Values
Post-hoc
Agnostic
Global
Gramegna et al. [65]
2020
XGBoost
SHAP
Post-hoc
Agnostic
Local
Gite et al. [66]
2021
LSTM-CNN
LIME
Post-hoc
Agnostic
Local
Healthcare
Chittajallu et al. [67]
2019
ResNet50
XAI-CBIR
Post-hoc
Agnostic
-
Hossain et al. [68]
2020
ResNet50,
Deep tree,
Inception v3
LIME, GradCAM
Post-hoc
Agnostic
-
Monroe et al. [69]
2020
CNN
HihO
Post-hoc
Agnostic
Global
Pnevmatikakis et al. [70]
2020
RF, DNN
SHAP
Post-hoc
Agnostic
Local
Hatwell et al. [71]
2020
AdaBoost
Ada-WHIPS
Post-hoc
Agnostic
Local
Dave et al. [72]
2020
XGBoost
LIME, SHAP
Post-hoc
Agnostic
Local,
Global
Gozzi et al. [73]
2022
CNN
Grad-CAM, SHAP
Post-hoc
Speciﬁc
Global
Industrial
Rehse et al. [74]
2019
DNN
-
Post-hoc
Agnostic
Local,
Global
Chen and Lee [75]
2020
CNN
Grad-CAM
Post-hoc
Agnostic
Local
Sun et al. [76]
2020
CNN
CAM
Post-hoc
Agnostic
Local
Serradilla et al. [77]
2020
RF
LIME, ELI5
Post-hoc
Agnostic
Local,
Global
Senoner et al. [78]
2021
DT
SHAP
Post-hoc
Agnostic
Local
Mehdiyev et al. [79]
2021
DNN
Surrogate
Decision Trees
Post-hoc
Agnostic
Local
Brito et al. [80]
2022
kNN, CBLOF
SHAP
Post-hoc
Agnostic
Local
Security and Privacy
Saharkhizan et al. [81]
2020
LSTM
DT
Post-hoc
Speciﬁc
Global
Khan et al. [82]
2021
CNN, AE-LSTM
LIME
Post-hoc
Agnostic
Local
Sarhan et al. [83]
2021
DFF, RF
SHAP
Post-hoc
Agnostic
Local
Mahbooba et al. [84]
2021
DT
-
Ante-hoc
Speciﬁc
Global
Nascita et al. [85]
2021
BiGRU
DeepSHAP
Post-hoc
Agnostic
Global
Zolanvari et al. [86]
2021
ANN
TRUST
Ante-hoc
Agnostic
Local
Le et al. [87]
2022
DT, RF
SHAP
Post-hoc
Agnostic
Local,
Global
Smart Agriculture
Kundu et al. [88]
2021
Custom-Net
Grad-CAM
Post-hoc
Agnostic
Local
Viana et al. [89]
2021
RF
LIME, PDP
Post-hoc
Agnostic
Local,
Global
Garrido et al. [90]
2022
ANN
DT
Ante-hoc
Speciﬁc
Global
when stock prices fall or rise and make decisions accordingly.
In this study, the interpretation and explainability of the model
outputs were carried out using LIME.
E. Healthcare
Decision-making in the healthcare domain affect people
directly, and it is very difﬁcult to compensate for their neg-
ative consequences. Therefore, AI models used in this ﬁeld
should not only perform well but also be reliable, transparent,
interpretable and explainable. Especially in IoT applications
that provide monitoring, diagnosis and health advice, this need
should be addressed as a priority. There are many studies for
this purpose. For example, Chittajallu et al. [67] proposed
a human-assisted explainable AI system called XAI-CBIR
that enables content-based image retrieval for use in surgical
education. In XAI-CBIR, CNN-based DL model lists similar
pictures by extracting the semantic descriptors of the image in
the query video. It iteratively trains itself based on relevant
feedback from users. The developed system provides the
explainability of the pictures similar to the picture in the query
by creating a visual saliency map. Hossain et al. [68] proposed
a three-tiered (stakeholder layer, edge layer, and cloud layer)
smart healthcare framework that uses 5G networking to com-
bat COVID-19-like pandemics. The framework is capable of
detecting COVID-19 using chest X-ray or CT scan images,
as well as features such as social distancing, masks and
body temperature control. The authors used ResNet50, Deep
tree, and Inception v3 models in the edge layer. Interactive
explainability is provided by using Local Interpretable Model-
Agnostic (LIMA) on the knowledge graphs produced based
on the learning parameters of these DL models. In [72],
Dave et al. focused on the usability of feature- and example-
based XAI techniques on the heart disease dataset to ensure
the reliability of AI systems used in the healthcare domain.
The authors showed that black box model behaviors can
be explained using feature-based XAI techniques SHAP and
