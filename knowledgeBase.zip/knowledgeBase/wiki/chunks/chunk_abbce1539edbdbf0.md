---
id: chunk_abbce1539edbdbf0
document: doc_309e7c4d59ff81df
heading: Page 10
start_paragraph: 18
end_paragraph: 19
---

# Page 10

## Page 10

10
decrease persists throughout the interaction. In contrast, for the finite Gaussian pulse [Fig. 3(b)],
the energy loss is localized within the pulse duration ∼ωτ; after the field amplitude vanishes, u0
approaches a constant asymptotic value, indicating that radiation emission has effectively ceased.
Panels [Fig. 3(c)] and [Fig. 3(d)] show the transverse component ux. The oscillatory behavior
is primarily driven by the transverse laser field and closely follows the Lorentz-force solution.
Radiation reaction introduces only moderate corrections to the transverse dynamics, although a
gradual reduction of the oscillation amplitude is visible in the pulsed case due to the combined
effects of radiative damping and the finite pulse envelope. After the pulse has passed, the transverse
oscillations disappear together with the external field.
Panels [Fig. 3(e)] and [Fig. 3(f)] present the longitudinal component uz, which characterizes the
particle motion along the initial propagation direction. Since the particle initially counter-propagates
with respect to the laser wave, the quantity uz increases from its initial negative value as the particle
decelerates under radiation losses. The increase is most pronounced in the classical Landau–Lifshitz
case, while inclusion of the Gaunt factor leads to weaker deceleration and correspondingly smaller
deviations from the Lorentz-force trajectory. For the Gaussian pulse [Fig. 3(f)], uz tends toward a
constant asymptotic value once the particle leaves the interaction region and the radiation-reaction
force vanishes.
IV.
CYCLE-AVERAGED DYNAMICS AND POINCAR´E MAP
The damping factor h(ϕ) satisfies Eq. (16), while quantum effects enter through the Gaunt
factor g(χ). The local quantum parameter is
χ(ϕ) = χ0(ϕ)
h(ϕ) ,
χ0(ϕ) = ρ0
m
ξjψ′
j(ϕ)
 .
(21)
Radiation reaction therefore affects the dynamics both directly, through the evolution of h, and
indirectly, through the suppression of χ.
For a monochromatic plane wave,
ξjψ′
j(ϕ)
 = e
ma0| cos ϕ|,
(22)
so that χ0(ϕ) is periodic in the laser phase and the dynamics admits a cycle-averaged description.
Using the approximate Gaunt factor
g(χ) ≃(1 + aχ)−1,
a ≃4.8,
(23)
