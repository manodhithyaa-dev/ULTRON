---
id: chunk_638a88d4afceb0d0
document: doc_6ac2027a878dbe19
heading: Page 31
start_paragraph: 64
end_paragraph: 65
---

# Page 31

## Page 31

introduces an exact divergence-detection algorithm and a heuristic potential-finding algorithm,
both of which hold independent computational value beyond the phase space framework.
The package introduces several novel features that, to the best of our knowledge, remain unavailable
in any prior tensor algebra implementation. Chief among these is the accommodation of generic
Lagrangians via PartialPartial tensors, which encode functional derivatives of unspecified scalar
functions with respect to a tensor and its derivatives. This innovation allows xCPS to seamlessly
manipulate generalized frameworks such as f(Riem) gravity and L(Riem, ∇Riem) theories without
demanding a fixed functional form. Furthermore, the variational graph and its recursive constantness-
propagation algorithm provide a systematic, extensible mechanism for tracking tensor dependencies,
resolving the structural limitations of the VarD approach. Finally, a native implementation of
vertical exterior calculus—featuring the supercommutative WWedge product and the four foundational
vertical operators—makes the symplectic current computable in absolute generality, a milestone
unachievable via perturbation-based tools such as xPert.
The applications presented in section 6 demonstrate the reliability and expansive reach of the
package. For standard frameworks like the Klein–Gordon scalar field, electromagnetism, and
General Relativity, xCPS reproduces known expressions. For higher-derivative gravity, the package
effortlessly generates highly complex outputs that would be exceptionally tedious, if not impossible,
to derive by hand or with pre-existing software.
Several development ideas remain open:
• Algorithmic Enhancements: The divergence-detection algorithm, DivergenceQ, currently
requires a scalar input; extending it to expressions with free indices would significantly broaden
its applicability.
• Ecosystem Integration: A basic compatibility with xCoba is already in place but further
integration and testing is required. A combination with xTerior is also desirable. Together,
the two packages would provide a complete implementation of the variational bicomplex,
handling both horizontal and vertical differential forms within a unified framework. However,
this relies on a double-graded wedge product, requiring a non-trivial addition to xAct.
• Physical Extensions: Finally, extending xCPS to accommodate manifolds with boundaries
[18] will unlock the automated computation of boundary charges and corner terms, which are
increasingly vital in the modern study of asymptotic symmetries and edge modes.
By automating the tedious and error-prone derivations inherent to the CPS formalism, we hope
xCPS will serve as a powerful and reliable asset for the theoretical physics community.
References
[1] Ian M Anderson. The variational bicomplex. Technical report, Utah State University, 1989. Available
at http://math.usu.edu/~fg_mp.
[2] Thomas Bäckdahl, José M. Martín-García, and Barry Wardell. TexAct: TeX code to format xAct
expressions. github.com/xAct-contrib/TexAct. Mathematica package.
[3] J Fernando Barbero G, Juan Margalef-Bentabol, Valle Varo, and Eduardo JS Villaseñor. Covariant phase
space for gravity with boundaries: metric versus tetrad formulations. Physical Review D, 104(4):044048,
2021.
[4] J Fernando Barbero G, Juan Margalef-Bentabol, Valle Varo, and Eduardo JS Villaseñor. Palatini
gravity with nonmetricity, torsion, and boundaries in metric and connection variables. Physical Review
D, 104(4):044046, 2021.
[5] J Fernando Barbero G, Juan Margalef-Bentabol, Valle Varo, and Eduardo JS Villaseñor. On-shell
equivalence of general relativity and Holst theories with nonmetricity, torsion, and boundaries. Physical
Review D, 105(6):064066, 2022.
31
