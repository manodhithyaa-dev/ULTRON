---
id: chunk_d0149a35cedeb4ed
document: doc_604e4dcb676808b0
heading: Page 4
start_paragraph: 13
end_paragraph: 19
---

# Page 4

## Page 4

original network and use the best data augmentation 
methods according to the automatic learning data 
augmentation policy to enrich the dataset and improve 
the training effect. The improved YOLOv5s network 
structure is shown in Fig. 1. 
CSP1_1 CSP1_3
CSP1_3
6086083
7676255
Conv
3838255
1919255
Conv
Conv
FEM
Neck
Backbone
Input
Prediction
Focus
Slice
Concat
=
Focus
=
CBL
Concat
CBL
Leaky
Relu
BN
Conv
X*Res unit
...
CSP1_X
CSP2
=
CBL
Concat
CBL
Leaky
ReLU
BN
CBL
Conv
CBL
CBL
add
=
Res unit
Conv
BN
Leaky
ReLU
=
CBL
Max Pooling
Concat
CBL
CBL
=
SPP
Data 
augmentation
AAM

Fig. 1 The architecture of the proposed YOLOv5s network 
In Prediction, generalized IoU (GIoU) [39] loss is 
used as the loss function of the bounding box and the 
weighted non-maximum suppression (NMS) [40] 
method is used for NMS. The loss function is as 
follows:



1




gt
GIoU
C
B
B
IoU
C
L

(1)




A
B
IoU
A
B 
(2)
where C is the smallest box covering B and Bgt. Bgt=(xgt, 
ygt, wgt, hgt) is the ground-truth box, and B=(x, y, w, h) is 
the predicted box. 
However, when the predicted box is inside the 
ground-truth box and the size of the predicted box is the 
same, the relative positions of the predicted box and the 
ground-truth box cannot be distinguished.  
In this paper, the GIoU is replaced by complete IoU 
(CIoU) [41] loss. Based on GIoU loss, the CIoU loss 
considers the overlap area, central point distance of 
bounding boxes, and the consistency of aspect ratios for 
bounding boxes. The loss function can be defined as:

2
2
( ,
)


gt
CIoU
b b
R
c

 
(3)
