---
id: chunk_f87d5a938aef8f03
document: doc_309e7c4d59ff81df
heading: Page 13
start_paragraph: 30
end_paragraph: 31
---

# Page 13

## Page 13

13
FIG. 5.
Cycle-to-cycle evolution of the damping factor hn as a function of cycle number n for different
laser amplitudes a0 in a counter-propagating relativistic electron–laser configuration. Panels (a) and (b)
correspond to a monochromatic plane wave and a finite-duration Gaussian pulse, respectively. Results are
shown for a0 = 100, 500, 1500, with fixed initial conditions γ0 = 1500, ωτ = 1, and τR = 10−9.
Under the cycle-averaged approximation,
hn+1 ≃hn + 2πKeff G(εn) = hn + 2π ¯Keff(hn),
(38)
where ¯Keff(hn) = KeffG(εn).
Equation (38) defines a one-dimensional dissipative nonlinear map. In the weakly quantum
regime, where g(χ) ≈1 and the dependence on h becomes negligible, ¯Keff approaches a constant
and the map reduces to an approximately affine form,
hn+1 ≃hn + const.
(39)
In this limit the particle loses approximately the same amount of energy during each optical cycle,
producing the nearly linear growth observed in Fig. 5 (blue line).
In the crossover regime, χ0/h ∼1, the feedback between h and χ becomes significant. The
Gaunt factor suppresses radiation losses as h grows, weakening the effective drift and reducing the
nonlinearity of the dynamics. Although the evolution is nonlinear, the system remains effectively
one-dimensional and dissipative, and no chaotic behavior is observed.
The cycle-averaged flow and the stroboscopic map therefore provide two complementary descrip-
tions of semiclassical radiation reaction in a monochromatic plane wave: the former emphasizes the
slow continuous evolution, while the latter captures the discrete energy update accumulated during
each optical period [17, 18].
