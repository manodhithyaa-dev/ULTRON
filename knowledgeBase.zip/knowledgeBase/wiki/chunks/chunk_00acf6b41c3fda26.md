---
id: chunk_00acf6b41c3fda26
document: doc_4a9484dd924d39f9
heading: Page 23
start_paragraph: 46
end_paragraph: 47
---

# Page 23

## Page 23

• The momentum-space dualization given in Eqs. (8)–(10) is not unique.
Alternative
dualizations, including Hopf-algebraic constructions related to κ-Poincaré symmetry [12],
curved momentum-space geometries, or relative-locality actions [13], may lead to different
dispersion relations.
• The dual transformations require the choice of a preferred cosmological world line. The
formalism is therefore less covariant than standard SR or a complete relative-locality
phase-space model. A fully covariant formulation remains to be developed.
• The simple Casimir relation in Eq. (13) was obtained after suppressing the full spatial
dependence of the FL conformal factor. Retaining this dependence would yield inhomo-
geneous wave equations and could modify the oscillator potential, the scalar product,
and the self-adjointness conditions.
• The spectral formulas are leading-order adiabatic results. Although the controlling pa-
rameter is extremely small for cosmological R, exact time-dependent solutions and quan-
titative subleading corrections would require Lewis–Riesenfeld invariants or an equivalent
non-adiabatic framework [16].
• The oscillator analysis has been restricted to one spatial dimension. Three-dimensional
KG and Dirac oscillators would introduce angular momentum, spin-orbit coupling, and
additional degeneracy structures that may respond differently to the FL scaling.
• The present treatment is first-quantized. A field-theoretic embedding is required to define
vacuum choice, particle creation, back-reaction, and the role of negative-frequency sectors
in a fully consistent manner.
These points do not invalidate the analytic results obtained above; rather, they delineate
the precise regime in which those results should be interpreted.
VIII.
CONCLUSION
We have constructed a momentum-space dual of the Fock–Lorentz transformations and
derived the corresponding Casimir invariant, Eq. (13). The resulting dispersion relation is
equivalent to the ordinary special-relativistic mass shell with a time-dependent apparent
23
