---
id: chunk_72fb204c4a8e4af5
document: doc_604e4dcb676808b0
heading: Page 5
start_paragraph: 24
end_paragraph: 29
---

# Page 5

## Page 5

the aspect ratio. 
And the trade-off parameter α is defined as

(1
)



IoU


 
(6)
which the overlap area factor is given higher priority 
for regression, especially for non-overlapping cases.

3.2 AF-FPN structure 
Based on the traditional feature pyramid network, 
AF-FPN adds the adaptive attention module (AAM) 
and the feature enhancement module (FEM). The 
former part reduces the loss of context information in 
the high-level feature map due to the reduced feature 
channels. The latter part enhances the representation of 
feature pyramids and accelerates the inference speed 
while achieving state-of-the-art performance. The 
structure of the AF-FPN is shown in Fig. 2. 
The input image generates feature maps {C1, C2, C3, 
C4, C5} through multiple convolutions. C5 generates the 
feature map M6 through AAM. And M6 is combined 
with M5 by summation and propagated to fuse with 
other features at lower levels through a top-down path, 
and the receptive field is expanded through FEM after 
each fusion. PANet shortens the information path 
between lower layers and the topmost feature. 
76×76
304×304
152×152
76×76
38×38
19×19
C5
C2
C1
C3
C4
M3
76×76
38×38
19×19
PANet
PANet
P5
P4
P3
Upsampling
Downsampling
M6
38×38
19×19
M5
M4

Fig. 2 The architecture of the AF-FPN 
The operation of the adaptive attention module can 
be performed in two steps. First of all, the multiple 
context features with different scales are obtained 
through the adaptive average pooling layer. The pooling 
coefficient β is [0.1, 0.5], and it adaptively changes 
according to the target size in the dataset. Secondly, a 
spatial weight map is generated for each feature map 
through the spatial attention mechanism. Through the 
weight map, context features are fused to generate a 
new feature map, which contains multi-scale context 
information. The new feature map is combined with the 
original high-level feature map and propagated to fuse 
with other features at lower levels. 
Adaptive Pooling Layer
Upsampling
W
H
W
H
Hadamard Product
Matrix Sum
W
H
Upsampling
Upsampling
C5
M6

Fig. 3 The architecture of the AAM 
The specific structure of the AAM is shown in Fig. 3. 
As the input of the adaptive attention module, the size 
of C5 is S=h×w. It first obtains context features with 
different scales of (β1×S, β2×S, β3×S) through the 
adaptive pooling layer. Then each context feature 
undergoes a 1×1 convolution to obtain the same 
channel dimension 256. Bilinear interpolation is used to 
upsample them to the scale of S for subsequent fusion. 
The spatial attention mechanism merges the channels of 
the three context features through a Concat layer, and 
then the feature map sequentially passes 1×1 
convolution 
layer, 
ReLU 
activation 
layer, 
3×3 
convolution layer, and sigmoid activation layer to 
generate corresponding spatial weights for each feature 
map. The generated weight map and the feature map 
after the merged channel are subjected to the Hadamard 
product operation, which is separated and added to the 
input feature map M5 to aggregate context features into
