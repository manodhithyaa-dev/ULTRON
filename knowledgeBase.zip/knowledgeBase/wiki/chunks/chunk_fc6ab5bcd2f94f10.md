---
id: chunk_fc6ab5bcd2f94f10
document: doc_6ac2027a878dbe19
heading: Page 23
start_paragraph: 45
end_paragraph: 46
---

# Page 23

## Page 23

SymplecticCurrent[tensors][L] applies VertDiff to SymplecticPotential[tensors][L] fol-
lowed by ExpandVertDiff with the option NonConstantTensors→tensors. The latter ensures
that only dynamical fields are varied. The option HoldExpandVertDiff→tensor can be added to
prevent the expansion of tensor in the second variation (see the example of subsection 6.2).
In[57]:= SymplecticPotential[phi][LScl] // ContractMetric // Simplification
SymplecticCurrent[phi][LScl] // Simplification
SymplecticCurrent[][LScl] // ContractMetric // Simplification
Out[57]=
p
−
≈g(dϕ)(nD)aDaϕ
Out[58]= −
p
−
≈g(nD)a(dϕ) ∧Da(dϕ)
Out[59]= −1
2
p
−
≈g(nD)a
2(dϕ) ∧Da(dϕ) + (dϕ) ∧(dg)bbDaϕ −2(dϕ) ∧(dg)abDbϕ

Remark 5.5. Through considerable effort, xPert could yield the first variation. However, it cannot
compute the symplectic current since the super-commutativity of WWedge is essential.
5.5
Noether symmetries, potentials, and currents
5.5.1
NoetherSymmetryQ
NoetherSymmetryQ checks whether a VVF is a d-symmetry of a Lagrangian. Following equation (20),
it checks whether LXL is a divergence. For that, xCPS runs DivergenceQ (see subsubsection 4.7.1)
over VertInt[VVF][VertDiff@Lagrangian]//ExpandVertInt[] (see subsections 4.3 and 4.6). For
example, we can use this command to check that the diffeomorphism-induced VVF, Xξ, acting only
on ϕ is not a d-symmetry of LScl in general:
In[60]:= vvf1 = VVFFromLieD[xi][phi]
NoetherSymmetryQ[vvf1][g][LScl]
NoetherSymmetryQ[vvf1][g,CheckZero→True][LScl]
Out[60]= ( δ
δϕ)Lξϕ
Out[61]= DaϕDbDbϕ = 0 && Dcϕ(DaξcDbϕ+DaϕDbξc −gabDdξcDdϕ)+ξc(DbϕDcDaϕ+DaϕDcDbϕ−
gabDdDcϕDdϕ)
=
0 && ξaDaDbDbϕ + DaξaDbDbϕ
=
DaϕDbDbξa + ξaDbDbDaϕ +
2DbDaϕDbξa
Out[62]= False
However, if it acts on all fields, it is a symmetry:
In[63]:= vvf2 = VVFFromLieD[xi][phi,g]
NoetherSymmetryQ[vvf2][g][LScl]
NoetherSymmetryQ[vvf2][g][LScl] // SortCovDs // Simplification
Out[63]= ( δ
δg)abLξgab + ( δ
δϕ)Lξϕ
Out[64]= DaDbξbDaϕ + ξaDbDbDaϕ = ξaDaDbDbϕ + DaϕDbDaξb
Out[65]= True
If ξ is a g-Killing vector field, then Lξgab = 0. In that case vvf1=vvf2 and both are symmetries.
5.5.2
SymmetryPotential
SymmetryPotential[vvf][metric][L] attempts to find the symmetry potential⃗svvf satisfying
LvvfL = div(⃗svvf) (see equation (20)). For that, xCPS runs FindPotentialGradient (see subsub-
section 4.7.2) over VertInt[VVF][VertDiff@Lagrangian]//ExpandVertInt[] (see subsections 4.3
and 4.6).
In[66]:= SymmetryPotential[vvf1][g][LScl]
23
