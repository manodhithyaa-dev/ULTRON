---
id: chunk_95ad35faeea20af6
document: doc_6ac2027a878dbe19
heading: Page 9
start_paragraph: 17
end_paragraph: 18
---

# Page 9

## Page 9

In[4]:= T[a,b,-c]-T[b,a,-c] // Simplify ( Symmetry not considered )
T[a,b,-c]-T[b,a,-c] // ToCanonical
Out[4]= T ab
c −T ba
c
Out[5]= 0
ToCanonical is arguably the most important command in xAct, as it brings any expression down
to a unique canonical form. While canonicalization does not necessarily yield a simpler-looking
expression, it enforces a standard form which is suited for Mathematica’s simplification algorithms.
For convenience, xAct provides the command Simplification which is Simplify@ToCanonical.
With a manifold and tensors defined, we can perform differential calculus. Without introducing
additional structures, we have access to Lie derivatives, LieD, and Lie Brackets, Bracket.
In[6]:= DefTensor[{v[a],w[a]},M]
LieD[v[d]]@T[a,b,-c]
Bracket[v[d],w[d]][c]
Out[7]= LvT ba
c
Out[8]= [vd, wd]c
The vectors v[d] and w[d] are the arguments and, when playing this operational role, their indices
are called “ultraindices”. They act purely as placeholders identifying the vectors and do not appear
in the index structure of the output, and may be freely repeated.
The previous expressions can be rewritten in terms of some covariant derivatives (CovD). By default,
xAct uses a fiducial torsion-free flat connection named PD, denoted ∂, and referred to as the ordinary
derivative in [24]. It is not unique yet constitutes a CovD in its own right (no coordinates needed!).
In[9]:= LieDToCovD[LieD[v[d]]@T[a,b,-c]]
BracketToCovD[Bracket[v[d],w[d]][c]]
Out[9]= vd∂dT ab
c + T ab
d ∂cvd −T db
c ∂dva −T ad
c ∂dvb
Out[10]= va∂awc −wa∂avc
Additional CovDs, possibly with torsion, can be defined on any tangent bundle:
In[11]:= DefCovD[CD[-a],{";","D"},Torsion→True]
This defines the covariant derivative CD over M (to which the index a belongs), denoted D, along with
its associated tensors: TorsionCD[a,-b,-c] (zero if Torsion→False), ChristoffelCD[a,-b,-c],
RiemannCD[-a,-b,-c,d] and RicciCD[-a,-b]. Because this CovD is non-metric, ChristoffelCD
and RicciCD are not symmetric and RiemannCD is only antisymmetric in the first pair.
Remark 3.1. ChristoffelCD is a genuine tensor, not merely a connection symbol. It measures
the difference between CD and the fiducial connection PD:
In[12]:= CD[-a]@T[b,-c,-d] == (CD[-a]@T[b,-c,-d] // ChangeCovD)
Out[12]= DaT bcd = ∂aT bcd + Γ[D]baeT ecd −Γ[D]eadT bce −Γ[D]eacT bed
We can also define inner vector bundles (possibly complex) over M, equipped with their corresponding
abstract indices, where the specified dimension corresponds to the dimension of a typical fiber.
In[13]:= DefVBundle[inner,M,3,{J,P,Q,X}]
Subsequently, we can define a CovD that acts simultaneously on both TangentM and inner indices.
In[14]:= DefCovD[CD2[-a],inner,{";","∇"},Torsion→True]
In addition to the standard tensors associated with any CovD (TorsionCD2, ChristoffelCD2,
9
