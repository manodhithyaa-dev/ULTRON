---
id: chunk_d83bef92942049da
document: doc_6ac2027a878dbe19
heading: Page 28
start_paragraph: 55
end_paragraph: 56
---

# Page 28

## Page 28

In[10]:= FirstVariation[A,LCDer][LEM]
Out[10]=
p
−
≈g(dA)aDbF ab + TotalDerivativeOfLCDer

−
p
−
≈g(dA)aFab(nD)b
We can see that the Gauss law is written in a compact form in terms of the F tensor. This is one
of the novelties of xCPS.
Energy-momentum tensor
In[11]:= EnMomEM = EnergyMomentum[LEM] // ContractMetric // Simplification
Out[11]= F acF bc −1
4FcdF cdgab
Symplectic currents
In[12]:= SymplecticCurrent[A,LCDer][LEM] // ContractMetric // Simplification
SymplecticCurrent[A,LCDer,HoldExpandVertDiff→F][LEM] // ContractMetric
,→
// Simplification
Out[12]= −
p
−
≈g(nD)a((dA)b ∧Db(dA)a −(dA)b ∧Da(dA)b)
Out[13]= −
p
−
≈g(nD)a(dA)b ∧(dF)ab
The second form is more compact since HoldExpandVertDiff prevents dF from being expanded
into dA terms in the second variation, keeping the field strength manifest.
Noether symmetries
In[14]:= DefTensor[lambda[],M,PrintAs→"λ"]
DefTensor[xi[a],M,PrintAs→"ξ"]
vvfEM1 = LCDer[-a]@lambda[] VariationalVectorA[a]
vvfEM2 = VVFFromLieD[xi][A]
NoetherSymmetryQ[vvfEM1][g][LEM]
NoetherSymmetryQ[vvfEM2][g,CheckZero→True][LEM]
Out[16]= ( δ
δA)aDaλ
Out[17]= ( δ
δA)aLξAa
Out[18]= True
Out[19]= False
vvfEM1 corresponds to the standard EM gauge transformation.
Noether current
In[20]:= NoetherCurrent[vvfEM1][LCDer][LEM] // ContractMetric // Simplification
Out[20]= −
p
−
≈g Fab(nD)aDbλ
Upon integration over a closed Cauchy surface and integration by parts, this expression vanishes
on-shell: the extrinsic curvature term that arises cancels by the antisymmetry of F.
Non-Noether current
In[21]:= CurrentFromVector[xi][A,LCDer][LEM] // LieDToCovD[#,LCDer] &
,→// ContractMetric // Simplification
Out[21]=
p
−
≈g(nD)a
1
4FbcF bcξa −FacξbDbAc −AcFabDbξc

This is the EM energy-momentum current. It is not conserved in general since Xξ is not a symmetry
(g is non-dynamical). Conservation is restored if, for instance, ξ is a g-Killing vector field.
28
