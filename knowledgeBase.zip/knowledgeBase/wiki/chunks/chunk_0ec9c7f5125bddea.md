---
id: chunk_0ec9c7f5125bddea
document: doc_27960becbcfef01d
heading: Page 9
start_paragraph: 16
end_paragraph: 17
---

# Page 9

## Page 9

Ethical and Social Aspects of Self-Driving Cars
ARXIV’18, January 2018, Gothenburg, Sweden
Table 2: Summary of social challenges and recommendations grouped by requirement
Requirements
Challenges
Recommendations
Social
challenges of
disruptive
technology
• Handling job losses (e.g., taxi/truck drivers, traditional
mechanics, insurance agents, etc.)
• Change of related markets and business models (e.g., car
insurances, car manufacturers, etc.)
• Prepare strategic solutions for people loosing jobs
• Take advice/learn from historic parallels to industrialization
and automatization
Stakeholders -
general public
interests
• Human concerns in the decision making of self-driving cars,
e.g. possibility of interference with the decision making
• Freedom of choice hindered by the system (e.g. it may not
allow to drive into a certain area)
• Values and priorities: Ensure that general public values will be
embodied in the technology, with interests of minorities taken
into account
• Determine and communicate the amount of control a human
has in context of the self-driving car
• The freedom of choice determined by regulations
• Active involvement of stakeholders in the process of design
and requirements specification
Selling points
• Self-driving cars will have different buying criteria, depending
on who will own the cars, big companies, social institutions such
as municipalities or individual users, as they all have different
preferences. Among those preferences environmental and
sustainability criteria can be expected to play central role
• Existing policy documents don’t seem to leave possibilities
open for anti-social self-driving cars to be
developed [13, 27, 46, 49].
• Priorities and choices for the self-driving cars will result from
the dialog between producers and future users
• Ensure that existing and future policies and standards prevent
the possibility of developing "anti-social" self-driving cars.
Legislation,
norms, policies
and standards
• Keeping legislation up-to-date with current level of automated
driving, and emergence of self-driving cars
• Creating and defining global legislation frameworks for the
implementation of interoperable and development of
increasingly automated vehicles
• Defining the guidelines that will be adopted by society for
building self-driving cars.
• Including ethical guidelines in design and development
processes
• Car producers supporting and collaborating with legislators in
their task to keep up-to-date with the current level of automated
driving
• Legislative support and contribution to global frameworks to
ensure a smooth enrollment of the emerging technology
• Include ethics in the overall process of design, development
and implementation of self-driving cars. Ensure Ethics training
for involved engineers [52, 55]
• Establish and maintain a functioning socio-technological
system in addition to functional safety standards.
