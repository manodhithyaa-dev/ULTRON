---
id: chunk_ca6e0f0ccb183a63
document: doc_6ac2027a878dbe19
heading: Page 27
start_paragraph: 53
end_paragraph: 54
---

# Page 27

## Page 27

Out[31]=
1
2
p
−
≈g(nD)aDbϕ(−2ξbDaϕ + ξaDbϕ)
Integrating over a Cauchy surface Σ yields the ξ-energy of Σ. It is not conserved in general:
evaluating on a different Cauchy surface Σ′ yields a different value even on-shell.
Noether currents of GR
In[32]:= NoetherCurrent[vvf3][g][LGR]
FindPotentialGradient::Loop detected at iteration 4. Search aborted. Provide the optional ’iteration’
argument to obtain partial results or try applying intermediate simplification functions.
Out[32]=
p
−
≈g gbc(nD)a(DaLξgbc −DcLξgab)
NoetherCurrent finds a loop even though vvf3 is a symmetry of LGR. The problem arises because
SymmetryPotential reorders covariant derivatives without applying the Bianchi identities, causing
the algorithm to fail to recognize that intermediate expressions vanish. We can force the application
of the Bianchi identities in the intermediate steps as follows:
In[33]:= SymmetryPotential[vvf3][g][LGR,SortCovDs,ApplyBianchi]
NoetherCurrent[vvf3][g][LGR,ApplyBianchi] // LieDToCovD[#,LCDer] &
,→// SortCovDs // ContractMetric // Simplification
Out[33]=
p
−
≈g(nD)aR[D]ξa
Out[34]=
p
−
≈g(nD)a(R[D]ξa −2R[D]abξb)
The Noether current vanishes on-shell, as expected.
Remark 6.1. Different choices of intermediate functions can affect the form of the result. When
they do, the outputs differ by a total divergence and are thus equivalent. For instance:
In[35]:= NoetherCurrent[vvf3][g][LGR,ApplyBianchi,SortCovDs] // LieDToCovD[#,LCDer] &
,→// SortCovDs // ContractMetric // Simplification
Out[35]=
p
−
≈g(nD)a(R[D]ξa −2R[D]abξb + DbDaξb −DbDbξa)
6.2
Electromagnetism
We now treat electromagnetism (EM). We begin a new Mathematica session and define a manifold,
a Lorentzian metric, a 1-form Aa, and an antisymmetric tensor Fab:
In[1]:= <<xActxCPS
SetOptions[ContractMetric,AllowUpperDerivatives→True];
DefManifold[M,4,{a,b,c,d,e,f,h,i,j,k,l}]
DefMetric[-1,g[-a,-b],LCDer,{";","D"}]
DefTensor[A[-a],M]
DefTensor[F[-a,-b],M,Antisymmetric[-a,-b]]
First variation
We define the EM Lagrangian and include the expansion rule for dF:
In[7]:= LEM =
1
4
p
-Detg[] F[-a,-b] F[a,b]
GenerateExpandVertDiffRule[dlF[-a,-b],LCDer[-a]@dlA[-b]-LCDer[-b]@dlA[-a]]
VertDiff[F[-a,-b]] // ExpandVertDiff[]
Out[7]=
1
4
p
−
≈g FabF ab
Out[9]= Da(dA)b −Db(dA)a
Its first variation is given by:
27
