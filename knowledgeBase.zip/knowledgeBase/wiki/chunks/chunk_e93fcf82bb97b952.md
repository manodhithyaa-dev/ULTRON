---
id: chunk_e93fcf82bb97b952
document: doc_6ac2027a878dbe19
heading: Page 11
start_paragraph: 21
end_paragraph: 22
---

# Page 11

## Page 11

4
xCPS core functionalities
This section explains the core functionalities of xCPS, which is distributed as part of xAct under the
GNU General Public License [17] and is also available at https://github.com/juanmargalef/xCPS.
Where possible, explanations are language-agnostic to facilitate reimplementation in other languages.
We begin a new Mathematica session and load xCPS (which automatically loads xAct) using:
In[1]:= <<xActxCPS
SetOptions[ContractMetric,AllowUpperDerivatives→True];
DefManifold[M,4,{a,b,c,d,e,f,h,i,j,k,l}]
4.1
Vertical forms and the field-space wedge product
DefTensor has been modified in three key ways:
1. It accepts the additional option VertDeg, a non-negative integer (0 by default) indicating
that the defined tensor of M is also a form on the space of fields F of that degree. The term
“vertical” refers to the fiber direction in the variational bicomplex [1, 18] as opposed to the
“horizontal” degree on M.
2. For any tensor T, an additional tensor dlT is defined: the vertical exterior derivative of T,
printed as dT, with the same characteristics as T except that VertDeg[dT]=VertDeg[T]+1.2
3. For any tensor T, an additional tensor VariationalVectorT is defined: the dual to the first-
order variation of T, printed as
δ
δT. It has “opposite” characteristics to T: opposite variance of
indices (but identical symmetries), opposite vertical degree, VertDeg[ δ
δT]=-VertDeg[T], and
opposite density weight, WeightOfTensor[ δ
δT]=-WeightOfTensor[T].
Remark 4.1. dT and
δ
δT are dual: their contraction yields a scalar (see details on subsection 4.6).
The vertical degree enables a new bilinear supergraded product called WWedge, corresponding to
the natural wedge of k-forms on the space of fields:
α ∧β = (−1)VertDeg[α]VertDeg[β]β ∧α
(22)
Remarks.
4.2. The WWedge product is associative and reduces to the standard Times product if at least one
of the two terms has a VertDeg of zero.
4.3. Several xAct commands have been modified to account for the WWedge product. For instance,
LieD and Bracket must satisfy the Leibniz rule with respect to the WWedge.
4.4. Part of the setup so far is the vertical analog of the xTerior package [12] (which implements
the horizontal Wedge product of horizontal forms). A key difference is that horizontal k-forms
vanish when k exceeds the dimension of M, while there is no limit to the degree of the vertical
differential forms (F is infinite-dimensional).
4.2
Variational vectors and variational vector fields
As mentioned before, each tensor defined via DefTensor has an associated variational vector with
“opposite” characteristics. For example, for a metric gab, its variational vector
δ
δg has two upper
symmetric indices:
 δ
δg
ab
(23)
2The prepend “dl” and the print symbol d can be modified via $NameVerticalExteriorDerivative and
$SymbolVerticalExteriorDerivative.
11
