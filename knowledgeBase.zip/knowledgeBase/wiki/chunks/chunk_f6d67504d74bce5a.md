---
id: chunk_f6d67504d74bce5a
document: doc_a8343f0236b29082
heading: Page 14
start_paragraph: 26
end_paragraph: 27
---

# Page 14

## Page 14

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
14
[95] N. L. Tsakiridis, T. Diamantopoulos, A. L. Symeonidis, J. B.
Theocharis, A. Iossiﬁdes, P. Chatzimisios, G. Pratos, and D. Kouvas,
“Versatile internet of things for agriculture: an explainable ai approach,”
in IFIP International Conference on Artiﬁcial Intelligence Applications
and Innovations.
Springer, 2020, pp. 180–191.
[96] R. Gandhi, S. Bhardwaj, B. Sehgal, and D. Gupta, “An explainable ai
approach for agriculture using iot,” Available at SSRN 3834259, 2021.
[97] E. M. Kenny, E. Ruelle, A. Geoghegan, M. Temraz, M. T. Keane
et al., “Bayesian case-exclusion and explainable ai (xai) for sus-
tainable farming,” in The 29th International Joint Conference on
Artiﬁcial Intelligence-17th Paciﬁc Rim International Conference on
Artiﬁcial Intelligence (IJCAI-PRICAI-20), Yokohama, Japan, January
2021 (Conference postponed due to COVID-19 pandemic), 2021.
[98] M. Ghassemi, L. Oakden-Rayner, and A. L. Beam, “The false hope of
current approaches to explainable artiﬁcial intelligence in health care,”
The Lancet Digital Health, vol. 3, no. 11, pp. e745–e750, 2021.
[99] D. Watson, “Conceptual challenges for interpretable machine learning,”
Available at SSRN 3668444, 2020.
[100] G. Fidel, R. Bitton, and A. Shabtai, “When explainability meets adver-
sarial learning: Detecting adversarial examples using shap signatures,”
in 2020 international joint conference on neural networks (IJCNN).
IEEE, 2020, pp. 1–8.
˙Ibrahim Kök received his MSc and PhD degrees
in Computer Science from Gazi University in 2015
and 2020, respectively. He is currently Assistant
Professor with the Department of Computer Engi-
neering, Pamukkale University, Denizli. His current
research interests include Internet of Things (IoT),
Deep Learning, AI-enabled IoT, and Data Analytics.
Feyza Yıldırım Okay received the MSc and PhD
degrees in Computer Engineering from Gazi Uni-
versity Graduate School of Natural and Applied
Sciences in 2013 and 2019, respectively. She is
currently working as a research assistant at the same
institute. Her research interests include Internet of
Things, Fog Computing, Software Deﬁned Network-
ing, and Network Security.
Özgecan Muyanlı received her BS in Computer
Engineering from Gazi University in 2020. She is
currently a PhD student with the Department of
Computer Engineering, Hacettepe University and
working as a software engineer at TUSA¸S. Her re-
search interests include Artiﬁcial Intelligence, Data
Analytics, Big Data, and Internet of Things.
Suat Özdemir is with the Department of Com-
puter Engineering at Hacettepe University, Ankara,
Turkey. He received his MSc degree in Computer
Science from Syracuse University (August 2001)
and PhD degree in Computer Science from Arizona
State University (December 2006). His current re-
search interests include Internet of Things, Data An-
alytics, Artiﬁcial Intelligence, and Network Security.
