---
id: chunk_900cc5e10cdbf462
document: doc_4a9484dd924d39f9
heading: Page 26
start_paragraph: 52
end_paragraph: 53
---

# Page 26

## Page 26

Press, Cambridge, 1982), doi:10.1017/CBO9780511622632.
[19] R. P. Martínez-y-Romero, H. N. Núñez-Yépez, and A. L. Salas-Brito, “Relativistic quan-
tum mechanics of a Dirac oscillator,” Eur. J. Phys. 16, 135–141 (1995), doi:10.1088/0143-
0807/16/3/008.
[20] G. Junker, “On the supersymmetry of the Klein–Gordon oscillator,” Symmetry 13, 835 (2021),
doi:10.3390/sym13050835.
[21] K. Bakke and C. Furtado, “On the Klein–Gordon oscillator subject to a Coulomb-type poten-
tial,” Ann. Phys. 355, 48–54 (2015), doi:10.1016/j.aop.2015.01.028.
[22] D. Colladay and V. A. Kostelecký, “CPT violation and the standard model,” Phys. Rev.
D 55, 6760–6774 (1997), doi:10.1103/PhysRevD.55.6760; D. Colladay and V. A. Kost-
elecký, “Lorentz-violating extension of the standard model,” Phys. Rev. D 58, 116002 (1998),
doi:10.1103/PhysRevD.58.116002.
[23] R. Lehnert, “Dirac theory within the standard-model extension,” J. Math. Phys. 45, 3399–3452
(2004), doi:10.1063/1.1780871.
[24] X. Bi, Z. Cao, Y. Li, and Q. Yuan, “Testing Lorentz invariance with ultra-high energy cosmic
ray spectrum,” Phys. Rev. D 79, 083015 (2009), doi:10.1103/PhysRevD.79.083015.
[25] G. Amelino-Camelia and T. Piran, “Cosmic rays and TeV photons as probes of quantum prop-
erties of space-time,” Phys. Lett. B 497, 265–270 (2001), doi:10.1016/S0370-2693(00)01305-8.
[26] M. Rodríguez Martínez and T. Piran, “Constraining Lorentz violations with gamma-ray
bursts,” JCAP 04, 006 (2006), doi:10.1088/1475-7516/2006/04/006.
[27] M. Galaverni and G. Sigl, “Lorentz violation for photons and ultrahigh-energy cosmic rays,”
Phys. Rev. Lett. 100, 021102 (2008), doi:10.1103/PhysRevLett.100.021102.
[28] M. Galaverni and G. Sigl, “Lorentz violation and ultrahigh-energy photons,” Phys. Rev. D 78,
063003 (2008), doi:10.1103/PhysRevD.78.063003.
26
