---
id: chunk_3ef303bd7f0bb76d
document: doc_6ac2027a878dbe19
heading: Page 32
start_paragraph: 66
end_paragraph: 67
---

# Page 32

## Page 32

[6] Glenn Barnich and Cedric Troessaert. BMS charge algebra. Journal of High Energy Physics, 2011(12):1–
22, 2011.
[7] Hermann Bondi, MG Julian Van der Burg, and AW Kenneth Metzner. Gravitational waves in general
relativity, VII. waves from axi-symmetric isolated system. Proceedings of the Royal Society of London.
Series A. Mathematical and Physical Sciences, 269(1336):21–52, 1962.
[8] David Brizuela, José M. Martín-García, and Guillermo A. Mena Marugán. xPert: Computer algebra for
metric perturbation theory. General Relativity and Gravitation, 41:2415–2431, 2009.
[9] Freddy Cachazo and Andrew Strominger. Evidence for a new soft graviton theorem. arXiv preprint
arXiv:1404.4091, 2014.
[10] Miguel Campiglia and Alok Laddha. Asymptotic symmetries and subleading soft graviton theorem.
Physical Review D, 90(12):124028, 2014.
[11] Laurent Freidel, Roberto Oliveri, Daniele Pranzetti, and Simone Speziale. The Weyl BMS group and
Einstein’s equations. Journal of High Energy Physics, 2021(7):170, 2021.
[12] Alfonso
García-Parrado
and
Leo
C.
Stein.
xTerior:
Exterior
calculus
in
Mathematica.
github.com/xAct-contrib/xTerior. Mathematica package.
[13] Vivek Iyer and Robert M Wald. Some properties of the noether charge and a proposal for dynamical
black hole entropy. Physical Review D, 50(2):846, 1994.
[14] Kevin Kiely, Barry Wardell, Adrian Ottewill, and José M. Martín-García. TInvar: Canonicalization of
Riemann expressions with free indices. xact.es. Mathematica package, part of the xAct bundle.
[15] Joohan Lee and Robert M Wald. Local symmetries and constraints. Journal of Mathematical Physics,
31(3):725–743, 1990.
[16] Juan Margalef-Bentabol. Towards general relativity through parametrized theories. arXiv preprint
arXiv:1807.05534, 2018.
[17] Juan Margalef-Bentabol and Laura Sánchez Cotta. xCPS: an xAct package for covariant phase space,
Noether charges, and entropy. github.com/juanmargalef/xCPS, 2026. Mathematica package.
[18] Juan Margalef-Bentabol and Eduardo JS Villaseñor. Geometric formulation of the covariant phase
space methods with boundaries. Physical Review D, 103(2):025011, 2021.
[19] Juan Margalef-Bentabol and Eduardo JS Villaseñor. Proof of the equivalence of the symplectic forms
derived from the canonical and the covariant phase space formalisms. Physical Review D, 105(10):L101701,
2022.
[20] José M. Martín-García. xPerm: fast index canonicalization for tensor computer algebra. Computer
Physics Communications, 179:597–603, 2008.
[21] Rainer K. Sachs. Asymptotic symmetries in gravitational theory. Physical Review, 128(6):2851–2864,
1962.
[22] Robert M Wald. On identically closed forms locally constructed from a field. Journal of Mathematical
Physics, 31(10):2378–2384, 1990.
[23] Robert M Wald. Black hole entropy is the noether charge. Physical Review D, 48(8):R3427, 1993.
[24] Robert M Wald. General relativity. University of Chicago Press, 2010.
[25] Robert M Wald and Andreas Zoupas. General definition of “conserved quantities” in general relativity
and other theories of gravity. Physical Review D, 61(8):084027, 2000.
[26] Gregg J Zuckerman. Action principles and global geometry. In Mathematical aspects of string theory,
pages 259–284. World Scientific, 1987.
[27] Čedomir Crnković and Edward Witten. Covariant description of canonical formalism in geometrical
theories. In Stephen W. Hawking and Werner Israel, editors, Three Hundred Years of Gravitation, pages
676–684. Cambridge University Press, 1987.
32
