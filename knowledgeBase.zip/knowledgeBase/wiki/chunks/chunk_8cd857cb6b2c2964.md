---
id: chunk_8cd857cb6b2c2964
document: doc_4a9484dd924d39f9
heading: Page 10
start_paragraph: 18
end_paragraph: 21
---

# Page 10

## Page 10

and substituting into the deformed dispersion relation (13), one obtains the modified Klein–
Gordon equation
h
∂2
t −c2∇2 +
m2
0c4/ℏ2
(1 + ct/R)2
i
Φ(t, x) = 0.
(17)
Because (1 + ct/R) is a c-number after the world-line reduction, no operator-ordering ambi-
guity arises at this step. The mass term is now manifestly time-dependent through m2
app(t).
A fully inhomogeneous treatment, in which the spatial dependence of the FL conformal
factor is retained, would require a separate analysis of ordering and self-adjointness.
Plane-wave solutions are no longer exact; however, for any constant-momentum mode
ei⃗k·x, Eq. (17) reduces to a harmonic-oscillator-like equation in time:
¨ϕ⃗k(t) + Ω2
k(t) ϕ⃗k(t) = 0,
Ω2
k(t) ≡c2k2 +
m2
0c4/ℏ2
(1 + ct/R)2.
(18)
This is the equation of motion of a parametric oscillator with a slowly varying frequency,
for which adiabatic and quantum-field-theoretic analyses are well established [16–18]. The
WKB ansatz
ϕ⃗k(t) ∼
1
p
2Ωk(t)
exp

∓i
Z t
Ωk(t′) dt′
(19)
provides accurate positive- and negative-frequency solutions whenever the adiabatic param-
eter
η(t) ≡

˙Ωk
Ω2
k

(20)
remains much smaller than unity. Let
µ ≡m0c2
ℏ
,
s(t) ≡1 + ct
R.
(21)
A direct differentiation of Eq. (18) gives the exact mode-dependent expression
ηk(t) = c
R
µ2/s3(t)
[c2k2 + µ2/s2(t)]3/2.
(22)
In the massive sector, where the rest-frequency term dominates, this reduces to
ηk(t) ≃
ℏ
m0cR ≡
¯λC
R ,
(23)
where ¯λC is the reduced Compton wavelength. Thus the leading massive-sector adiabatic
parameter is constant; the factor s(t) coming from 1/Ωk is exactly cancelled by the cor-
responding factor in | ˙Ωk|. For a finite nonzero wave number, Eq. (22) may be written as
ηk = [ℏ/(m0cR)]/[1 + (ℏks/m0c)2]3/2, so the parameter is largest near the initial epoch and
10
