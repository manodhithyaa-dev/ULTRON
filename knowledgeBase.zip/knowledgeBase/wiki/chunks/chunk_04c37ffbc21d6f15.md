---
id: chunk_04c37ffbc21d6f15
document: doc_309e7c4d59ff81df
heading: Document
start_paragraph: 22
end_paragraph: 27
---

# Document

cos2 ϕ
1 + εn| cos ϕ|

.
(29)
Using the symmetry of the integrand,

cos2 ϕ
1 + εn| cos ϕ|

= 2
π
Z π/2
0
cos2 ϕ
1 + εn cos ϕ dϕ,
(30)
which can be evaluated in closed form. For εn > 1,
G(εn) =

cos2 ϕ
1 + εn| cos ϕ|

=
2
πεn
−1
ε2n
+
4
πε2n
p
ε2n −1
artanh
r
εn −1
εn + 1,
(31)
with the corresponding real-valued expression for 0 < εn < 1 obtained by analytic continuation.
The averaged dynamics is therefore governed by the effective drift
dh
dϕ ≃Keff G(εn).
(32)
When εn varies slowly over many cycles, the drift coefficient may be regarded as nearly constant
over a finite phase interval. In that case,
h(ϕ) ≃h(ϕ0) + ¯Keff(ϕ −ϕ0),
¯Keff = Keff G(εn),
(33)
