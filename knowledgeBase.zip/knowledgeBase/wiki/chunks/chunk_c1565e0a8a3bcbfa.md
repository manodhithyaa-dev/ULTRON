---
id: chunk_c1565e0a8a3bcbfa
document: doc_309e7c4d59ff81df
heading: Page 5
start_paragraph: 8
end_paragraph: 9
---

# Page 5

## Page 5

5
FIG. 1. Phase dependence of the inverse Gaunt factor 1/g(χ) (blue) and quantum parameter χ (orange) in
(a) a monochromatic plane wave and (b) a gaussian-enveloped pulse with a0 = 500, γ0 = 1500, ωτ = 10 and
τR = 10−9. Case of a counter-propagating relativistic particle.
oscillations. At the same time, the peak values gradually decrease with increasing phase ϕ, reflecting
the reduction of the average value of χ. This behavior follows directly from Eq. (17), where χ ∝h−1,
while h(ϕ) increases due to radiation losses. In the monochromatic case [Fig. 1(a)], this produces a
slowly decaying oscillatory pattern, whereas for a Gaussian-envelope pulse [Fig. 1(b)] the decrease
is significantly faster, since the particle eventually leaves the region of strong electromagnetic field.
The modified equation becomes
mduµ
ds = eF µνuν + τRg(χ)

e∂αF µνuαuν −e2
mF µνFανuα + e2
m(F αβuβFαγuγ)uµ

.
(5)
This equation remains deterministic but incorporates quantum-reduced radiative power at the
level of average dynamics.
B.
Plane-wave geometry
We now specialize to a plane electromagnetic wave. Let nµ = (1, n) be a lightlike four-vector,
n2 = 0, defining the propagation direction of the wave. The phase variable is ϕ = n · x.
The four-potential may be written as
Aµ(ϕ) = aµ
j ψj(ϕ),
(6)
where aµ
j (j = 1, 2) are constant polarization vectors, n · aj = 0, ai · aj = −a2
i δij, ψj(ϕ) are arbitrary
scalar envelope functions.
