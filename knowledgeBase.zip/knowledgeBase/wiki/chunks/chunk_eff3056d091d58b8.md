---
id: chunk_eff3056d091d58b8
document: doc_4a9484dd924d39f9
heading: Page 22
start_paragraph: 44
end_paragraph: 45
---

# Page 22

## Page 22

rest-mass contributions scale as m2
app(t). Therefore, the ratio of an electronic line to a
vibrational, rotational, or hyperfine line may acquire a residual drift of order c∆t/R once
the universal redshift has been removed. Schematically,
νA(z)/νB(z)
νA(0)/νB(0) −1 = CAB ∆F(z),
F(z) = (1 + ct/R)−1,
(52)
where CAB is a model-dependent sensitivity coefficient determined by the microscopic
structure of the two transitions. This proposal is analogous in spirit to spectroscopic
searches for variations of dimensionless constants, although the present mechanism is
tied to the FL conformal factor rather than to a varying coupling constant.
• Energy-dependent propagation effects at very high energies. The squared dispersion re-
lation (13) reduces to the SR form once mapp(t) is reinterpreted as an apparent rest
mass.
Consequently, the present framework does not predict the energy-dependent
group-velocity effect that is often tested in gamma-ray-burst or ultra-high-energy-cosmic-
ray analyses [24–28]. A null result in such tests is therefore consistent with the model;
conversely, those tests would constrain the proposal only if the world-line ansatz were
embedded into a broader deformation that included additional energy-dependent terms.
• Comparison of fermionic and bosonic level spacings. The KG and Dirac oscillators share
the same global mapp(t) scaling, but the Dirac oscillator carries a component-index shift:
the lower component associated with a given physical level is displaced by one oscil-
lator quantum relative to the upper component. A late-universe compression of this
component structure relative to spinless, mass-controlled scales would be a qualitative
consequence of the model, although its quantitative magnitude lies far below present
observational capabilities for cosmological R.
The present paper therefore does not claim an immediately observable signal.
Its phe-
nomenological contribution is more modest: it identifies which dimensionless observables
would be required to test the apparent-mass scaling, and clarifies why purely dimensional
mass drifts cannot in themselves constitute a falsifiable prediction.
G.
Limitations and open problems
Several limitations of the present analysis should be acknowledged:
22
