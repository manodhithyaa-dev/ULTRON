---
id: chunk_6fd387c20105d5de
document: doc_4a9484dd924d39f9
heading: Page 19
start_paragraph: 38
end_paragraph: 39
---

# Page 19

## Page 19

KG case, the entire instantaneous spectrum approaches E = 0 as t →∞, while the oscil-
lator length grows and the component-index separation is progressively compressed by the
decreasing apparent mass.
VII.
DISCUSSION
The principal physical consequence of the dual FL construction is the emergence of the
slowly varying mass scale mapp(t). The present section clarifies how this quantity should be
interpreted and how it affects the oscillator spectra.
The same mathematical result admits two complementary interpretations. From a formal
standpoint, the construction deforms the mass shell through the linear-fractional FL factor.
Operationally, it describes the rest-mass scale inferred by an observer who employs the
original FL laboratory variables along a selected cosmological world line. The model should
therefore not be regarded as an arbitrary time-dependent mass ansatz: the time dependence
follows directly from the chosen momentum-space dualization and from the evaluation of
the conformal factor on a specified world line.
A.
Evolution of the instantaneous spectrum
The spectra derived above depend on time exclusively through mapp(t). In Eq. (37), for
instance, the rest-mass contribution to E2
n scales as (1 + ct/R)−2, whereas the oscillator
contribution scales as (1 + ct/R)−1. Consequently, the level spacings decrease progressively
as the apparent mass diminishes. In the limit t →∞, the instantaneous energies vanish for
every fixed quantum number. This behaviour is best characterized as a degeneration of the
instantaneous spectrum at E = 0, rather than as a finite-time loss of normalizability. The
oscillator wavefunctions remain normalizable at every finite time; their characteristic length
merely grows as ℓ(t) ∝[mapp(t)ω]−1/2.
B.
Dimensionless numerical illustrations
The figures included in this manuscript are not fitted to data; they are dimensionless di-
agnostic plots designed to render the analytic scaling laws transparent. Figure 2 displays the
19
