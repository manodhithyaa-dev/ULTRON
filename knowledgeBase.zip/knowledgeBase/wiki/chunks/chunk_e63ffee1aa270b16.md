---
id: chunk_e63ffee1aa270b16
document: doc_4a9484dd924d39f9
heading: Page 1
start_paragraph: 0
end_paragraph: 1
---

# Page 1

## Page 1

Klein–Gordon and Dirac Oscillators with an Apparent Mass
Induced by the Momentum-Space Dual of the Fock–Lorentz
Transformations
A. Boumali,1, ∗N. Jafari,2, 3, † and Manizheh Botshekananfard4, ‡
1Laboratory of Applied Physics and Theoretical Physics, Department of Matter Sciences,
Faculty of Exact Sciences and Sciences of Nature and Life,
Larbi Tebessi University, Tebessa, Algeria
2Fesenkov Astrophysical Institute, 050020 Almaty, Kazakhstan
3Al-Farabi Kazakh National University,
Al-Farabi Avenue 71, 050040 Almaty, Kazakhstan
4Department of Physics, Bogazici University, 34342 Bebek, Istanbul, Turkey
(Dated: June 5, 2026)
1
arXiv:2606.05226v1  [physics.gen-ph]  2 Jun 2026
