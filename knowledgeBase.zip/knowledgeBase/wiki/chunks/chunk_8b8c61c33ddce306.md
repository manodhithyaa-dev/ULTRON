---
id: chunk_8b8c61c33ddce306
document: doc_4a9484dd924d39f9
heading: Page 9
start_paragraph: 16
end_paragraph: 17
---

# Page 9

## Page 9

FIG. 2. Apparent mass mapp(t)/m0 = (1 + ct/R)−1 as a function of the dimensionless time ct/R.
The horizontal dotted line marks the special-relativistic limit recovered for R →∞. The dot-dashed
line indicates the leading-order linear drift 1 −ct/R that controls the variation on laboratory time
scales. As t →∞, the apparent mass approaches zero, signalling an asymptotic degeneration of the
rest-mass scale.
Retaining the complete spatial dependence of D(t, x; v) before the world-line reduction
would generate wave equations with position- and time-dependent coefficients. These equa-
tions would require a separate treatment of operator ordering, self-adjointness, boundary
conditions, and the oscillator potential in a genuinely inhomogeneous FL background. The
present work therefore isolates the homogeneous sector in which the apparent-mass mech-
anism and its spectral consequences admit an analytic treatment. This restricted setting
defines the domain of the model and motivates the extensions discussed in Sec. VII.
III.
MODIFIED KLEIN–GORDON EQUATION
Promoting the four-momentum components to differential operators through the canon-
ical correspondence
E →iℏ∂t,
p →−iℏ∇,
(16)
9
