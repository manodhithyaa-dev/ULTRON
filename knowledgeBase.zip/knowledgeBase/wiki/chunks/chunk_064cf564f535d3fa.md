---
id: chunk_064cf564f535d3fa
document: doc_309e7c4d59ff81df
heading: Page 12
start_paragraph: 28
end_paragraph: 29
---

# Page 12

## Page 12

12
FIG. 4.
Evolution of the light-front dissipation function h(ϕ) for a monochromatic plane wave in a
counter-propagating relativistic electron–laser configuration. Results are shown for fixed parameters a0 = 500,
γ0 = 1500, and τR = 10−9. The classical radiation-reaction case (g = 1, orange) exhibits linear growth with
slope Keff, while the semiclassical Gaunt-corrected case (blue) shows a reduced effective drift ¯Keff, reflecting
quantum suppression of radiative energy loss.
and, for the common choice h(0) = 1,
h(ϕ) ≃1 + ¯Keffϕ.
(34)
The linear approximation Eq. (34) is illustrated in Fig. 4. The classical radiation-reaction case
(g = 1) is characterized by the larger slope Keff, whereas the inclusion of the Gaunt factor reduces
the effective growth rate to ¯Keff, resulting in a slower increase of h(ϕ).
As a consequence, the quantum parameter decreases according to
χ(ϕ) = χ0(ϕ)
h(ϕ) ,
(35)
so radiation reaction progressively suppresses quantum recoil even when the system initially satisfies
χ0 >∼1.
The same dynamics may be expressed as a Poincar´e map sampled once per optical cycle [17].
Defining
hn = h(ϕn),
ϕn = 2πn,
(36)
the evolution over one period reads
hn+1 −hn =
Z ϕn+2π
ϕn
dh
dϕ dϕ.
(37)
