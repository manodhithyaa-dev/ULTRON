---
id: chunk_bc4b5edc9db34c47
document: doc_309e7c4d59ff81df
heading: Page 15
start_paragraph: 34
end_paragraph: 35
---

# Page 15

## Page 15

15
[4] A. A. Sokolov and I. M. Ternov, Radiation from Relativistic Electrons (American Institute of Physics,
New York, 1986).
[5] V. N. Baier, V. M. Katkov, and V. M. Strakhovenko, Electromagnetic Processes at High Energies in
Oriented Single Crystals (World Scientific, Singapore, 1998).
[6] A. Di Piazza, Letters in Mathematical Physics 83, 305 (2008).
[7] V. I. Ritus, Journal of Soviet Laser Research 6, 497 (1985).
[8] A. R. Bell and J. G. Kirk, Physical Review Letters 101, 200403 (2008).
[9] N. V. Elkina et al., Physical Review Special Topics - Accelerators and Beams 14, 054401 (2011).
[10] C. P. Ridgers, J. G. Kirk, C. S. Brady, T. D. Arber, and A. R. Bell, Journal of Computational Physics
260, 273 (2014).
[11] S. V. Bulanov et al., Physics Letters A 374, 1110 (2010).
[12] N. B. Narozhny and A. M. Fedotov, Contemporary Physics 56, 249 (2015).
[13] A. M. Fedotov, Journal of Physics: Conference Series 826, 012027 (2017).
[14] F. Niel et al., Physical Review E 97, 043209 (2018).
[15] T. G. Blackburn, Reviews of Modern Plasma Physics (2024).
[16] L. D. Landau and E. M. Lifshitz, The Classical Theory of Fields, 4th ed. (Pergamon Press, 1975).
[17] R. Z. Sagdeev and G. M. Zaslavsky, Nonlinear Physics: From Pendulum to Turbulence and Chaos
(Harwood Academic Publishers, 1988).
[18] E. S. Sarachik and G. T. Schappert, Physical Review D 1, 2738 (1970).
