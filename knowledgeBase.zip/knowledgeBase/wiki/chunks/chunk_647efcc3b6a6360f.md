---
id: chunk_647efcc3b6a6360f
document: doc_6ac2027a878dbe19
heading: Page 6
start_paragraph: 11
end_paragraph: 12
---

# Page 6

## Page 6

2.6
Noether symmetries and charges
Definition 2.5. Given a local action S, we say that a VVF, X, is a symmetry of S if LXS = 0.
Such a symmetry leaves the action S (and therefore the physics) invariant, which subsequently
preserves the set of critical points Sol(S). Thus, its restriction X := X|Sol(S) is a vector field of
Sol(S). A natural question is whether X is a Hamiltonian vector field with respect to ΩS. Among all
symmetries, the d-symmetries defined below admit a systematic treatment via Noether’s theorem.
Definition 2.6. A VVF, X, is a d-symmetry (or variational symmetry) of L if
LXL = dSX
(12)
for some SX ∈Ω(n−1,0)(M × F). In this case, SX is called a symmetry potential of X.
Remarks.
2.7. If X is a d-symmetry of L, then it is also a d-symmetry of any L′ = L + dY .
2.8. If X is a d-symmetry of L, then X is a symmetry of SL. The converse is not generally true.
2.9. SX is defined up to a closed form, which might not be exact. For simplicity, we assume that
every closed (n −1)-form is exact (see [18] for a discussion when this does not hold).
Applying Cartan’s magic formula and equation (1), we find:
0 = LXL −dSX = iXdL −dSX = iX(EOMidΦi + dΘ) −dSX = EOMiLXΦi −d(SX −iXΘ)
Definition 2.10. Given a d-symmetry X of SL, we define its X-current (or Noether current) as
JX = SX −iXΘ ∈Ω(n−1,0)(M × F)
Integrating over a Cauchy surface Σ yields the X-charge (or Noether charge):
HX :=
Z
Σ
ı∗JX
−→
HX := j∗HX
(13)
Tracking the ambiguities outlined in subsection 2.3, one finds that HX depends only on S, X, and
ı : Σ ,→M, while its pull-back to the space of solutions HX (on-shell), depends exclusively on S and
X. This latter quantity represents the physically meaningful conserved Noether charge, taking the
same value on any Cauchy surface Σ. Furthermore, HX is the Hamiltonian of X, i.e., iXΩS = dHX.
Finally, we define a gauge transformation as a VVF over the space of solutions X such that:
iXΩS = 0
≡
HX = 0 (up to a constant)
≡
JX = dQX
(14)
Example 4:
Let us consider the electromagnetic (EM) Lagrangian given by
LEM(A) = 1
4gacgbd(dA)ab(dA)cdvolg
where A ∈Ω1(M) and g is some fixed metric. A straightforward computation shows that
EOMb
EM = −∇a(dA)abvolg
ΘEM = ι⃗Uvolg
with
Ua = (dA)ab(dA)b
Letting λ ∈Ω0(M), we define Xλ by:
iXλdA := dλ
≡
LXλA := dλ
≡
Xλ =
Z
M
dλ δ
δA
(15)
6
