---
id: chunk_4de1b25850e72f5d
document: doc_6ac2027a878dbe19
heading: Page 29
start_paragraph: 57
end_paragraph: 60
---

# Page 29

## Page 29

6.3
f(Riem)
We now consider a generic f(Riem) theory. As before, we begin a new Mathematica session and
define a manifold and a Lorentzian metric:
In[1]:= <<xActxCPS
SetOptions[ContractMetric,AllowUpperDerivatives→True];
DefManifold[M,4,{a,b,c,d,e,f,h,i,j,k,l}]
DefMetric[-1,g[-a,-b],LCDer,{";","D"}]
PrintAs[RiemannLCDer] ^= "Riem";
To define the Lagrangian, we use the xAct command DefScalarFunction, which is modified by
xCPS to accept an additional argument: the list of tensors on which it depends variationally.
In[6]:= DefScalarFunction[L,RiemannLCDer]
Ldensity =
p
-Detg[] L[RiemannLCDer]
Out[7]=
p
−˜˜g L

Riem

EOM
In[8]:= EOM[g][Ldensity] // ContractMetric // Simplification
Out[8]=
1
2
p
−˜˜g

gabL

Riem

+ (
∂L
∂Riem)bcdeRiemacde + (
∂L
∂Riem)acdeRiembcde
−2DcDd(
∂L
∂Riem)acbd −2DdDc(
∂L
∂Riem)acbd
ExpandVertDiff uses the chain rule when acting over the VertDiff of a scalar function. If not yet
defined, the command defines the required tensors ∂function
∂tensor
automatically. The indices are opposite
to tensor and with the same symmetries. Its weight equals the weight of function minus that of
tensor. These tensors are called PartialPartial tensors within xCPS.
Wald entropy
In[9]:= EOM[RiemannLCDer][Ldensity] // Simplification
Out[9]=
p
−˜˜g(
∂L
∂Riem)abcd
Symplectic Current
In[10]:= SymplecticCurrent[][Ldensity] // ContractMetric // Simplification
Out[10]=
p
−˜˜g(nD)a

(
∂L
∂Riem)bcde(dg)bd ∧Da(dg)ce −2(
∂L
∂Riem)bcde(dg)bd ∧De(dg)ac
+2(
∂2L
∂2Riem)afhibcdjRiembcde(dg)ej ∧Di(dg)fh + (
∂L
∂Riem)abcd
(dg)bc ∧Dd(dg)ee
+2(dg)ce ∧Db(dg)de + 2(dg)ce ∧Dd(dg)be −2(dg)ce ∧De(dg)bd + (dg)ee ∧Dd(dg)bc

+2(
∂2L
∂2Riem)afhibcdjRiembcde(dg)fh ∧Di(dg)ej −4(
∂2L
∂2Riem)abcdefhi
(dg)bc ∧DdDiDf(dg)eh
−Dd(dg)bc ∧DiDf(dg)eh

+ 4(dg)bd ∧DiDf(dg)ehDc(
∂2L
∂2Riem)abcdefhi
−(dg)bd ∧(dg)eeDc(
∂L
∂Riem)abcd + 2(
∂2L
∂2Riem)ahf ibcdj(dg)ej ∧(dg)hiDfRiembcde
+2Riembcde(dg)ej ∧(dg)fiDh(
∂2L
∂2Riem)afhibcdj

Higher-order derivatives of L are handled analogously: ExpandVertDiff applies the chain rule and
defines (if needed) the required higher-order PartialPartial tensors of the form
∂kfunction
∂i1tensor1 · · · ∂imtensorm
The indices are the concatenation of the opposite indices of tensor1, . . . , tensorm (the tensors are
always ordered lexicographically, since the “partial derivatives” commute by assumption). The
symmetry group of this tensor is nontrivial:
29
