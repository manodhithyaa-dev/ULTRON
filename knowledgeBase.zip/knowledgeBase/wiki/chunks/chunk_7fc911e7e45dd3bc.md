---
id: chunk_7fc911e7e45dd3bc
document: doc_6ac2027a878dbe19
heading: Page 7
start_paragraph: 13
end_paragraph: 14
---

# Page 7

## Page 7

Since d2 = 0, it is easy to check that
LXλLEM = 0
−→
JXλ = −iXλΘ = −ι(iXλ⃗U)volg = −ι((dA)ab(dλ)b)volg
Integrating by parts produces the Noether charge:
HXλ =
Z
Σ
λnaEOMa
EMvolγ
−→
HXλ = 0
Thus, Xλ is a d-symmetry and Xλ is, according to equation (14), a gauge transformation.
2.7
Diff-invariance and non-Noether charges
An action S is Diff-invariant if Xξ, as defined in equation (11), is a symmetry of S for all ξ ∈X(M).
A Lagrangian L is Diff-invariant if LXξL = LξL for all ξ ∈X(M). If L is Diff-invariant, then Xξ is
a d-symmetry of L (though the converse might not hold) with
SXξ = ιξL
−→
JXξ = ιξL −iXξΘ
−→
HXξ :=
Z
Σ
ı∗JXξ
−→
HXξ := j∗HXξ
(16)
Notably, these quantities can be defined even when Xξ is not a d-symmetry:
Sξ := ιξL
−→
Jξ := ιξL −iXξΘ
−→
QΣ
ξ :=
Z
Σ
ı∗Jξ
−→
QΣ
ξ := j∗QΣ
ξ
(17)
that we call ξ-potential, ξ-current, off-shell ξ-charge, and on-shell ξ-charge. If Xξ is not a symmetry,
QΣ
ξ is a non-Noether charge. This generally depends on the chosen Lagrangian representative and
the Cauchy surface Σ, leading to a flux law relating charges on different Cauchy surfaces.
Example 5:
The ξ-charge of the Lagrangian Lscl given by equation (2) is:
QΣ
ξ =
Z
Σ
naξbT ab
sclvolγ
Here, T ab
scl = ∇aϕ∇bϕ −gabLscl(ϕ) is the energy-momentum tensor.
2.8
Top-forms vs densities
Because xAct operates on tensorial expressions rather than geometric integrals, xCPS works with
densitized currents instead of top-forms and their integrated counterparts. These approaches are
equivalent once a fiducial volume form vol0 on M is fixed, which we assume henceforth. We now
explicitly define eΛ, the density-level analogue to Λ from equation (8).
First consider a Lagrangian function L ∈Ω(0,0)(M × F). Clearly L := Lvol0 ∈Ω(n,0)(M × F) is a
Lagrangian with the usual decomposition dL = EOMdΦi + dΘ given by equation (1). Since Θ has
horizontal-co-degree 1, there exists a symplectic potential vector⃗U such that Θ = ι⃗Uvol0. Therefore,
the same computation used after equation (4) shows that dΘ = div(⃗U)vol0. Thus, using the fact
that vol0 is fixed (dvol0 = 0), we obtain the density-equivalent decomposition to equation (1):
dL = dL
vol0
= EOMi
vol0
dΦi + dΘ
vol0
= EOMi
vol0
dΦi + div(⃗U)vol0
vol0
= eomidΦi + div(⃗U)
(18)
Here, eomi is the densitized equations of motion (i.e. EOMi = eomivol0), whose kernel is the same
as EOMi. Consequently, we define the canonical decomposition map eΛ as:
eΛ :
Ω(0,0)(M × F)
−→
Ω(0,0)(M × F) × T (1,1)(M × F)
L
7−→
( eomi ,⃗U )
7
