---
id: chunk_04f2f6f08c1e8e58
document: doc_309e7c4d59ff81df
heading: Page 14
start_paragraph: 32
end_paragraph: 33
---

# Page 14

## Page 14

14
V.
CONCLUSION
In this work we have shown that the Landau–Lifshitz equation with semiclassical Gaunt-factor
correction remains exactly integrable in a plane-wave background. Exploiting the fact that, in a
plane wave, the quantum nonlinearity parameter χ depends solely on the light-front momentum, the
full dynamics reduces to a single scalar quadrature governing energy dissipation. The four-velocity
and trajectory then follow in closed form, with the classical Di Piazza solution [6] recovered in the
limit g(χ) →1.
The resulting solution provides an exact analytical benchmark for semiclassical radiation-reaction
models widely used in particle-in-cell simulations, which are now a standard tool for describing
charged-particle dynamics in regimes where classical radiation reaction and quantum effects coexist
[3]. The Gaunt-factor correction captures the deterministic reduction of radiative losses due to
quantum recoil, while preserving a classical equation-of-motion structure. However, it does not
include inherently quantum effects such as stochastic photon emission, radiation straggling, and
discrete recoil events that arise in full strong-field QED.
Such stochastic features become essential in the regime χ >∼1, where radiation emission becomes
strongly probabilistic and cascade-like dynamics may emerge in both laboratory and astrophysical
environments. In this context, plane waves serve as a standard benchmark configuration for testing
radiation-reaction models and numerical implementations.
Our exact solution therefore establishes a direct analytical bridge between classical integrable
radiation-reaction dynamics and semiclassical quantum-corrected models. It provides a controlled
baseline against which both deterministic Gaunt-factor approaches and stochastic QED simulations
can be compared, clarifying the domain of validity of reduced models in high-field physics.
Future work may extend this framework to include stochastic emission processes on top of the
exact semiclassical trajectory, or to explore more general plane-wave structures with nontrivial
polarization and envelope dynamics.
[1] A. Di Piazza, C. M¨uller, K. Z. Hatsagortsyan, and C. H. Keitel, Reviews of Modern Physics 84, 1177
(2012).
[2] M. Marklund and P. K. Shukla, Reviews of Modern Physics 78, 591 (2006).
[3] A. Gonoskov, T. G. Blackburn, M. Marklund, and S. S. Bulanov, Reviews of Modern Physics 94, 045001
(2022).
