---
id: chunk_9c0df650384be3e9
document: doc_27960becbcfef01d
heading: Page 4
start_paragraph: 6
end_paragraph: 7
---

# Page 4

## Page 4

ARXIV’18, January 2018, Gothenburg, Sweden
Tobias Holstein and Gordana Dodig-Crnkovic, Patrizio Pelliccione
over time. Nowadays, manufacturer are increasingly interested in
continuous integration and deployment techniques that promise to
update the software even after the vehicle has been sold and is on
the street, like a common smart-phone. However, changing even a
single line of code might require to starting counting from 0 the
number of covered miles.
3
ETHICAL ASPECTS OF THE TECHNICAL
CHALLENGES IN SELF-DRIVING CARS
In the following, we will discuss ethical deliberations surrounding
the autonomous vehicle, including involved stakeholders, technolo-
gies, social environments, and costs vs. quality. The multifaceted
and complex nature of reality emphasizes again the importance to
look broader instead of focusing on single ethical dilemma like the
trolley problem.
3.1
Safety
Safety is the most fundamental requirement of autonomous cars.
The central question is then: how should a self-driving car be tested?
What guidelines should be fulfilled to ensure that it is safe to use?
There are several standards, such as the ISO 26262, that specify the
safety standard for road vehicles. For self-driving cars standards
are under development, based on experiences being made. Google
Car tests show one million kilometres without any accident, is
this a measurement to certify its software? As we discussed above,
this should not be a reasonable assurance for safety. Should a self-
driving car make a driver licence as suggested in [43]? How would
that work?
The source code of autonomous cars are typically commercial
and not publicly available. One possibility to assure code correctness
via independent control. Should there be an independent organiza-
tion to check those? But could it actually be checked? Who else than
the developers at a car manufacturer or supplier will understand
such a complex system?
An alternative route seems to be preferred by legislators - instead
of control of the software which is in the domain of the producers,
legislation focus on behaviour that is being tested, based on the
"Proven in Use" Argument.
Testing of present-day cars should demonstrate the compliance
of their behaviour with legislative norms [20]. Disengagements,
accidents and reaction times based on data released in 2016 from
the California trials are discussed in [21].
In the case of the software of the car will evolve even when the
vehicle is already on the street, testing should account for this new
challenge.
When it comes to hardware and hardware-software systems,
there have been discussions about the prices of laser radars com-
pared to cameras or ultra-sonic sensors. Laser radars are very ex-
pensive, but deliver high quality data in diverse weather conditions.
Ultra-sonic sensors or cameras are less accurate and sensitive under
weather conditions like rain. Should a car manufacturer choose a
cheap over an expensive sensor, even if this raises the likelihood of
errors/faults/accidents? In advanced driving assistance systems, the
driver would take over, if a critical situation could not be handled
by the system. What happens in self-driving cars? Will the car
just stop and wait until the rain is over? Will passengers be able
and allowed to intervene? Under which conditions? Would it be re-
quired to have a driving licence for a self-driving car? Or would the
police have a possibility to intervene, and in what way, when a car
behaves inadequately or even dangerously? Also would the police
even have the possibility to stop a self-driving car that is behaving
correctly, with the sole purpose of checking the passengers?
The economic aspects might be seen as the highest priority.
Using cheap equipment might lead to wrong decision-making and
in a self-driving car, it would be impossible to interfere with the
decisions made. Assuming that wrong decision may lead to a loss of
human lives or property, having chosen a cheap component could
therefore be ethically unacceptable.
Learning from experience is the most important basis for im-
provement of safety in self-driving cars. This is for instance envi-
sioned by the CEO of Tesla, Elon Musk, in the Tesla’s second 10
year master plan “part deux”, where the third element of the four
major elements is: develop a vehicle self-driving capability that is
10x safer than manual via massive fleet learning1.
3.2
Security
For autonomous cars, security is of paramount importance, and
software security is a fundamental requirement. As an indication of
the development we mention that in August 2017 UK’s Department
for Transport, published the document “Key principles of vehicle
cyber security for connected and automated vehicles” [19]. It is
built on the following eight basic principles:
(1) Organizational security is owned, governed, and promoted
at board level;
(2) Security risks are assessed and managed appropriately and
proportionately, including those specific to the supply chain;
(3) Organizations need product aftercare and incident response
to ensure systems are secure over their lifetime;
(4) All organizations, including sub-contractors, suppliers, and
potential 3rd parties, work together to enhance the security
of the system;
(5) Systems are designed using a defence-in-depth approach;
(6) The security of the software is managed throughout its life-
time;
(7) The storage and transmission of data is secure and can be
controlled;
(8) The system is designed to be resilient to attacks and respond
appropriately when its defences or sensors fail.
Similar documents are mentioned, such as Microsoft Security
Development Lifecycle (SDL), SAFE Code best practices, OWASP
Comprehensive, lightweight application security process (CLASP),
and HMG Security policy framework [19].
There have been a number of attacks at car systems and sen-
sors (e.g., LIDAR and GPS) that were used to manipulate the cars
behaviour. Attacks might be inevitable, but should there be a mini-
mum security threshold to allow a self-driving car to be used? This
leads to another question: How secure must the systems and the
connections be?
In aircrafts “black boxes” are used to determine what happened
after a crash. Should this be also a part of a self-driving car?
1https://www.tesla.com/blog/master-plan-part-deux
