---
id: chunk_e8f27c603c4fbf0b
document: doc_604e4dcb676808b0
heading: Page 10
start_paragraph: 52
end_paragraph: 53
---

# Page 10

## Page 10

5 Conclusion 
In this paper, we proposed a real-time traffic sign 
detection network based on modified YOLOv5s, which 
achieves better detection performance than state-of-art 
one-stage detectors. In this work, the proposed AF-FPN 
structure improves the information extraction ability of 
feature maps and its representation ability for detecting 
multi-scale objects. And the new data augmentation 
strategy enriches the traffic sign dataset by adding 
Noise, Mosaic, and other methods to improve the 
training effect of the model. The empirical results 
verified that the proposed method could achieve 
state-of-the-art performance with a fast inference speed, 
the detection speed on the vehicle side is 95 FPS. The 
proposed method provides the input feature map of 
different receptive fields and fuses the receptive field 
pyramids for the target traffic signs. Therefore, the 
improved network can enhance the recognition 
accuracy of multi-scale targets without introducing 
additional calculations, the mAP has increased by 
4.96% compared to the original network on the 
TT100K. Due to the size of the trained model being 
small, it is easy to deploy on the mobile device of the 
vehicle and perform real-time recognition and detection 
of the road scene. However, in practical applications, a 
faster vehicle speed will cause the motion blur of the 
image, which will affect the recognition result. In the 
future, we plan to explore a better performance 
detection model for high-speed moving targets.
