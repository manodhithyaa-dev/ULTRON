---
id: chunk_dd078bcfbf16902a
document: doc_6ac2027a878dbe19
heading: Page 5
start_paragraph: 9
end_paragraph: 10
---

# Page 5

## Page 5

2.4
Summary of the variations
For any local action S, the CPS formalism provides, a unique (pre)symplectic space of solutions:
Ψ : Ω0(F) →Sympl
given by
Ψ(S) =

{Φ ∈F : EOMi(Φ) = 0}, ΩS

defined via equations (1), (5) and (6) using any representative L of S. In practice, it is better to
operate at the Lagrangian level, where the relevant map is
Λ :
Ω(n,0)(M × F)
−→
Ωn(M) × Ω(n−1,1)(M × F)
L
7−→
(EOMi, Θ + dZ)
(8)
The symplectic potential is determined up to the dZ ambiguity discussed in subsection 2.3.
Remarks.
2.2. Ψ(SdY ) = (F, 0). The trivial action yields the full field space with a zero presymplectic form.
2.3. Λ(dY ) = (0, dY + dZ). A total derivative Lagrangian has vanishing equations of motion, and
its symplectic potential inherits the aforementioned ambiguities.
2.5
Variational vector fields
In classical mechanics, transformations like rotations or translations take place in the space of
coordinates. Rather than working with finite transformations, which form a group, we usually
work with infinitesimal transformations, which form an algebra, i.e., vector fields over the space of
coordinates. In field theories, the role of coordinates is played (loosely speaking) by tensor fields, so
an infinitesimal transformation is a vector field X ∈X(F), called a variational vector field (VVF).
For a tensorial field Φi, we define XΦi := Ψi ∈TΦF. Here, Ψi satisfies the linearized conditions of
Φi so, in particular, shares its index character. Setting aside infinite-dimensional subtleties [18], X
can be equivalently understood as a derivation via the Lie derivative of F:
XΦi := Ψi
≡
LXΦi := Ψi
≡
iXdΦi := Ψi
(9)
Remark 2.4. The last two formulas are related via Cartan’s magic formula over F (which holds
for a broad class of VVFs but not all, see subsection 4.3): LX = iXd + diX.
The last expression of equation (9) serves as an implicit definition of X as a map acting on 1-forms
via the interior product. This enables a formal expression analogous to the finite-dimensional case:
ξ =
n
X
j=1
ιξ(dxj) ∂
∂xj
∈X(M)
X =
Z
M
iX(dΦi) δ
δΦi ∈X(F)
(10)
These expressions conveniently package their respective components, {ιξ(dxj)}j and {iX(dΦi)}i,
into a single geometric object. While equation (10) is purely formal, it is highly practical for
implementing VVFs in xCPS, as demonstrated in subsection 4.2.
Example 3:
Given ξ ∈X(M), we define Xξ ∈X(F) as the infinitesimal action of Diff(M):
iXξdΦi := LξΦi
≡
LXξΦi := LξΦi
≡
Xξ =
Z
M
LξΦi δ
δΦi
(11)
The action of Xξ generates, loosely speaking, the transformation Φi 7→Φi + εLξΦi + O(ε2).
Notice that in the physics literature, this is frequently denoted as δξΦ = LξΦi.
5
