---
id: chunk_ef20ecf5a069384d
document: doc_6ac2027a878dbe19
heading: Page 17
start_paragraph: 33
end_paragraph: 34
---

# Page 17

## Page 17

One of the most interesting features of ExpandVertDiff is the option HoldExpandVertDiff, which
acts as a circuit breaker to prevent deeper recursive expansion. For instance, it allows one to expand
the variation of the Riemann tensor in terms of dΓ rather than unwinding it down to dg:
In[24]:= expr = VertDiff[RiemannLCDer[-a,-b,-c,-d]];
expr // ExpandVertDiff[] // ContractMetric // Simplification
expr // ExpandVertDiff[HoldExpandVertDiff→ChristoffelLCDer]
,→// ContractMetric // Simplification
Out[25]=
1
2(−DaDb(dg)cd −DaDc(dg)bd + DaDd(dg)bc + DbDa(dg)cd + DbDc(dg)ad −DbDd(dg)ac)
Out[26]= Db(dΓ[D])dac −Da(dΓ[D])dbc
Another essential option is ConstantTensors, which indicates the list of tensors to be considered
as constant (non-dynamic). As explained in the previous section for VariationalRelationsOf,
these constant tensors might force other tensors to be constant.
In[27]:= expr = VertDiff[RicciScalarLCDer[]];
expr // ExpandVertDiff[] // ContractMetric // Simplification
expr // ExpandVertDiff[HoldExpandVertDiff→RiemannLCDer]
,→
// ContractMetric // Simplification
expr // ExpandVertDiff[ConstantTensors→RiemannLCDer] // ContractMetric
,→// Simplification
Out[28]= −(dg)abR[D]ab + DbDa(dg)ab −DbDb(dg)aa
Out[29]= (dR[D])abab −2(dg)abR[D]ab
Out[30]= −2(dg)abR[D]ab
The option NonConstantTensors is the opposite of ConstantTensors, providing the list of dynam-
ical tensors by enforcing every other tensor to be constant.
4.6
ExpandVertInt
ExpandVertInt behaves to VertInt as ExpandVertDiff behaves to VertDiff, with the additional
rule explained when we introduced equation (10):
icoeff[inds1]∧
δ
δtensori [-inds1]]
h
dtensorj[inds2]
i
= 0
if i̸ = j
coeff[inds2]
if i = j
(32)
This is the infinite-dimensional version of
ιf(⃗x)
∂
∂xi
h
dxji
= 0
if i̸ = j
f(⃗x)
if i = j
(33)
Before applying the rule of equation (32), ExpandVertInt calls ExpandVertDiff with the option
HoldExpandVertDiff active for the field tensori, the unique tensor whose variational vector
δ
δtensori appears in the VVF. This ensures that the matching condition of equation (32) is checked
before dtensorj is expanded into more primitive variations.
Remark 4.8. The VVF knows how to act over dtensor (vertically exact forms). If we want to
define a VVF acting over non-exact vertical k-forms, we need DefGeneralizedVVF but, for brevity,
we do not discuss it further here and refer the interested reader to the xCPS documentation.
4.7
Divergences and reconstruction of potentials
In this subsection, we introduce two of the most powerful tools of xCPS, both of independent interest
beyond the CPS formalism: DivergenceQ and FindPotentialGradient. The former checks if an
expression is a total divergence expr=∇aV a and the latter attempts to find the potential.
17
