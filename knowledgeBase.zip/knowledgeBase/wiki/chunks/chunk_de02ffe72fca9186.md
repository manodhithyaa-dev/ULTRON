---
id: chunk_de02ffe72fca9186
document: doc_604e4dcb676808b0
heading: Page 3
start_paragraph: 9
end_paragraph: 10
---

# Page 3

## Page 3

Moreover, FPN pays too much attention to the 
extraction and optimization of low-level features. As 
the number of channels decreases, high-level features 
will lose a lot of information, resulting in a decrease in 
the detection accuracy of large-scale targets [22]. In 
response to this problem, a simple yet effective method 
named receptive field pyramid (RFP) [26] is proposed 
to enhance the representation ability of feature 
pyramids and drive the network to learn the optimal 
feature fusion pattern [14].
