---
id: chunk_d0a63c92c0e66d26
document: doc_27960becbcfef01d
heading: Page 2
start_paragraph: 2
end_paragraph: 3
---

# Page 2

## Page 2

ARXIV’18, January 2018, Gothenburg, Sweden
Tobias Holstein and Gordana Dodig-Crnkovic, Patrizio Pelliccione
It is worth to notice that the engineering problem is substantially
different from the hypothetical ethical dilemma. While an ethical
dilemma is an idealized constructed state that has no good solution,
an engineering problem is always by construction such that it can
differentiate between better and worse solutions. A decision mak-
ing process that has to be implemented in a self-driving car can be
summarized as follows. It starts with an awareness of the environ-
ment: Detecting obstacles, such as a group of humans, animals or
buildings, and also the current context/situation of the car using
external systems (GPS, maps, street signs, etc.) or locally available
information (speed, direction, etc.). Various sensors have to be used
to collect all required information. Gaining detailed information
about obstacles would be a necessary step before a decision can be
made that maximizes utility and/or minimizes damage. A computer
program calculates solutions and chooses the solution with the op-
timal outcome. The self-driving car executes the calculated action
and the process repeats itself.
The process itself can be used to identify concrete ethical chal-
lenges within the decision making by considering the current state
of the art of technology and its development. In a concrete car
both the parts of this complex system and the way in which it is
created have a critical impact on the decision-making. This includes
for instance the quality of sensors, code, and testing. We also see
ethical challenges in design decisions, such as whether a certain
technology is used because of its lower price, even though the qual-
ity of information for the decision making would be substantially
increased if more expensive technology (such as sensors) would be
used.
Since building and engineering of self-driving vehicle involve
various stakeholders, such as software/hardware engineers, sales
people, management, etc., we can also pose the following questions:
does the actual self-driving car have a moral on its own or is it
the moral of its creators? And who is to blame for the decision
making of a self-driving car? In [22] the argument is put forward
that the systemic view must be used in case of socio-technological
systems. Thus the problems in the system can originate or be a com-
bination coming from inadequate solutions in various steps from
requirements specification to implementation, testing, deployment
maintenance, safety regulation and other normative support etc.
Besides the self-driving vehicle itself, it is also important to
address yet another complex system: self-driving vehicles partici-
pating in public traffic among cars with human drivers. Therefore,
it is important to investigate how self-driving vehicles are actually
built, how ethical challenges are addressed in their design, produc-
tion, and use and how certain decisions are justified. Discussing this
before self-driving vehicles are officially introduced into the market,
allows taking part in the setting and definition of ethical ground
rules. McBride states that “Issues concerning safety, ethical decision
making and the setting of boundaries cannot be addressed without
transparency” [43]. We think that transparency is only one factor,
as it is necessary to start further investigations and discussions.
In order to give a more detailed perspective on the complex de-
cision making process, we propose to create a conceptual ethical
model that connects the different components, systems and stake-
holders. It shows inter-dependencies and allows pinpointing ethical
challenges that will be presented in the concluding recommenda-
tions.
Focusing on important ethical challenges that should currently
be addressed and solved is an important step before ethical aspects
of self-driving cars can actually be meaningfully discussed from
the point of view of societal and individual stakeholders as well as
designers and producers. It is important to focus not on abstract
thought experiments but on concrete conditions that influence
the behavior of self-driving cars and their safety as well as our
expectations from them.
The paper is structured as follows. A short introduction to self-
driving cars and their current state of the art is provided in Section 2,
with the emphasis on the description of the decision making prin-
ciples given in Section 2.1 and the role of software in Section 2.2.
Ethical and social challenges are addressed in Section 3 regarding
technical aspects, and Section 4 addressing social aspects. Section 5
describes the current state of norms and standards, while conclu-
sions and final remarks are presented together with recommenda-
tions in Section 6.
2
SELF-DRIVING CARS BASICS
The term "autonomous" could be ambiguous to some readers. It
can be used to describe certain autonomous features or functions,
such as advanced driver assistance systems, that for example assist
the driver in keeping the lane or adjust to the speed of vehicles
ahead. Those systems are designed to assist, but the driver is always
responsible and has to intervene if critical situations occur.
We use the term "self-driving" cars to avoid wrong interpreta-
tions of the terms "fully autonomous" or "driverless". Self-driving
cars refer to cars that may operate self-driving without human help
or even without a presence of human being. This means that the un-
occupied car can drive from place A to B to pick up someone. This
is the highest level of autonomy for cars and corresponds to the last
level of five as defined by the Society of Automotive Engineers [51]
and United States National Highway Traffic Safety Administration
(NHTSA), who, since September 2016, adopted SAE’s classification
with level 1 (no automation), level 2 (drive assistance), level 3 (par-
tial automation), level 4 (conditional automation), and level 5 (full
automation) [45, p.9].
A concrete example is the self-driving Waymo car [65], former
known as the Google car [35], a fully autonomous and self-driving
vehicle.
2.1
Decision Making Process in Self-Driving
Cars
Developing self-driving cars that act without a driver means to
replace a human, who today is performing the complex tasks of
driving, with a computer system executing the same tasks. Figure 1
shows both variants and allows a comparison.
There is an important difference in the feedback loop. While
humans continuously learn, for example from their mistakes or
misbehaviour, automotive software might be confined to slow up-
dates. Approaches with self-adaptive software, such as machine
learning approaches, which learns and reacts immediately, aim
to overcome this constraint. Extraordinary road signs for exam-
ple, which are new to the self-driving car’s software, present a
risk as they can pass unnoticed/uninterpreted, while they could
be understood by a human through context/interpretation. Also
