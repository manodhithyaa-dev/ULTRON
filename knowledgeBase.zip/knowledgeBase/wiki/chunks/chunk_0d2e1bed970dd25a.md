---
id: chunk_0d2e1bed970dd25a
document: doc_4a9484dd924d39f9
heading: Page 18
start_paragraph: 36
end_paragraph: 37
---

# Page 18

## Page 18

FIG. 5. Instantaneous Dirac-oscillator component ladders as functions of ct/R. Solid lines show
the upper-component equation with index n; dashed lines show the lower-component equation,
whose index is shifted by one relative to the physical spinor level. Three values of n are shown,
with ℏω/(m0c2) = 0.5.
The dotted curve indicates mapp(t).
The upper-component state with
N = 0 coincides with mapp(t) at all times, generalizing the standard Dirac-oscillator ground state
E = ±m0 to the FL-deformed setting.
component equations of one and the same Dirac spinor. A physical eigenstate has a common
energy in both components, so that the level with upper oscillator index N is paired with
the lower oscillator index N −1 for N ≥1, while the N = 0 state has only the upper
component. Equivalently, the physical instantaneous spectrum is
E2
N(t) =
m2
0
(1 + ct/R)2 +
2m0ω
1 + ct/R N,
N = 0, 1, 2, . . . .
(51)
The component ladders that build this physical spectrum are displayed in Fig. 5.
The
apparent offset between the upper and lower curves is the usual Dirac-oscillator component-
index shift; it is not an additional spin splitting in one spatial dimension.
In the special-relativistic limit R →∞, the N = 0 state satisfies E = ±m0, reproducing
the standard one-dimensional Dirac-oscillator ground state [15]. In the FL-deformed theory,
this rest-energy level evolves according to E = ±mapp(t) = ±m0/(1 + ct/R). As in the
18
