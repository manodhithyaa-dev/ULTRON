---
id: chunk_a424d062cbc9fe4f
document: doc_6ac2027a878dbe19
heading: Page 16
start_paragraph: 31
end_paragraph: 32
---

# Page 16

## Page 16

Out[15]=
Out[16]=
This dependency graph is essential for computing variational derivatives, since only the dynamical
fields must be taken into account. Several commands presented on section 5 make use of the func-
tion VariationallyConstantQ[ConstantTensors,{}][tensor], which returns True if tensor is
variationally constant (red square in the graph) and False otherwise.
4.5
ExpandVertDiff
ExpandVertDiff[][expr] expands the vertical exterior derivative of expr. It operates analogously
to ExpandPerturbation from xPert [8], but incorporates significant additional capabilities.
We can use GenerateExpandVertDiffRule[{dltensor,expansion},options] to generate the
expansion rule dltensor→expansion to be used by ExpandVertDiff. A rule can be removed with
RemoveExpandVertDiffRule[dltensor].
In[17]:= DefTensor[beta[-a,-b],M,VertDeg→2,PrintAs→"β"]
GenerateExpandVertDiffRule[dlbeta[-a,-b],dlalpha[-a]∧alpha[-b]]
dlbeta[-a,-b] == (dlbeta[-a,-b] // ExpandVertDiff[])
Out[19]= (dβ)ab = (dα)a ∧αb
ExpandVertDiff[] is applied recursively. Note that xCPS does not perform infinite-loop checks.
In[20]:= GenerateExpandVertDiffRule[dlalpha[-a],alpha[b]∧dlg[-a,-b]]
dlbeta[a,-b] == (dlbeta[a,-b] // ExpandVertDiff[])
Out[21]= (dβ)ab = gcdαd ∧(dg)ac ∧αb
ExpandVertDiff expands expressions involving LieD, CovD, and Bracket using predefined rules,
such as equation (31). Most of these rules can be toggled off via options like ExpandVertDiffLieD,
ExpandVertDiffCovD, and ExpandVertDiffBracket, which are all True by default.
In[22]:= VertDiff[LCDer[-a][alpha[-b]]] == (VertDiff[LCDer[-a][alpha[-b]]]
,→// ExpandVertDiff[] //ContractMetric // Simplification)
Out[22]= d[Daαb] = 1
2(3αc ∧Da(dg)bc + αc ∧Db(dg)ac −αc ∧Dc(dg)ab + 2Daαc ∧(dg)bc)
Finally, ExpandVertDiff also handles tensors defined alongside a CovD or metric, such as Riemann,
Ricci, and Torsion, using predefined rules like equation (30):
In[23]:= VertDiff[ChristoffelLCDer[a,-b,-c]] == (VertDiff[ChristoffelLCDer[a,-b,-c]]
,→
// ExpandVertDiff[] )
Out[23]= (dΓ[D])abc = 1
2gad(Db(dg)dc + Dc(dg)bd −Dd(dg)bc)
16
