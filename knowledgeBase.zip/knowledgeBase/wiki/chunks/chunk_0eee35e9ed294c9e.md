---
id: chunk_0eee35e9ed294c9e
document: doc_4a9484dd924d39f9
heading: Page 15
start_paragraph: 30
end_paragraph: 31
---

# Page 15

## Page 15

FIG. 4. Instantaneous Klein–Gordon oscillator spectrum En(t)/m0c2, Eq. (37), as a function of ct/R
for several quantum numbers n. The dimensionless ratio ℏω/(m0c2) = 0.5 is used for illustration.
The dashed line shows the rest-mass curve mapp(t) = m0/(1 + ct/R). As t increases, all levels
approach zero. In the late-time, oscillator-dominated regime, the positive-energy levels scale as
En ∝
p
mapp(t) ω ∝(1 + ct/R)−1/2 for fixed n.
B.
Non-adiabatic correction and particle production
A non-adiabatic correction to Eq. (37) is associated with the parametric-oscillator struc-
ture of the underlying mode equation (18). Bogoliubov techniques [18] express the produced
particle number per mode as |βk|2. For an analytic, slowly varying frequency with no real
zero, WKB estimates give the generic non-perturbative behaviour
|βk|2 ≲exp

−Ck/ηmax

,
(38)
where ηmax is the peak value of the adiabatic parameter and Ck is a positive coefficient
determined by the nearest complex turning point. One should therefore not attach universal
significance to the precise numerical coefficient in the exponent; the robust conclusion is the
exponential suppression when ηmax ≪1. For the cosmological time dependence considered
here, the system is, to an excellent approximation, adiabatically invariant.
15
