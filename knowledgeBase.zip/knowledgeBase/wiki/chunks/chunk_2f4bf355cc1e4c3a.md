---
id: chunk_2f4bf355cc1e4c3a
document: doc_4a9484dd924d39f9
heading: Page 20
start_paragraph: 40
end_paragraph: 41
---

# Page 20

## Page 20

universal factor (1+ct/R)−1. Figures 4 and 5 then show how this factor propagates into the
KG and Dirac oscillator spectra. In these examples, the illustrative choice ℏω/(m0c2) = 0.5
is deliberately large so that the separation between the rest-mass and oscillator contribu-
tions remains visible. For atomic or molecular systems, the same curves would be compressed
extremely close to the special-relativistic limit on laboratory time scales.
These plots are useful for two reasons. First, they confirm that the apparent-mass drift
produces a monotonic spectral collapse only in the asymptotic limit t →∞, and not at finite
time. Second, they show that the KG and Dirac oscillators share the same global scaling but
differ in their component-dependent structure: the lower Dirac component is shifted by one
oscillator quantum relative to the upper component, and this component-index structure is
progressively compressed as mapp(t) decreases.
C.
Adiabaticity and non-adiabatic effects
The validity of the oscillator adiabatic approximation is controlled by the dimensionless
parameter ϵ = c/(Rω) introduced in Eq. (35), while the free-field mode analysis is governed
by ηk in Eq. (22). For microscopic oscillator frequencies and a cosmological value of R, both
quantities are extremely small. Moreover, after the correction displayed in Eq. (23), the
massive-sector value of ηk is constant rather than growing with time, and fixed nonzero-
k modes become increasingly adiabatic. In the language of Bogoliubov transformations,
the particle-production probability is non-perturbatively suppressed, generically as |βk|2 ≲
exp[−O(1/ηmax)], which places such effects far beyond present observational sensitivity for
cosmological values of R.
D.
Geometric and operational interpretation
The auxiliary coordinates introduced in Eq. (24) demonstrate that the modified KG equa-
tion can be mapped, to leading order in 1/R, onto a constant-mass KG equation expressed
in rescaled variables. This observation supports the interpretation of mapp(t) as an apparent
mass associated with the use of FL laboratory coordinates rather than of natural comoving
variables. The same conformal factor appears in both the original FL spacetime construction
and the momentum-space dualization, indicating that the spectral drift is intrinsically tied
20
