---
id: chunk_8d43dd5bdff67b11
document: doc_a8343f0236b29082
heading: Page 13
start_paragraph: 24
end_paragraph: 25
---

# Page 13

## Page 13

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
13
[54] J.-Y. Kim and S.-B. Cho, “Electric energy consumption prediction by
deep learning with state explainable autoencoder,” Energies, vol. 12,
no. 4, p. 739, 2019.
[55] B. Sirmacek and M. Riveiro, “Occupancy prediction using low-cost
and low-resolution heat sensors for smart ofﬁces,” Sensors, vol. 20,
no. 19, p. 5497, 2020.
[56] S. S. Amiri, S. Mottahedi, E. R. Lee, and S. Hoque, “Peeking inside the
black-box: Explainable machine learning applied to household trans-
portation energy consumption,” Computers, Environment and Urban
Systems, vol. 88, p. 101647, 2021.
[57] K. Barrett-Powell, J. Furby, L. Hiley, M. R. Vilamala, H. Taylor,
F. Cerutti, A. Preece, T. Xing, L. Garcia, M. Srivastava et al., “An
experimentation platform for explainable coalition situational under-
standing,” arXiv preprint arXiv:2010.14388, 2020.
[58] I. Kalamaras, I. Xygonakis, K. Glykos, S. Akselsen, A. Munch-
Ellingsen, H. T. Nguyen, A. J. Lepperod, K. Bach, K. Votis, and
D. Tzovaras, “Visual analytics for exploring air quality data in an ai-
enhanced iot environment,” in Proceedings of the 11th International
Conference on Management of Digital EcoSystems, 2019, pp. 103–110.
[59] G. Graham, N. Csicsery, E. Stasiowski, G. Thouvenin, W. H. Mather,
M. Ferry, S. Cookson, and J. Hasty, “Genome-scale transcriptional
dynamics and environmental biosensing,” Proceedings of the National
Academy of Sciences, vol. 117, no. 6, pp. 3301–3306, 2020.
[60] D. Thakker, B. K. Mishra, A. Abdullatif, S. Mazumdar, and S. Simpson,
“Explainable artiﬁcial intelligence for developing smart cities solu-
tions,” Smart Cities, vol. 3, no. 4, pp. 1353–1382, 2020.
[61] M. Ryo, B. Angelov, S. Mammola, J. M. Kass, B. M. Benito, and
F. Hartig, “Explainable artiﬁcial intelligence enhances the ecological
interpretability of black-box species distribution models,” Ecography,
vol. 44, no. 2, pp. 199–205, 2021.
[62] A. B. Diallo, H. Nakagawa, and T. Tsuchiya, “An explainable deep
learning approach for adaptation space reduction,” in 2020 IEEE In-
ternational Conference on Autonomic Computing and Self-Organizing
Systems Companion (ACSOS-C).
IEEE, 2020, pp. 230–231.
[63] S. Sachan, J.-B. Yang, D.-L. Xu, D. E. Benavides, and Y. Li, “An
explainable ai decision-support-system to automate loan underwriting,”
Expert Systems with Applications, vol. 144, p. 113100, 2020.
[64] N. Bussmann, P. Giudici, D. Marinelli, and J. Papenbrock, “Explainable
machine learning in credit risk management,” Computational Eco-
nomics, vol. 57, no. 1, pp. 203–216, 2021.
[65] A. Gramegna and P. Giudici, “Why to buy insurance? an explainable
artiﬁcial intelligence approach,” Risks, vol. 8, no. 4, p. 137, 2020.
[66] S. Gite, H. Khatavkar, K. Kotecha, S. Srivastava, P. Maheshwari, and
N. Pandey, “Explainable stock prices prediction from ﬁnancial news
articles using sentiment analysis,” PeerJ Computer Science, vol. 7, p.
e340, 2021.
[67] D. R. Chittajallu, B. Dong, P. Tunison, R. Collins, K. Wells, J. Flesh-
man, G. Sankaranarayanan, S. Schwaitzberg, L. Cavuoto, and A. En-
quobahrie, “Xai-cbir: Explainable ai system for content based retrieval
of video frames from minimally invasive surgery videos,” in 2019 IEEE
16th International Symposium on Biomedical Imaging (ISBI 2019).
IEEE, 2019, pp. 66–69.
[68] M. S. Hossain, G. Muhammad, and N. Guizani, “Explainable ai and
mass surveillance system-based healthcare framework to combat covid-
i9 like pandemics,” IEEE Network, vol. 34, no. 4, pp. 126–132, 2020.
[69] W. S. Monroe, F. M. Skidmore, D. G. Odaibo, and M. M. Tanik, “Hiho:
accelerating artiﬁcial intelligence interpretability for medical imaging
in iot applications using hierarchical occlusion,” Neural Computing and
Applications, vol. 33, no. 11, pp. 6027–6038, 2021.
[70] A. Pnevmatikakis, S. Kanavos, G. Matikas, K. Kostopoulou, A. Ce-
sario, and S. Kyriazakos, “Risk assessment for personalized health
insurance based on real-world data,” Risks, vol. 9, no. 3, p. 46, 2021.
[71] J. Hatwell, M. M. Gaber, and R. M. Atif Azad, “Ada-whips: explaining
adaboost classiﬁcation with applications in the health sciences,” BMC
Medical Informatics and Decision Making, vol. 20, no. 1, pp. 1–25,
2020.
[72] D. Dave, H. Naik, S. Singhal, and P. Patel, “Explainable ai
meets healthcare: A study on heart disease dataset,” arXiv preprint
arXiv:2011.03195, 2020.
[73] N. Gozzi, L. Malandri, F. Mercorio, and A. Pedrocchi, “Xai for myo-
controlled prosthesis: Explaining emg data for hand gesture classiﬁca-
tion,” Knowledge-Based Systems, p. 108053, 2022.
[74] J.-R. Rehse, N. Mehdiyev, and P. Fettke, “Towards explainable pro-
cess predictions for industry 4.0 in the dfki-smart-lego-factory,” KI-
Künstliche Intelligenz, vol. 33, no. 2, pp. 181–187, 2019.
[75] H.-Y. Chen and C.-H. Lee, “Vibration signals analysis by explainable
artiﬁcial intelligence (xai) approach: Application on bearing faults
diagnosis,” IEEE Access, vol. 8, pp. 134 246–134 256, 2020.
[76] K. H. Sun, H. Huh, B. A. Tama, S. Y. Lee, J. H. Jung, and S. Lee,
“Vision-based fault diagnostics using explainable deep learning with
class activation maps,” IEEE Access, vol. 8, pp. 129 169–129 179, 2020.
[77] O. Serradilla, E. Zugasti, C. Cernuda, A. Aranburu, J. R. de Okariz, and
U. Zurutuza, “Interpreting remaining useful life estimations combining
explainable artiﬁcial intelligence and domain knowledge in industrial
machinery,” in 2020 IEEE International Conference on Fuzzy Systems
(FUZZ-IEEE).
IEEE, 2020, pp. 1–8.
[78] J. Senoner, T. Netland, and S. Feuerriegel, “Using explainable artiﬁcial
intelligence to improve process quality: Evidence from semiconductor
manufacturing,” Management Science, 2021.
[79] N. Mehdiyev and P. Fettke, “Explainable artiﬁcial intelligence for
process mining: A general overview and application of a novel local
explanation approach for predictive process monitoring,” Interpretable
Artiﬁcial Intelligence: A Perspective of Granular Computing, pp. 1–28,
2021.
[80] L. C. Brito, G. A. Susto, J. N. Brito, and M. A. Duarte, “An explainable
artiﬁcial intelligence approach for unsupervised fault detection and
diagnosis in rotating machinery,” Mechanical Systems and Signal
Processing, vol. 163, p. 108105, 2022.
[81] M. Saharkhizan, A. Azmoodeh, A. Dehghantanha, K.-K. R. Choo, and
R. M. Parizi, “An ensemble of deep recurrent neural networks for
detecting iot cyber attacks using network trafﬁc,” IEEE Internet of
Things Journal, vol. 7, no. 9, pp. 8852–8859, 2020.
[82] I. A. Khan, N. Moustafa, D. Pi, K. M. Sallam, A. Y. Zomaya, and
B. Li, “A new explainable deep learning framework for cyber threat
discovery in industrial iot networks,” IEEE Internet of Things Journal,
2021.
[83] M. Sarhan, S. Layeghy, and M. Portmann, “An explainable machine
learning-based network intrusion detection system for enabling gener-
alisability in securing iot networks,” arXiv e-prints, pp. arXiv–2104,
2021.
[84] B. Mahbooba, M. Timilsina, R. Sahal, and M. Serrano, “Explainable
artiﬁcial intelligence (xai) to enhance trust management in intrusion
detection systems using decision tree model,” Complexity, vol. 2021,
2021.
[85] A. Nascita, A. Montieri, G. Aceto, D. Ciuonzo, V. Persico, and
A. Pescapé, “Xai meets mobile trafﬁc classiﬁcation: Understanding and
improving multimodal deep learning architectures,” IEEE Transactions
on Network and Service Management, vol. 18, no. 4, pp. 4225–4246,
2021.
[86] M. Zolanvari, Z. Yang, K. Khan, R. Jain, and N. Meskin, “Trust xai:
Model-agnostic explanations for ai with a case study on iiot security,”
IEEE Internet of Things Journal, 2021.
[87] T.-T.-H. Le, H. Kim, H. Kang, and H. Kim, “Classiﬁcation and
explanation for intrusion detection system based on ensemble trees
and shap method,” Sensors, vol. 22, no. 3, p. 1154, 2022.
[88] N. Kundu, G. Rani, V. S. Dhaka, K. Gupta, S. C. Nayak, S. Verma,
M. F. Ijaz, and M. Wo´zniak, “Iot and interpretable machine learning
based framework for disease prediction in pearl millet,” Sensors,
vol. 21, no. 16, p. 5386, 2021.
[89] C. M. Viana, M. Santos, D. Freire, P. Abrantes, and J. Rocha,
“Evaluation of the factors explaining the use of agricultural land: A
machine learning and model-agnostic approach,” Ecological Indicators,
vol. 131, p. 108200, 2021.
[90] M. C. Garrido, J. M. Cadenas, A. Bueno-Crespo, R. Martínez-España,
J. G. Giménez, and J. M. Cecilia, “Evaporation forecasting through
interpretable data analysis techniques,” Electronics, vol. 11, no. 4, p.
536, 2022.
[91] J. Danielsson, R. Macrae, and A. Uthemann, “Artiﬁcial intelligence
and systemic risk,” Journal of Banking & Finance, p. 106290, 2021.
[92] E. Oyekanlu, “Distributed osmotic computing approach to implemen-
tation of explainable predictive deep learning at industrial iot network
edges with real-time adaptive wavelet graphs,” in 2018 IEEE First
International Conference on Artiﬁcial Intelligence and Knowledge
Engineering (AIKE).
IEEE, 2018, pp. 179–188.
[93] I. T. Christou, N. Kefalakis, A. Zalonis, and J. Soldatos, “Predictive
and explainable machine learning for industrial internet of things
applications,” in 2020 16th International Conference on Distributed
Computing in Sensor Systems (DCOSS).
IEEE, 2020, pp. 213–218.
[94] Y. Liu, J. Wang, J. Li, S. Niu, and H. Song, “Zero-bias deep learning
enabled quick and reliable abnormality detection in iot,” arXiv preprint
arXiv:2105.15098, 2021.
