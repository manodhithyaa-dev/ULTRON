---
id: chunk_a2a2c117fbd51e0e
document: doc_6ac2027a878dbe19
heading: Page 3
start_paragraph: 5
end_paragraph: 6
---

# Page 3

## Page 3

2
Mathematical background
This section summarizes the mathematical foundation underlying xCPS. We consider an n-manifold
without boundary M and a space of tensorial fields F over M. Both spaces are naturally endowed
with an exterior derivative: d for M and d for F, (horizontal and vertical directions of the variational
bicomplex [1]). Following the standard physics convention, we assume they commute.
2.1
First variation
Consider a local Lagrangian L : F →Ωn(M), i.e., a top-form depending on the fields of F and
finitely many of their derivatives. Equivalently, L ∈Ω(n,0)(M × F) is a bi-graded (n, 0)-form over
M × F (see [1, 18]). The fundamental CPS identity is the canonical decomposition of the first
variation:
dL = EOMidΦi + dΘ
(1)
where EOMi ∈Ω(n,0)(M×F) is the Euler-Lagrange (EL) form whose kernel provides the solution to
the equations of motion1 EOMi = 0 associated with the dynamical field Φi ∈F; Θ ∈Ω(n−1,1)(M×F)
is a symplectic potential; and dΦi acts as an infinitesimal variation of the field Φi, analogous to
dx, dy, dz in R3. The global decomposition (1) holds under mild regularity conditions [1, 18] and is
achieved in practice by repeatedly applying the Leibniz rule to remove derivatives from dΦi.
Remark 2.1. In the physics literature, the equations of motion are often denoted as EOMi =: δL
δΦi .
Example 1:
Given a fixed metric g, consider the Lagrangian of a scalar field theory given by
Lscl(ϕ) = 1
2∇aϕ∇aϕ volg
(2)
where volg is the metric volume form. Its vertical exterior derivative is
dLscl = 1
2∇adϕ∇aϕ volg + 1
2∇aϕ∇adϕ volg = ∇adϕ∇aϕ volg
(3)
where we have used that dgab = 0. Now, using ∇gab = 0 and the Leibniz rule leads to:
dLscl = ∇a(dϕ∇aϕ)volg −dϕ∇a∇aϕ volg = EOMscl dϕ + div(⃗Uscl)volg
(4)
where Ua
scl = dϕ∇aϕ. The last term of (4) can be rewritten using L⃗Uvolg = div(⃗U)volg,
dvolg = 0, and L⃗U = ι⃗Ud + dι⃗U (ι : Ωk(M) →Ωk−1(M) is the interior product). Thus, the
first variation takes the form of equation (1) with EOMscl = −∇a∇aϕvolg ∈Ω(n,0)(M × F)
the EL form of ϕ (whose kernel is the solutions to the wave equation ∇a∇aϕ = 0) and
Θscl = ι⃗Usclvolg ∈Ω(n−1,1)(M × F) a symplectic potential.
2.2
Symplectic form
For a given symplectic potential Θ, we define its symplectic current as
ω = dΘ ∈Ω(n−1,2)(M × F)
(5)
Integrating the horizontal part of ω over an (n−1)-dimensional submanifold Σ ⊂M yields a 2-form
on F. The natural choice is to take Σ a Cauchy surface. We then define the (pre)symplectic form
ΩΣ =
Z
Σ
ı∗ω ∈Ω2(F)
(6)
1To avoid cluttering the notation, we assume that Φi has horizontal degree k = 0, though it can have any index
structure. If Φi is a k-form with k̸ = 0, we have EOMi ∈Ω(n−k,0)(M × F) and dL = EOMi ∧dΦi + dΘ, with the
remaining arguments unchanged.
3
