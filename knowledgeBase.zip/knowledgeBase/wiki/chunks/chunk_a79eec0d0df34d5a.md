---
id: chunk_a79eec0d0df34d5a
document: doc_27960becbcfef01d
heading: Page 1
start_paragraph: 0
end_paragraph: 1
---

# Page 1

## Page 1

Ethical and Social Aspects of Self-Driving Cars
Tobias Holstein
Mälardalen University
Västerås, Sweden
tobias.holstein@mdh.se
Gordana Dodig-Crnkovic, Patrizio Pelliccione
Chalmers University of Technology | University of
Gothenburg
Gothenburg, Sweden
[gordana.dodig-crnkovic,patrizio]@chalmers.se
ABSTRACT
As an envisaged future of transportation, self-driving cars are being
discussed from various perspectives, including social, economical,
engineering, computer science, design, and ethics. On the one hand,
self-driving cars present new engineering problems that are being
gradually successfully solved. On the other hand, social and ethical
problems are typically being presented in the form of an idealized
unsolvable decision-making problem, the so-called trolley problem,
which is grossly misleading. We argue that an applied engineering
ethical approach for the development of new technology is what
is needed; the approach should be applied, meaning that it should
focus on the analysis of complex real-world engineering problems.
Software plays a crucial role for the control of self-driving cars;
therefore, software engineering solutions should seriously handle
ethical and social considerations. In this paper we take a closer
look at the regulative instruments, standards, design, and imple-
mentations of components, systems, and services and we present
practical social and ethical challenges that have to be met, as well
as novel expectations for software engineering.
CCS CONCEPTS
• Computer systems organization →Embedded systems; Re-
dundancy; Robotics; • Networks →Network reliability;
KEYWORDS
Self-Driving Cars, Autonomous Cars, Trolley Problem, Decision
Making, Ethics, Social Aspects, Software Engineering, Challenges
1
INTRODUCTION
Increasingly, prototypical self-driving vehicles are participating in
public traffic [48] and are planned to be sold starting in 2020 [56, 61].
Public awareness and media coverage contribute to a manifold of
discussions about self-driving vehicles. This is currently amplified
through recent accidents with autonomous vehicles [24, 58].
Software is playing a key role in modern vehicles and in self-
driving vehicles. Gigabytes of software run inside the Electronic
Control Units (ECUs), which are small computers embedded in
the vehicle. The number of ECUs has grown in the last 20 years
from 20 to more than 100. Software in cars is growing by a factor
of 10 every 5 to 7 years, and in some sense car manufacturers
are becoming software companies [47]. These novelties ask for a
change on how the software is engineered and produced and for a
disruptive renovation of the electrical and software architecture of
the car, as testified by the effort of Volvo Cars [47].
Moreover, self-driving vehicles will be connected with other ve-
hicles, with the manufacturer cloud, e.g., for software upgrades,
with Intelligent Transport Systems (ITS), Smart Cities, and Inter-
net of Things (IoT). Self-driving vehicles will combine data from
inside vehicle with external data coming from the environment
(other vehicles, the road, signs, and the cloud). In such a scenario,
different applications will be possible: smart traffic control, better
platooning coordination, and enhanced safety in general. How-
ever, the basic assumption is that future self-driving connected
cars must be socially sustainable. A typical discussion about ethical
aspects of self-driving cars starts with ethical thought experiment,
so called “trolley problem” described in [29] and [66], that has been
discussed in number of articles in IEEE [7, 9, 33], ACM [30, 40, 43],
Scientific American [16, 37, 41], Science [11, 36], other high-profile
journals [14, 32, 34], conference workshops [8, 50] and other sources
[2, 6, 44, 54]. Here is the general scenario being discussed:
A self-driving vehicle drives on a street with a high speed. In front
of the vehicle a group of people suddenly blocks the street. The vehicle
is too fast to stop before it reaches the group. If the vehicle does not react
immediately, the whole group will be killed. The car could however
evade the group by entering the pedestrian way and consequently
killing a previously not involved pedestrian. The following alternations
of the problem exist: (A) Replacing the pedestrian with a concrete wall,
which in consequence will kill the passenger of the self-driving car;
(B) Varying the personas of people in the group, the single pedestrian
or the passenger. The use of personas allows including an emotional
perspective [10], e.g., stating that the single pedestrian is a child, a
relative, a very old or a very sick human, or a brutal dictator, who
killed thousands of people.
Even though the scenarios are similar, the responses of humans,
when asked how they would decide, differ [11]. The problem is
that the question asked has limited number of possible answers,
which are all ethically questionable and perceived as bad or wrong.
Therefore, a typical approach to this problem is to analyze the
scenarios by following ethical theories, such as utilitarianism, other
forms of consequentialism or deontological ethics [42]. For example,
utilitarianism would aim to minimize casualties, even if it means to
kill the passenger, by following the principle: the moral action is the
one that maximizes utility (or in this case minimizes the damage).
Depending on the ethics framework, different arguments can be
used to justify the decision.
Applying ethical doctrines to analyze a given dilemma and pos-
sible answers can presently only be done by humans. How would
self-driving cars solve such dilemmas? There are a number of publi-
cations that suggest to implement moral principles into algorithms
of self-driving cars [17, 18, 33]. We find that this does not solve the
problem, but it reassures that the solution is calculated based on
a given set of rules or other mechanisms, moving the problem to
engineering, where it is implemented.
arXiv:1802.04103v1  [cs.CY]  5 Feb 2018
