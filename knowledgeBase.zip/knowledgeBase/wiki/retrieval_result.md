# Graph Retrieval Result

**Query:** what is reinforcement learning

## Retrieval Statistics

- Expanded nodes: 11
- Pruned branches: 0
- LLM calls: 7
- Candidate nodes: 11
- Final alpha: 0.7477

## Retrieved Chunks

### 1. Page 7

- Chunk: `chunk_3f0df260b036f227`
- Entity: **Data Augmentation Policy**
- Score: `0.7477`
- Document: `doc_604e4dcb676808b0`

#### Graph path

```text
Data Augmentation Policy
```

#### Content

---
id: chunk_3f0df260b036f227
document: doc_604e4dcb676808b0
heading: Page 7
start_paragraph: 40
end_paragraph: 41
---

# Page 7

## Page 7

roughly (19×D×P)2×5 possibilities and requires an 
efficient search algorithm to navigate this space [46]. 
Fig. 5 shows the policy with 5 sub-policies in the search 
space. 
Sub-policy 1
Sub-policy 2
Original
Sub-policy 5
Sub-policy 4
Sub-policy 3
Solarize_Add, 0.8, 6
Equalize, 0.8, 8
Rotate, 1.0, 10
Cutout, 1.0, 10
Posterize, 0.8, 2
Translate_X, 1.0, 8
Rotate, 0.6, 8
Rotate, 0.8, 10
Equalize, 0.8, 10
Auto_Contrast, 0.2, 10 
Fig. 5 An example of a policy with 5 sub-policies 
Through the search space, the problem of searching 
for a learned augmentation policy into a discrete 
optimization problem. Reinforcement Learning [47] is 
used as the search algorithm, which has two 
components: a controller RNN and the training 
algorithm. The controller RNN is a recurrent neural 
network, and the proximal policy optimization (PPO) 
[46] with a learning rate of 0.00035 is used as the 
network training algorithm. The controller RNN 
predicts a decision produced by a softmax at each step 
and the prediction is then fed into the next step as an 
embedding from the search space. Totally, the 
controller has 30 softmax predictions to predict 5 
sub-policies, each of which has two operations, and 
each operation requires an operation type, magnitude, 
and probability. We applied the automatic learning data 
augmentation method to the TT100K dataset, and then 
used the best data augmentation policy obtained 
through training.


---

### 2. Document

- Chunk: `chunk_a324525c8c883cb0`
- Entity: **Data Augmentation Policy**
- Score: `0.7477`
- Document: `doc_604e4dcb676808b0`

#### Graph path

```text
Data Augmentation Policy
```

#### Content

---
id: chunk_a324525c8c883cb0
document: doc_604e4dcb676808b0
heading: Document
start_paragraph: 37
end_paragraph: 39
---

# Document

1
1


B
p
i
i
y
y
B

(9)
where yp denotes the output of the branch pooling layer. 
B represents the number of parallel branches and we set 
B = 3.

3.3 Data Augmentation 
The augmentation policy consists of two parts: search 
space and search algorithm [44]. The search space 
contains 5 sub-strategies, each of which consists of two 
simple image enhancement operations applied in 
sequence. One of the sub-policies are be chosen at 
random and applied to the current image. In addition, 
each 
operation 
is 
also 
associated 
with 
two 
hyperparameters: the probability of applying the 
operation and the magnitude of the operation [10]. The 
operations we used in the experiment include the latest 
data augmentation methods such as Mosaic [13], 
SnapMix [45], Erasing, CutMix, Mixup, and Translate 
X/Y. In total, we have 15 operations in our search space. 
Each operation also comes with a default range of 
magnitude. We discretize the range of magnitude into 
D=11 values that follow the uniform distribution so that 
we can use a discrete search algorithm to find them. 
Similarly, we also discretize the probability of applying 
one of all operation into P=10 values (also following a 
uniform distribution). Finding each sub-policy becomes 
a search problem in a space of (19×D×P)2 possibilities. 
Therefore, the search space with 5 sub-policies then has


---

### 3. Page 9

- Chunk: `chunk_684b65a2e79e2632`
- Entity: **TT100K**
- Score: `0.7188`
- Document: `doc_604e4dcb676808b0`

#### Graph path

```text
TT100K
```

#### Content

---
id: chunk_684b65a2e79e2632
document: doc_604e4dcb676808b0
heading: Page 9
start_paragraph: 48
end_paragraph: 51
---

# Page 9

## Page 9

Ours
Original

(a) 
Camera
LED Screen
Jetson Xavier NX

(b) 
Fig. 8 (a) Some examples were detected by our method on the TT100K dataset; (b) The mobile device deployment 
and the detection example of shooting through the camera.
4.3 Ablation study 
To more intuitively demonstrate the better performance 
of the proposed method for traffic sign detection and 
recognition, we conduct the ablation study, and the 
results are shown in Table Ⅱ. 
Table Ⅱ 
Ablation study 
Method 
Model
Param 
FLOPS
FPS
mAP 
YOLOv5s 
14.6M
7.193M
17.9G
105 
0.6018
YOLOv5s+Aug 
16.3M
7.193M
17.9G
105 
0.6131
YOLOv5s+AF-FPN
14.6M
8.039M
17.9G
95 
0.6267
Ours 
16.3M
8.039M
17.9G
95 
0.6514
Table Ⅱ shows the ablation result of incrementally 
adding the components training on the YOLOv5s 
model. As observed from the results, the standard 
YOLOv5s provides a detection mAP of 60.18%. 
Integrating the data augmentation and the AF-FPN 
improves the mAP to 61.31% and 62.67%, respectively. 
The mAP of our method on the TT100K dataset is 
4.96% higher than that of the YOLOv5s, which means 
the proposed method achieves impressive performance 
in target and recognition. At the same time, the model 
size and parameters amount only slightly increase, and 
the FLOPs do not change, which means that the 
training speed of the improved network and the 
requirements for training equipment are basically 
unchanged. These ensure that our method can be easily 
deployed on the vehicle side. Although FPS decreases 
by 10, it still meets the requirements of real-time 
detection on the vehicle side.


---

### 4. Page 2

- Chunk: `chunk_4c99723739a79c4c`
- Entity: **Interpretability**
- Score: `0.6860`
- Document: `doc_a8343f0236b29082`

#### Graph path

```text
Interpretability
```

#### Content

---
id: chunk_4c99723739a79c4c
document: doc_a8343f0236b29082
heading: Page 2
start_paragraph: 2
end_paragraph: 3
---

# Page 2

## Page 2

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
2
domain. The main contributions of this paper are as follows:
• For early researchers in this area, we explain XAI termi-
nology and techniques in a simple and clear manner.
• We present a comprehensive review of the current studies
addressing XAI methods in IoT domain.
• We highlight the emerging challenges and open issues in
XAI from an IoT perspective and outline future research
directions.
The remainder of the paper is structured as follows. In
Section II, we present the taxonomy, terminology, and method-
ology of XAI. In Section III, we explain the needs and beneﬁts
of the synergies between XAI and IoT. In Section IV, we
review current studies addressing XAI by considering IoT
application areas. Section V outlines open challenges and
future directions. Finally, Section VI concludes the paper.
II. EXPLAINABLE ARTIFICIAL INTELLIGENCE (XAI)
A. Terminology and Deﬁnitions
Interpreting and explaining models are not a new problem in
computer science and statistics domains. The difﬁculty of de-
scribing the outcome of an expert system is long lasting issue
that has been tackled since the 1970s. With the proliferation
of AI applications, especially since 2016, interpreting and ex-
plaining models started to attract more attention. Practitioners
and academics in the literature interchangeably use the terms
XAI and Interpretable Machine Learning (IML). Nevertheless,
IML is a subset of XAI that focuses on describing the logic
of machine learning algorithms [13].
It is hard to give a precise deﬁnition for the term of
explanation. Although some systems are explainable by nature,
an explanation helps to make a system more understandable.
Especially determining what is a good explanation or not is a
debatable issue in the literature [14]. In addition, XAI and IML
are two similar concepts that are used interchangeably in the
literature [13], focusing on explainability and interpretability,
respectively. However, there are some fundamental differences
between these two terms. To clarify the similarities and dif-
ferences among the similar terms, we provide brief deﬁnitions
of the terms as follows [7], [11], [15], [16]:
• Explainability: It is the ability to provide information
about the inner workings of the model.
• Interpretability: It is the ability to extend a model or
its predictions understandable by humans. It is expressed
through transparency.
• Understandability / Intelligibility: It is the ability to
make a human grasp its function about how it works
without having to explain its underlying structure or the
algorithmic ways.
• Comprehensibility: It is the ability to express learned
information to make it understandable to humans.
• Transparency: It is the opposite of being opaque for a
black-box model. A system or a model becomes trans-
parent when it is understandable by humans.
• Faithfulness: It is the ability of being consistency of
choosing the truly relevant features.
• Informativeness: It is the ability of a strategy for explain-
ability to offer end-users with meaningful information.
• Explicitness: It is the ability of a method to deliver
immidiate and clear explanations.
These terms are given in Figure 1.
Explainable Artificial
Intelligence
(XAI)
Responsible
Transparent
Interpretable
Comprehensible
Understandable
Explainable
Informative
Explicit
Fig. 1. Buzzwords in XAI
B. XAI Taxonomy
The taxonomy of XAI can be classiﬁed from a variety of
perspectives [11], [17], as shown in Figure 2. It is worth point
out that there may be overlaps when a method is categorized
under this taxonomy. That is, a method can be classiﬁed into
one or more categories. A method can be classiﬁed as post-
hoc, model-agnostic, or local, for example. Accordingly, it
is more accurate to examine each method separately under
its own sub-taxonomy classiﬁcation. Furthermore, each ﬁgure
should be considered as an example method in the related
group. Different ﬁgures can be used to represent the taxonomy.
1) Ante-hoc vs. Post-hoc: An explanation can be provided
to a model in pre-training, in-training or post-training phases.
Explainable AI can be applied externally in pre-training or
post-training phases, or the model itself is intrinsically inter-
pretable during the training which is also called transparent.
Ante-hoc methods involve interpreting externally before the
training phase or internally during the training phase. At the
end of the training phase, the model becomes already ex-
plainable. Transparent methods like Decision Tree and Sparse
Linear Regression generally give intrinsic explainability about
the inner process of the structure. (𝑖𝑖) Post-hoc methods, on
the other hand, are applied externally after the training process
of decision systems. In addition, post-hoc methods can used
to the supplement ante-hoc methods for providing additional
information.
2) Model-speciﬁc vs. Model-agnostic: XAI can be grouped
based on applying to speciﬁc model classes, which are model-
speciﬁc and model-agnostic explanations (𝑖) Model-speciﬁc
methods are typically designed for one type of model such
as Deep Neural Network which is a well-known example


---

### 5. Page 12

- Chunk: `chunk_e462f399bda26deb`
- Entity: **Interpretability**
- Score: `0.6860`
- Document: `doc_a8343f0236b29082`

#### Graph path

```text
Interpretability
```

#### Content

---
id: chunk_e462f399bda26deb
document: doc_a8343f0236b29082
heading: Page 12
start_paragraph: 22
end_paragraph: 23
---

# Page 12

## Page 12

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
12
[7] R. Guidotti, A. Monreale, S. Ruggieri, F. Turini, F. Giannotti, and
D. Pedreschi, “A survey of methods for explaining black box models,”
ACM computing surveys (CSUR), vol. 51, no. 5, pp. 1–42, 2018.
[8] W. Samek, T. Wiegand, and K.-R. Müller, “Explainable artiﬁcial
intelligence: Understanding, visualizing and interpreting deep learning
models,” arXiv preprint arXiv:1708.08296, 2017.
[9] L. H. Gilpin, D. Bau, B. Z. Yuan, A. Bajwa, M. Specter, and L. Kagal,
“Explaining explanations: An overview of interpretability of machine
learning,” in 2018 IEEE 5th International Conference on data science
and advanced analytics (DSAA).
IEEE, 2018, pp. 80–89.
[10] E. Tjoa and C. Guan, “A survey on explainable artiﬁcial intelligence
(xai): Toward medical xai,” IEEE transactions on neural networks and
learning systems, vol. 32, no. 11, pp. 4793–4813, 2020.
[11] A. B. Arrieta, N. Díaz-Rodríguez, J. Del Ser, A. Bennetot, S. Tabik,
A. Barbado, S. García, S. Gil-López, D. Molina, R. Benjamins et al.,
“Explainable artiﬁcial intelligence (xai): Concepts, taxonomies, op-
portunities and challenges toward responsible ai,” Information fusion,
vol. 58, pp. 82–115, 2020.
[12] T. Rojat, R. Puget, D. Filliat, J. Del Ser, R. Gelin, and N. Díaz-
Rodríguez, “Explainable artiﬁcial intelligence (xai) on timeseries data:
A survey,” arXiv preprint arXiv:2104.00950, 2021.
[13] A. Adadi and M. Berrada, “Peeking inside the black-box: a survey
on explainable artiﬁcial intelligence (xai),” IEEE access, vol. 6, pp.
52 138–52 160, 2018.
[14] R. Confalonieri, L. Coba, B. Wagner, and T. R. Besold, “A historical
perspective of explainable artiﬁcial intelligence,” Wiley Interdisci-
plinary Reviews: Data Mining and Knowledge Discovery, vol. 11, no. 1,
p. e1391, 2021.
[15] M. van den Berg and O. Kuiper, “Xai in the ﬁnancial sector: a
conceptual framework for explainable ai (xai),” https://www. hu. nl/-
/media/hu/documenten/onderzoek/projecten/, 2020.
[16] G. Vilone and L. Longo, “Explainable artiﬁcial intelligence: a system-
atic review,” arXiv preprint arXiv:2006.00093, 2020.
[17] D. V. Carvalho, E. M. Pereira, and J. S. Cardoso, “Machine learning
interpretability: A survey on methods and metrics,” Electronics, vol. 8,
no. 8, p. 832, 2019.
[18] U. Kamath and J. Liu, Explainable Artiﬁcial Intelligence: An Introduc-
tion to Interpretable Machine Learning.
Springer, 2021.
[19] J. H. Friedman, “Greedy function approximation: a gradient boosting
machine,” Annals of statistics, pp. 1189–1232, 2001.
[20] A. Goldstein, A. Kapelner, J. Bleich, and E. Pitkin, “Peeking inside
the black box: Visualizing statistical learning with plots of individual
conditional expectation,” journal of Computational and Graphical
Statistics, vol. 24, no. 1, pp. 44–65, 2015.
[21] D. W. Apley and J. Zhu, “Visualizing the effects of predictor variables
in black box supervised learning models,” Journal of the Royal Sta-
tistical Society: Series B (Statistical Methodology), vol. 82, no. 4, pp.
1059–1086, 2020.
[22] M. Ku´zba, E. Baranowska, and P. Biecek, “pyceterisparibus: explaining
machine learning models with ceteris paribus proﬁles in python,”
Journal of Open Source Software, vol. 4, no. 37, p. 1389, 2019.
[23] M. J. Pontiveros, G. A. Solano, C. A. Tee, and M. L. Tee, “Explain-
able machine learning applied to single-nucleotide polymorphisms for
systemic lupus erythematosus prediction,” in 2020 11th International
Conference on Information, Intelligence, Systems and Applications
(IISA.
IEEE, 2020, pp. 1–8.
[24] S. M. Lundberg and S.-I. Lee, “A uniﬁed approach to interpreting
model predictions,” Advances in neural information processing systems,
vol. 30, 2017.
[25] O. Ribeiro, L. Gomes, and Z. Vale, “Iot-based human fall detection
system,” Electronics, vol. 11, no. 4, p. 592, 2022.
[26] M. T. Ribeiro, S. Singh, and C. Guestrin, “Anchors: High-precision
model-agnostic explanations,” in Proceedings of the AAAI conference
on artiﬁcial intelligence, vol. 32, no. 1, 2018.
[27] J. H. Friedman and B. E. Popescu, “Predictive learning via rule
ensembles,” The annals of applied statistics, vol. 2, no. 3, pp. 916–
954, 2008.
[28] F. Galkin, A. Aliper, E. Putin, I. Kuznetsov, V. N. Gladyshev, and
A. Zhavoronkov, “Human microbiome aging clocks based on deep
learning and tandem of permutation feature importance and accumu-
lated local effects,” BioRxiv, p. 507780, 2018.
[29] J. Lei, M. G’Sell, A. Rinaldo, R. J. Tibshirani, and L. Wasserman,
“Distribution-free predictive inference for regression,” Journal of the
American Statistical Association, vol. 113, no. 523, pp. 1094–1111,
2018.
[30] D. Lewis, Counterfactuals.
John Wiley & Sons, 2013.
[31] A. Dhurandhar, P.-Y. Chen, R. Luss, C.-C. Tu, P. Ting, K. Shanmugam,
and P. Das, “Explanations based on the missing: Towards contrastive
explanations with pertinent negatives,” Advances in neural information
processing systems, vol. 31, 2018.
[32] P. Stock and M. Cisse, “Convnets and imagenet beyond accuracy:
Understanding mistakes and uncovering biases,” in Proceedings of the
European Conference on Computer Vision (ECCV), 2018, pp. 498–512.
[33] J. Chakraborty, K. Peng, and T. Menzies, “Making fair ml software
using trustworthy explanation,” in 2020 35th IEEE/ACM International
Conference on Automated Software Engineering (ASE).
IEEE, 2020,
pp. 1229–1233.
[34] J. Druce, M. Harradon, and J. Tittle, “Explainable artiﬁcial intelligence
(xai) for increasing user trust in deep reinforcement learning driven
autonomous systems,” arXiv preprint arXiv:2106.03775, 2021.
[35] A. Das and P. Rad, “Opportunities and challenges in explainable ar-
tiﬁcial intelligence (xai): A survey,” arXiv preprint arXiv:2006.11371,
2020.
[36] J. Li, W. Monroe, and D. Jurafsky, “Understanding neural networks
through representation erasure,” arXiv preprint arXiv:1612.08220,
2016.
[37] V. Petsiuk, A. Das, and K. Saenko, “Rise: Randomized input
sampling for explanation of black-box models,” arXiv preprint
arXiv:1806.07421, 2018.
[38] L. M. Zintgraf, T. S. Cohen, T. Adel, and M. Welling, “Visualizing
deep neural network decisions: Prediction difference analysis,” arXiv
preprint arXiv:1702.04595, 2017.
[39] R. C. Fong and A. Vedaldi, “Interpretable explanations of black boxes
by meaningful perturbation,” in Proceedings of the IEEE international
conference on computer vision, 2017, pp. 3429–3437.
[40] D. Erhan, A. Courville, and Y. Bengio, “Understanding representations
learned in deep architectures,” Technical Report 1355, Université de
Montréal/DIRO, Tech. Rep., 2010.
[41] K. Simonyan, A. Vedaldi, and A. Zisserman, “Deep inside convolu-
tional networks: Visualising image classiﬁcation models and saliency
maps,” in In Workshop at International Conference on Learning
Representations.
Citeseer, 2014.
[42] A. Shrikumar, P. Greenside, and A. Kundaje, “Learning important
features through propagating activation differences,” in International
conference on machine learning.
PMLR, 2017, pp. 3145–3153.
[43] H. Chen, S. Lundberg, and S.-I. Lee, “Explaining models by prop-
agating shapley values of local components,” in Explainable AI in
Healthcare and Medicine.
Springer, 2021, pp. 261–270.
[44] M. D. Zeiler and R. Fergus, “Visualizing and understanding con-
volutional networks,” in European conference on computer vision.
Springer, 2014, pp. 818–833.
[45] J. T. Springenberg, A. Dosovitskiy, T. Brox, and M. Riedmiller,
“Striving for simplicity: The all convolutional net,” arXiv preprint
arXiv:1412.6806, 2014.
[46] B. Zhou, A. Khosla, A. Lapedriza, A. Oliva, and A. Torralba, “Learning
deep features for discriminative localization,” in Proceedings of the
IEEE conference on computer vision and pattern recognition, 2016,
pp. 2921–2929.
[47] R. R. Selvaraju, M. Cogswell, A. Das, R. Vedantam, D. Parikh, and
D. Batra, “Grad-cam: Visual explanations from deep networks via
gradient-based localization,” in Proceedings of the IEEE international
conference on computer vision, 2017, pp. 618–626.
[48] F. Doshi-Velez and B. Kim, “Towards a rigorous science of inter-
pretable machine learning,” arXiv preprint arXiv:1702.08608, 2017.
[49] I. Ahmed, G. Jeon, and F. Piccialli, “From artiﬁcial intelligence to
explainable artiﬁcial intelligence in industry 4.0: A survey on what,
how, and where,” IEEE Transactions on Industrial Informatics, 2022.
[50] N. Wang, D. V. Pynadath, and S. G. Hill, “The impact of pomdp-
generated explanations on trust and performance in human-robot
teams,” in Proceedings of the 2016 international conference on au-
tonomous agents & multiagent systems, 2016, pp. 997–1005.
[51] R. Iyer, Y. Li, H. Li, M. Lewis, R. Sundar, and K. Sycara, “Trans-
parency and explanation in deep reinforcement learning neural net-
works,” in Proceedings of the 2018 AAAI/ACM Conference on AI,
Ethics, and Society, 2018, pp. 144–150.
[52] T. Kampik, J. C. Nieves, and H. Lindgren, “Explaining sympathetic
actions of rational agents,” in International Workshop on Explainable,
Transparent Autonomous Agents and Multi-Agent Systems.
Springer,
2019, pp. 59–76.
[53] W. Guo, “Partially explainable big data driven deep reinforcement
learning for green 5g uav,” in ICC 2020-2020 IEEE International
Conference on Communications (ICC).
IEEE, 2020, pp. 1–7.


---

### 6. Page 3

- Chunk: `chunk_42086042ea3e3878`
- Entity: **Black-Box Models**
- Score: `0.6860`
- Document: `doc_a8343f0236b29082`

#### Graph path

```text
Black-Box Models
```

#### Content

---
id: chunk_42086042ea3e3878
document: doc_a8343f0236b29082
heading: Page 3
start_paragraph: 4
end_paragraph: 5
---

# Page 3

## Page 3

This work has been submitted to the IEEE for possible publication. Copyright may be transferred without notice, after which this version may no longer be accessible.
3
Black-Box 
   Models
When and how
explanation occurs 
in the model 
Explain particular
 feature or entire 
model features 
Explain speciﬁc 
model or any 
type of model
0
2
4
6
8
10
x4
x3
x2
x1
The output for 
xi is y 
because x  >45 
3
.  
.  
.  
.  
.        . 
.        . 
.        . 
.  
.  
.  
.  
.        . 
.        . 
.        . 
mean(|SHAP value| average impact on model output magnitute)
Class 1
Class 0
Contract
tenure
TotalCharges
InternetService
SeniorCitizen
TechSupport
OnlineSecurity
StreamingMovies
OnlineBackup
MonthlyCharges
Model 
Speciﬁc
Post-hoc
PhoneService
tenure
MonthlyCharges
SeniorCitizen
TechSupport
Contract
OnlineSecurity
InternetService
Partner
Dependents
- 0.10           - 0.05           0.00           0.05
Classiﬁer X - top 10 Coeﬃcient 
Ante-hoc
Model 
Agnostic
Global
Local
Fig. 2. The taxonomy of XAI in different perspectives
of black-box models with a superior prediction performance
despite its complex and opaque structure. The disadvantage
of model-speciﬁc explanations is that there is a limitation in
determining a model When the need for the particular type
of explanation. (𝑖𝑖) Model-agnostic methods can be applied
to any type of model without limiting the model classes.
It separates the explanation and model class. Therefore, the
explanations become independent of the model type.
3) Local vs. Global: According to the scope of the model,
explanations of the decision models can be performed locally
or globally. (𝑖) Local explanation describes why and how
certain predictions can be generated on a local level. It
concentrates on ensuring interpretability by examining single
or multiple instances. It is applied especially when predictions
are linearly dependent on some features rather than complex
dependence on all features. (𝑖𝑖) The goal of global explanation
is to characterize the model in its entirety. It seeks a global
understanding of which features are more signiﬁcant and what
kinds of relationships are possible between them.
C. XAI Methodologies
With the XAI concept gaining popularity in AI, different
XAI methods have begun to be developed. In literature, there
are different XAI methods to help explain and interpret black-
box models. These methods adopt different approaches and
provide different interpretations [18]. Here, we classify them
into ﬁve different groups as seen in Fig. 3.
1) Visual Explanation: Visual explanations cover a set of
methods to examine the relationships between input and output
or among input attributes, which allows users to understand the
contributions of each input to the output. In case the feature set
is small, interpreting these correlations is easier for users. Both
local and global explanations are supported visually. However,
as the feature set becomes large, visual explanations can fail
to visualize correlations properly, causing users to misinterpret
them. Partial Dependence Plot (PDP) [19] provides global
explanations and reveals the dependency between the input
features and output. Individual conditional explanation (ICE)
[20] plot is a more recent method that’s similar to PDP. PDP
calculates the mean over the marginal distribution, whereas
ICE keeps the entire distribution. Accumulated Local Effects
(ALE) [21] plots take the averages of changes in predictions
and accumulate them on local grids. Also, Ceteris Paribus (CP)
[22] plots and Breakdown plots [23] are employed to visualize
the inﬂuence of features on the model prediction for a speciﬁc
data instance.
2) Feature-based Explanation: Feature-based approaches,
like visual explanation methods, aim to assess the contribution
of features to the model prediction. Furthermore, they consider
some factors like type, robustness, and comprehensibility.
Explanations can be local or global. Similarly, it can be
model-speciﬁc or model-agnostic. Shapley values is a game-
theoretic approach to determine the feature importance of the
model. Then, SHapley Additive exPlanations (SHAP) [24]
method uses Shapley values and it is proposed for local and
global explanations. Also, KernelSHAP [24] is proposed to
overcome the conditional expectations issues of SHAP and
approximates the calculation of SHAP. Also, local and global
surrogate models attempt to explain the prediction of the
model. While local surrogate models like Local Interpretable
Model-Agnostic Explanations (LIME) [25] focus on explain-
ing the individual data instances, global surrogate models
focus on the entire model. Anchors [26] have also the ability of
local explanations by extracting a set of if-then rules. Feature
Interaction [27] is used for identifying the interaction effect


---
